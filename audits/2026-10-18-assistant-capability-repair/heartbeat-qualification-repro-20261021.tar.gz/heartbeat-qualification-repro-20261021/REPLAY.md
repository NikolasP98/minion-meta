# Heartbeat fixture diagnostic replay

The frozen candidate is not modified by this recipe. Prepare a new disposable clone
from base `71e8b2dcb748bce3970c78c5b3f6cbb4f71937ea`, using the same installed
Vitest 4.1.10 dependency tree. Do not use an existing working checkout.

```bash
repro_archive=/home/nikolas/.cache/codex-work/heartbeat-qualification-repro-20261021
repro_source=/home/nikolas/.cache/codex-work/minion-heartbeat-qualification-20261021
repro_clone=/home/nikolas/.cache/codex-work/heartbeat-disposable-replay-UNIQUE

git clone --no-hardlinks --no-checkout "$repro_source" "$repro_clone"
git -C "$repro_clone" checkout -b diagnostic/heartbeat-replay 71e8b2dcb748bce3970c78c5b3f6cbb4f71937ea
ln -s /home/nikolas/.cache/codex-work/minion-windows-qualification-20261021/node_modules "$repro_clone/node_modules"
cd "$repro_clone"
```

Run the following stages serially. `prepare-replay.py` copies the preserved stage
snapshot into the disposable clone and changes only its external diagnostic import
path to the preserved helper version. It refuses the frozen review clone. Intermediate
snapshots were reconstructed from the recorded edits after execution; their hashes are
not represented as execution-time attestations. `final-frozen.test.ts` was copied directly.

Before: original fixture, no cleanup drain, original 15s case budgets.
Expected exit 1: first test timeout and successor zero-send assertion failure.

```bash
python3 "$repro_archive/prepare-replay.py" "$repro_clone" before
HEARTBEAT_PROBE_SYNC_DELAY_MS=460 pnpm exec vitest run --project=unit src/infra/heartbeat-runner.respects-ackmaxchars-heartbeat-acks.test.ts --maxWorkers=1 -t 'respects ackMaxChars for heartbeat acks|sends HEARTBEAT_OK when visibility.showOk is true' --reporter=verbose
```

Drain only: preserve the original 15s timeout; delay only the first 34 flushes.
Expected exit 1: original timeout remains; successor passes after cleanup.

```bash
python3 "$repro_archive/prepare-replay.py" "$repro_clone" drain-only
HEARTBEAT_PROBE_SYNC_DELAY_MS=460 HEARTBEAT_PROBE_DELAY_SYNC_LIMIT=34 pnpm exec vitest run --project=unit src/infra/heartbeat-runner.respects-ackmaxchars-heartbeat-acks.test.ts --maxWorkers=1 -t 'respects ackMaxChars for heartbeat acks|sends HEARTBEAT_OK when visibility.showOk is true' --reporter=verbose
```

Bounded drain: same stage but explicit temporary 100ms onTestFinished and beforeEach
hook budgets. Expected exit 1: original timeout plus teardown hook timeout; successor
fails in the pending-fixture beforeEach, before resetting runtime/spies or running its
body. This demonstrates bounded failure, not cancellation of a permanently hung run.

```bash
python3 "$repro_archive/prepare-replay.py" "$repro_clone" drain-explicit-bound
HEARTBEAT_PROBE_SYNC_DELAY_MS=460 HEARTBEAT_PROBE_DELAY_SYNC_LIMIT=34 pnpm exec vitest run --project=unit src/infra/heartbeat-runner.respects-ackmaxchars-heartbeat-acks.test.ts --maxWorkers=1 -t 'respects ackMaxChars for heartbeat acks|sends HEARTBEAT_OK when visibility.showOk is true' --reporter=verbose
```

After: fixture drain plus six case-local 30s delivery limits; both selected cases
retain the same 460ms delay at every real flush. Expected exit 0: both pass (~15.8s each
in the recorded run). All actual I/O, locks, adapters, payloads and assertions run.

```bash
python3 "$repro_archive/prepare-replay.py" "$repro_clone" after
HEARTBEAT_PROBE_SYNC_DELAY_MS=460 pnpm exec vitest run --project=unit src/infra/heartbeat-runner.respects-ackmaxchars-heartbeat-acks.test.ts --maxWorkers=1 -t 'respects ackMaxChars for heartbeat acks|sends HEARTBEAT_OK when visibility.showOk is true' --reporter=verbose
```

Final normal file: no diagnostic import or injected latency; all 12 cases run.

```bash
python3 "$repro_archive/prepare-replay.py" "$repro_clone" normal
pnpm exec vitest run --project=unit src/infra/heartbeat-runner.respects-ackmaxchars-heartbeat-acks.test.ts --maxWorkers=1 --reporter=verbose
pnpm exec oxlint --type-aware src/infra/heartbeat-runner.respects-ackmaxchars-heartbeat-acks.test.ts
```

`receipt.json` binds original logs and preserved source snapshots by SHA-256. The
original `heartbeat-fs-delay-drain-bound.log` used CLI `--hookTimeout=100`, which did
not override the project's hook configuration; it is explicitly not the bounded-hook
proof. Use `heartbeat-fs-delay-drain-explicit-bound.log` for that proof.

The probe wraps `FileHandle.sync`, awaits an optional delay, and still calls the real
sync. It writes per-process counts/timings under the private cache. Native Windows
per-operation latency was not captured: this replay establishes a sufficient causal
mechanism and preserves failure semantics, not proof of the native host's exact I/O delay.
