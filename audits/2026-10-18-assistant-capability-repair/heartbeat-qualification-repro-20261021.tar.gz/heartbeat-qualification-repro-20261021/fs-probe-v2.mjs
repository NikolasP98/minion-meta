import fs from "node:fs";
import {setTimeout as delay} from "node:timers/promises";
const originalOpen=fs.promises.open;
const records=[]; let syncOrdinal=0;
fs.promises.open=async function(...args){
 const handle=await originalOpen.apply(this,args);
 const originalSync=handle.sync;
 handle.sync=async function(...syncArgs){
   const start=performance.now();
   if(++syncOrdinal <= Number(process.env.HEARTBEAT_PROBE_DELAY_SYNC_LIMIT ?? Infinity) && process.env.HEARTBEAT_PROBE_SYNC_DELAY_MS) await delay(Number(process.env.HEARTBEAT_PROBE_SYNC_DELAY_MS));
   try {return await originalSync.apply(this,syncArgs)}
   finally {records.push({path:String(args[0]),ms:performance.now()-start});fs.writeFileSync(`/home/nikolas/.cache/codex-work/heartbeat-fs-probe-${process.pid}.json`,JSON.stringify(records,null,2));}
 };
 return handle;
};
