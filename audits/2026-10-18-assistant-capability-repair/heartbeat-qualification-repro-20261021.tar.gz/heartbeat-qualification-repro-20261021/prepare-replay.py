#!/usr/bin/env python3
"""Prepare a diagnostic snapshot in a separately created, disposable clone."""
import pathlib, subprocess, sys
archive = pathlib.Path(__file__).resolve().parent
repo = pathlib.Path(sys.argv[1]).resolve()
stage = sys.argv[2]
protected = pathlib.Path('/home/nikolas/.cache/codex-work/minion-heartbeat-qualification-20261021').resolve()
if repo == protected:
    raise SystemExit('Refusing to modify the frozen review clone')
base = subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip()
if base != '71e8b2dcb748bce3970c78c5b3f6cbb4f71937ea':
    raise SystemExit('Replay clone must be at the exact diagnostic base')
files = {'before': ('before.test.ts', 'fs-probe-v1.mjs'), 'drain-only': ('drain-only.test.ts', 'fs-probe-v2.mjs'), 'drain-explicit-bound': ('drain-explicit-bound.test.ts', 'fs-probe-v2.mjs'), 'after': ('after.test.ts', 'fs-probe-v2.mjs'), 'normal': ('final-frozen.test.ts', None)}
snapshot, helper = files[stage]
text = (archive / snapshot).read_text()
if helper:
    text = text.replace('/home/nikolas/.cache/codex-work/heartbeat-fs-probe.mjs', str(archive / helper))
target = repo / 'src/infra/heartbeat-runner.respects-ackmaxchars-heartbeat-acks.test.ts'
target.write_text(text)
print(f'Prepared {stage}: {target}; only the diagnostic import path differs from the reconstructed snapshot')
