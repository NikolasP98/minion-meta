import { beforeEach, afterEach, describe, it, expect, vi } from 'vitest';
import { createServer, type Server } from 'node:http';
import { openPulsePostgres } from '../test-utils/pulse-postgres';
import {
  seedPulseAuthority,
  PULSE_FIXTURE_ORG as org,
  PULSE_FIXTURE_PROFILE as profile,
} from '../test-utils/pulse-fixtures';
import {
  digestFixturePolicy,
  digestFixtureSnapshot,
  digestFixtureResponse,
} from '../test-utils/pulse-digest-fixtures';
const boundary = vi.hoisted(() => ({ pool: vi.fn(), source: vi.fn(), admin: vi.fn() }));
vi.mock('$server/supabase', () => ({ supabaseAdmin: boundary.admin }));
vi.mock('$server/db/pg-pool', () => ({
  getPgClient: boundary.pool,
  getRlsPgClient: boundary.pool,
  getCriticalPgClient: boundary.pool,
  resetAllPgPools: vi.fn(),
}));
vi.mock('./pulse-digest.fetch', () => ({ fetchDigestSource: boundary.source }));
import { collectDueDigest } from './pulse-digest.collection';
import { GET } from '../../routes/api/pulse/tick/+server';
import { updateUserOrganizations } from './user.service';
let f: Awaited<ReturnType<typeof openPulsePostgres>>,
  policy: ReturnType<typeof digestFixturePolicy>,
  server: Server,
  origin: string,
  version: string,
  sourceCalls: number,
  modelCalls: number;
const nativeFetch = globalThis.fetch;
beforeEach(async () => {
  f = await openPulsePostgres();
  boundary.pool.mockReturnValue(f.pg);
  await seedPulseAuthority(f, 'wss://fixture.invalid');
  delete process.env.MINION_PULSE_WORKER_CONFIG;
  policy = digestFixturePolicy();
  process.env.MINION_PULSE_DIGEST_POLICY = JSON.stringify(policy);
  process.env.MINION_PULSE_DIGEST_SCOPE = JSON.stringify({
    tenantId: policy.tenantId,
    ownerProfileId: policy.ownerProfileId,
  });
  process.env.CRON_SECRET = 'local-pulse-cron-fixture';
  process.env.OPENROUTER_API_KEY = 'local-fixture-no-paid-access';
  version = 'v1';
  sourceCalls = 0;
  modelCalls = 0;
  boundary.admin.mockReturnValue({
    from: (table: string) => {
      if (table !== 'organization_members') throw new Error('fixture table');
      return {
        select: () => ({
          eq: async () => ({
            data: await f.pg`select organization_id from organization_members where profile_id=${profile}`,
            error: null,
          }),
        }),
        delete: () => ({
          eq: () => ({
            in: async () => {
              await f.peer`delete from organization_members where profile_id=${profile}`;
              return { error: null };
            },
          }),
        }),
      };
    },
  });
  boundary.source.mockReset();
  boundary.source.mockImplementation(async () => {
    sourceCalls++;
    return {
      status: 200,
      etag: version,
      lastModified: null,
      body: JSON.stringify([
        {
          html_url: `https://github.com/vercel/ai/releases/tag/${version}`,
          tag_name: `ai@${version}`,
          name: 'Fixture release',
          body: 'A supported synthetic dependency change.',
        },
      ]),
    };
  });
  server = createServer(async (req, res) => {
    for await (const _chunk of req) {
    }
    modelCalls++;
    const snapshot = await digestFixtureSnapshot(policy, version);
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify(digestFixtureResponse(snapshot)));
  });
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve));
  const address = server.address();
  if (!address || typeof address === 'string') throw new Error('fixture_bind');
  origin = `http://127.0.0.1:${address.port}`;
  vi.spyOn(globalThis, 'fetch').mockImplementation((input, init) => {
    const url = new URL(String(input));
    if (url.origin !== 'https://openrouter.ai' || !url.pathname.endsWith('/chat/completions'))
      throw new Error('external_fixture_network_denied');
    return nativeFetch(origin + url.pathname, init);
  });
});
afterEach(async () => {
  vi.restoreAllMocks();
  server?.closeAllConnections();
  if (server) await new Promise<void>((resolve) => server.close(() => resolve()));
  delete process.env.MINION_PULSE_DIGEST_POLICY;
  delete process.env.MINION_PULSE_DIGEST_SCOPE;
  delete process.env.OPENROUTER_API_KEY;
  delete process.env.CRON_SECRET;
  await f?.close();
});
const event = () =>
  ({
    request: new Request('http://127.0.0.1/api/pulse/tick', {
      headers: { authorization: 'Bearer local-pulse-cron-fixture' },
    }),
    url: new URL('http://127.0.0.1/api/pulse/tick'),
  }) as unknown as Parameters<typeof GET>[0];
describe('native cold-start collection and authenticated selected tick', () => {
  it('starts with an empty queue and one durable immediate poll under duplicate authenticated ticks', async () => {
    expect(await f.pg`select id from bg_jobs`).toHaveLength(0);
    await Promise.all([GET(event()), GET(event())]);
    expect(sourceCalls).toBe(1);
    expect(modelCalls).toBe(1);
    expect(await f.pg`select id from pulse_proposals`).toHaveLength(1);
    const [ns] =
      await f.pg`select extract(epoch from next_poll_at-clock_timestamp()) as remaining,collection_owner from pulse_digest_admission`;
    expect(Number(ns.remaining)).toBeGreaterThan(890);
    expect(ns.collection_owner).toBeNull();
    await GET(event());
    expect(sourceCalls).toBe(1);
    version = 'v2';
    await f.pg`update pulse_digest_admission set next_poll_at=now()-interval '1 second'`;
    await GET(event());
    expect(sourceCalls).toBe(2);
    expect(modelCalls).toBe(2);
    expect(await f.pg`select id from pulse_proposals`).toHaveLength(2);
  });
  it('leaves more than twenty unrelated older jobs untouched', async () => {
    await f.pg`insert into bg_jobs(id,tenant_id,user_id,type,status,created_at,updated_at) select gen_random_uuid()::text,${org},'other-owner','pulse_digest','queued',1,1 from generate_series(1,25)`;
    await GET(event());
    const [count] =
      await f.pg`select count(*)::int as n from bg_jobs where user_id='other-owner' and status='queued' and attempts=0`;
    expect(count.n).toBe(25);
    expect(modelCalls).toBe(1);
  });
  it('records a failed poll at five minutes without a mixed snapshot queue or cursor advance', async () => {
    boundary.source.mockRejectedValue(new Error('fixture source unavailable'));
    await GET(event());
    expect(await f.pg`select id from pulse_digest_runs`).toHaveLength(0);
    expect(await f.pg`select source_id from pulse_digest_sources`).toHaveLength(0);
    expect(modelCalls).toBe(0);
    const [ns] =
      await f.pg`select last_collection_outcome,extract(epoch from next_poll_at-clock_timestamp()) as remaining from pulse_digest_admission`;
    expect(ns.last_collection_outcome).toBe('failed');
    expect(Number(ns.remaining)).toBeGreaterThan(290);
    expect(Number(ns.remaining)).toBeLessThanOrEqual(300);
  });
  it('reclaims an expired generation lease and denies a stale collectors successor cadence write', async () => {
    await collectDueDigest(policy, performance.now() + 15000);
    await f.pg`update pulse_digest_admission set collection_owner=gen_random_uuid(),collection_lease_until=now()-interval '1 second',next_poll_at=now()-interval '1 second'`;
    expect((await collectDueDigest(policy, performance.now() + 15000)).outcome).toBe('duplicate');
    await f.pg`update pulse_digest_admission set next_poll_at=now()-interval '1 second'`;
    let release!: () => void;
    let entered!: () => void;
    const ready = new Promise<void>((r) => {
      entered = r;
    });
    const original = boundary.source.getMockImplementation()!;
    boundary.source.mockImplementation(async (...args: unknown[]) => {
      entered();
      await new Promise<void>((r) => {
        release = r;
      });
      return original(...args);
    });
    const pending = collectDueDigest(policy, performance.now() + 15000);
    await ready;
    await f.peer`update pulse_digest_admission set collection_generation=collection_generation+1,collection_owner=gen_random_uuid(),collection_lease_until=now()+interval '30 seconds',next_poll_at=now()+interval '1 hour'`;
    release();
    expect((await pending).outcome).toBe('failed');
    const [ns] =
      await f.pg`select extract(epoch from next_poll_at-clock_timestamp()) as remaining from pulse_digest_admission`;
    expect(Number(ns.remaining)).toBeGreaterThan(3500);
  });
  it('fences actual membership deletion during collection and cancels queued digest via the shared caller', async () => {
    let release!: () => void;
    let entered!: () => void;
    const ready = new Promise<void>((r) => {
      entered = r;
    });
    const original = boundary.source.getMockImplementation()!;
    boundary.source.mockImplementation(async (...args: unknown[]) => {
      entered();
      await new Promise<void>((r) => {
        release = r;
      });
      return original(...args);
    });
    const pending = collectDueDigest(policy, performance.now() + 15000);
    await ready;
    await updateUserOrganizations({ db: {} as never, tenantId: org }, profile, []);
    release();
    await pending;
    expect(await f.pg`select id from pulse_digest_runs`).toHaveLength(0);
    const [ns] = await f.pg`select enabled,collection_owner from pulse_digest_admission`;
    expect(ns.enabled).toBe(false);
    expect(ns.collection_owner).toBeNull();
    expect(modelCalls).toBe(0);
  });
  it('defers inference without admission when collection leaves fewer than thirty two seconds', async () => {
    const nativeNow = performance.now.bind(performance);
    let offset = 0;
    vi.spyOn(performance, 'now').mockImplementation(() => nativeNow() + offset);
    const original = boundary.source.getMockImplementation()!;
    boundary.source.mockImplementation(async (...args: unknown[]) => {
      const response = await original(...args);
      offset = 19000;
      return response;
    });
    await GET(event());
    expect(modelCalls).toBe(0);
    const [run] = await f.pg`select state,attempt_id from pulse_digest_runs`;
    expect(run).toEqual({ state: 'queued', attempt_id: null });
    const [job] = await f.pg`select status,next_attempt_at from bg_jobs`;
    expect(job.status).toBe('queued');
    expect(job.next_attempt_at).toBeTruthy();
    const [ns] = await f.pg`select attempted_calls from pulse_digest_admission`;
    expect(ns.attempted_calls).toBe(0);
  });
});
