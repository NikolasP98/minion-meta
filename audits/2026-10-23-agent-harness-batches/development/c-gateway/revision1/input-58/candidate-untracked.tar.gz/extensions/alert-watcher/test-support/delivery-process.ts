import fs from "node:fs";
import { setActivePluginRegistry } from "../../../src/plugins/runtime.js";
import type { DeliveryRow } from "../src/classification-work.js";

// Native outbound modules require the actual initialized plugin registry. Dynamic
// imports preserve this boundary when the formatter sorts the static imports.
const [
  { deliverOutboundPayloadsWithOutcome },
  { readQueuedDelivery },
  { enqueueDelivery },
  { createTestRegistry, createOutboundTestPlugin },
  { getWork },
  { settleDelivery },
  { snapshotHash },
  { testDb },
] = await Promise.all([
  import("../../../src/infra/outbound/deliver.js"),
  import("../../../src/infra/outbound/delivery-queue-files.js"),
  import("../../../src/infra/outbound/delivery-queue-store.js"),
  import("../../../src/test-support/channel-plugins.js"),
  import("../src/classification-work.js"),
  import("../src/delivery-bridge.js"),
  import("../src/provenance.js"),
  import("../src/work-test-fixtures.js"),
]);
const [file, receiptId, stateDir, stage, marker] = process.argv.slice(2);
const db = testDb(file),
  row = db
    .prepare("SELECT * FROM alert_delivery_receipts WHERE id=?")
    .get(receiptId) as DeliveryRow,
  work = getWork(db, row.work_id)!;
const recipient = JSON.parse(row.recipient_json!);
const params = {
  id: receiptId,
  channel: "telegram" as const,
  to: recipient.to,
  accountId: recipient.accountId,
  payloads: JSON.parse(row.payload_json!),
  completionPolicy: "caller" as const,
  callerRetention: {
    version: 1 as const,
    owner: "alert-watcher" as const,
    namespaceHash: snapshotHash(work.namespace),
    receiptId,
    payloadHash: row.payload_hash,
    recipientHash: row.recipient_hash,
    expiresAt: row.payload_expires_at,
  },
};
const barrier = (value: string) => {
  process.send?.({ stage: value });
};
const owner = `child-${process.pid}`,
  generation = row.generation + 1;
db.prepare(
  "UPDATE alert_delivery_receipts SET state='admitted',admitted_at=?,lease_owner=?,generation=?,lease_expires_at=? WHERE id=?",
).run(Date.now(), owner, generation, Date.now() + 30000, receiptId);
if (stage === "sqlite-admitted") {
  barrier(stage);
} else if (stage === "enqueued") {
  await enqueueDelivery(params, stateDir);
  barrier(stage);
} else {
  const send = async () => {
    fs.appendFileSync(marker, "accepted\n");
    if (stage === "provider-accepted") {
      barrier(stage);
      await new Promise(() => {});
    }
    return { channel: "telegram" as const, messageId: "accepted" };
  };
  setActivePluginRegistry(
    createTestRegistry([
      {
        pluginId: "telegram",
        source: "test",
        plugin: createOutboundTestPlugin({
          id: "telegram",
          outbound: { deliveryMode: "direct", sendText: send, sendMedia: send },
        }),
      },
    ]),
  );
  await deliverOutboundPayloadsWithOutcome({
    cfg: {},
    channel: "telegram",
    to: params.to,
    accountId: params.accountId,
    payloads: params.payloads,
    completionPolicy: "caller",
    callerRetention: params.callerRetention,
    queueId: receiptId,
    stateDir,
    durability: "required",
  });
  if (stage === "settled") {
    const entry = await readQueuedDelivery(receiptId, stateDir);
    settleDelivery(db, receiptId, owner, generation, "sent", {
      acceptedAt: entry.payloads[0].acceptedAt,
      queueGeneration: entry.generation,
      receipts: entry.payloads.map((p) => ({
        id: p.id,
        receipt: p.receipt,
        acceptedAt: p.acceptedAt,
      })),
    });
  }
  barrier(stage);
}
setInterval(() => {}, 1000);
