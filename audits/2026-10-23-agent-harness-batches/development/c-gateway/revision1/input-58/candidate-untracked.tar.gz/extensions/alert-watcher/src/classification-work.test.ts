import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { describe, it, expect } from "vitest";
import {
  admitSource,
  claimWork,
  admitInvocation,
  receiveInvocation,
  getWork,
  recoverExpiredInvocations,
  retryNoCredentials,
  redactExpiredWork,
  retireNamespace,
  finishWork,
  materializePositive,
} from "./classification-work.js";
import { exportComplaintEvaluation } from "./complaint-evaluation.js";
import { snapshotHash } from "./provenance.js";
import { initReplySchema } from "./reply-flow/store.js";
import { initSchema } from "./store.js";
import { testDb, workFixture } from "./work-test-fixtures.js";
const negative = {
  ok: true as const,
  data: { is_complaint: false, severity: "low", category: "other", summary: "" },
  usage: { inputTokens: 3, outputTokens: 4, cacheReadTokens: 0, cacheCreationTokens: 0 },
  durationMs: 12,
  resolvedModel: { provider: "anthropic", model: "claude-haiku-4-5" },
};
function usage(id: string) {
  return {
    attemptId: id,
    purpose: "classification" as const,
    requestedModel: negative.resolvedModel,
    resolvedModel: negative.resolvedModel,
    usage: negative.usage,
    costStatus: "known" as const,
    costUsd: 0.000023,
    costCoverage: "complete" as const,
    elapsedMs: 12,
  };
}
describe("durable classification receipts", () => {
  it("pins policy, exact source bytes, stable admission and ownership", () => {
    const db = testDb();
    const snapshot = workFixture();
    const first = admitSource(db, "namespace", snapshot);
    expect(first.kind).toBe("admitted");
    if (first.kind !== "admitted") {
      throw Error();
    }
    expect(
      admitSource(db, "namespace", {
        ...snapshot,
        model: "changed",
        policyHash: snapshotHash("new"),
      }).kind,
    ).toBe("existing");
    expect(
      admitSource(db, "namespace", {
        ...snapshot,
        source: { ...snapshot.source, text: snapshot.source.text.trim() },
      }).kind,
    ).toBe("identity_conflict");
    expect(
      admitSource(db, "namespace", {
        ...snapshot,
        source: { ...snapshot.source, conversationId: "other" },
      }).kind,
    ).toBe("admitted");
    expect(
      admitSource(db, "namespace", {
        ...snapshot,
        source: { ...snapshot.source, providerRevision: "edit1" },
      }).kind,
    ).toBe("admitted");
    const lease = claimWork(db, first.work.id, "owner")!;
    expect(claimWork(db, first.work.id, "other")).toBeUndefined();
    const id = admitInvocation(db, lease);
    receiveInvocation(db, lease, negative, usage(id));
    finishWork(db, lease, "completed");
    expect(getWork(db, first.work.id)?.state).toBe("completed");
    const record = exportComplaintEvaluation(db, first.work.id);
    expect(record.baseline.disposition).toBe("negative");
    expect(record.attempts[0].costUsd).toBe(0.000023);
    expect(exportComplaintEvaluation(db, first.work.id)).toEqual(record);
    db.close();
  });
  it("recovers ambiguous admitted work without returning it to queued and fences stale generations", () => {
    const db = testDb();
    const admitted = admitSource(db, "n", workFixture());
    if (admitted.kind !== "admitted") {
      throw Error();
    }
    const lease = claimWork(db, admitted.work.id, "owner")!;
    admitInvocation(db, lease);
    recoverExpiredInvocations(db, Date.now() + 31000);
    expect(getWork(db, lease.id)?.state).toBe("indeterminate");
    expect(claimWork(db, lease.id, "new")).toBeUndefined();
    expect(() =>
      receiveInvocation(db, lease, negative, usage(getWork(db, lease.id)!.attempt_id!)),
    ).toThrow();
    db.close();
  });
  it("retries only proven pre-provider errors at 5s/30s with three persisted invocations", () => {
    const db = testDb();
    const first = admitSource(db, "n", workFixture());
    if (first.kind !== "admitted") {
      throw Error();
    }
    let now = Date.now();
    for (let i = 1; i <= 3; i++) {
      const lease = claimWork(db, first.work.id, "owner", now)!;
      const id = admitInvocation(db, lease, now);
      receiveInvocation(
        db,
        lease,
        { ok: false, error: { code: "NO_API_KEY", message: "missing" }, durationMs: 0 },
        { ...usage(id), resolvedModel: null, costStatus: "unknown", costUsd: null },
        now,
      );
      retryNoCredentials(db, lease, now);
      const row = getWork(db, first.work.id)!;
      expect(row.attempt_count).toBe(i);
      if (i < 3) {
        expect(claimWork(db, row.id, "early", now)).toBeUndefined();
        expect(row.next_attempt_at - now).toBe(i === 1 ? 5000 : 30000);
        now = row.next_attempt_at;
      } else {
        expect(row.state).toBe("failed");
      }
    }
    db.close();
  });
  it("migrates old schema twice and never cascades tombstones when complaint rows are removed", () => {
    const directory = fs.mkdtempSync(path.join(os.tmpdir(), "watcher-migrate-"));
    const file = path.join(directory, "alerts.db");
    const db = testDb(file);
    initSchema(db);
    initReplySchema(db);
    const row = admitSource(db, "n", workFixture());
    expect(row.kind).toBe("admitted");
    const columns = db.prepare("PRAGMA table_info(pending_replies)").all() as Array<{
      name: string;
    }>;
    expect(columns.map((c) => c.name)).toContain("receipt_binding");
    db.exec("DELETE FROM complaints");
    expect(db.prepare("SELECT count(*) n FROM classification_work").get()).toEqual({ n: 1 });
    retireNamespace(db, "n");
    expect(
      admitSource(db, "n", workFixture({ source: { ...workFixture().source, messageId: "fresh" } }))
        .kind,
    ).toBe("retired");
    db.close();
    fs.rmSync(directory, { recursive: true, force: true });
  });
  it("redacts all raw copies while retaining paid receipt facts", () => {
    const db = testDb();
    const first = admitSource(db, "n", workFixture());
    if (first.kind !== "admitted") {
      throw Error();
    }
    const lease = claimWork(db, first.work.id, "owner")!;
    const id = admitInvocation(db, lease);
    const result = {
      ...negative,
      data: {
        is_complaint: true,
        severity: "high" as const,
        category: "other" as const,
        summary: "private summary",
      },
    };
    receiveInvocation(db, lease, result, usage(id));
    materializePositive(db, lease, result.data, "private payload", workFixture().destinations);
    finishWork(db, lease, "completed");
    expect(redactExpiredWork(db, Date.now() + 8 * 86400000)).toBe(1);
    expect(JSON.stringify(db.prepare("SELECT * FROM complaints").all())).not.toContain("private");
    expect(getWork(db, first.work.id)?.snapshot).toBeNull();
    expect(getWork(db, first.work.id)?.attempts_json).toContain("0.000023");
    expect(admitSource(db, "n", workFixture()).kind).toBe("existing");
    db.close();
  });
});
