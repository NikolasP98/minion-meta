import crypto from "node:crypto";
import type { DatabaseSync } from "node:sqlite";
import type { TerminalObserver } from "../../../src/drones/run-with-usage.js";
import {
  admitSource,
  claimWork,
  admitInvocation,
  receiveInvocation,
  finishWork,
} from "./classification-work.js";
import { snapshotHash } from "./provenance.js";
/** Legacy/manual calls get fresh accounting identities, never transport authority or dedup grants. */
export function legacyTerminalObserver(
  db: DatabaseSync | null,
  purpose: TerminalObserver["purpose"],
  model: string,
  input: string,
): TerminalObserver {
  if (!db) {
    throw new Error("alert-watcher store unavailable");
  }
  const identity = crypto.randomUUID();
  const admitted = admitSource(db, "uncertified-invocations", {
    source: {
      channel: "manual",
      accountId: "manual",
      conversationId: identity,
      messageId: identity,
      text: input,
    },
    authority: {
      kind: "local_unscoped",
      source: "json_config",
      evidenceHash: snapshotHash(["uncertified", identity]),
    },
    model,
    language: "es",
    overrides: {},
    minSeverity: "low",
    cooldown: { enabled: false, maxMessages: 12, windowMinutes: 30 },
    destinations: [],
    replyFlow: {
      enabled: false,
      windowMs: 0,
      notifyLoser: false,
      suggestions: { enabled: false, count: 0, maxChars: 0 },
    },
    mode: "off",
    policyHash: snapshotHash([purpose, model]),
    defaultPolicyHash: snapshotHash("uncertified"),
    customPolicy: true,
    sourceCertification: "uncertified",
    invocationPurpose: purpose,
  });
  if (admitted.kind !== "admitted") {
    throw new Error("fresh_invocation_admission_failed");
  }
  const lease = claimWork(db, admitted.work.id, identity);
  if (!lease) {
    throw new Error("fresh_invocation_claim_failed");
  }
  const attemptId = admitInvocation(db, lease);
  return {
    attemptId,
    purpose,
    onTerminal: (result, usage) => {
      receiveInvocation(db, lease, result, usage);
      finishWork(
        db,
        lease,
        result.ok ? "completed" : "failed",
        result.ok ? undefined : result.error.code,
      );
    },
  };
}
