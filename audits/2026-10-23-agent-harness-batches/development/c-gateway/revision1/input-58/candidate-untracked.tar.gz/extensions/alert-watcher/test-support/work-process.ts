import fs from "node:fs";
import { claimWork, admitInvocation, receiveInvocation } from "../src/classification-work.js";
import { testDb } from "../src/work-test-fixtures.js";
const [file, id, stage, marker] = process.argv.slice(2);
const db = testDb(file);
process.send?.({ stage: "ready" });
process.on("message", () => {
  const lease = claimWork(db, id, `child-${process.pid}`);
  if (!lease) {
    process.send?.({ stage: "unclaimed" });
    return;
  }
  if (stage === "claim") {
    process.send?.({ stage: "claimed", lease });
    return;
  }
  const attemptId = admitInvocation(db, lease);
  if (stage === "admitted") {
    process.send?.({ stage, lease });
    return;
  }
  fs.appendFileSync(marker, "invoked\n");
  if (stage === "response") {
    process.send?.({ stage, lease });
    return;
  }
  const result = {
    ok: true as const,
    data: { is_complaint: false, severity: "low", category: "other", summary: "" },
    usage: { inputTokens: 5, outputTokens: 6, cacheReadTokens: 0, cacheCreationTokens: 0 },
    resolvedModel: { provider: "anthropic", model: "claude-haiku-4-5" },
    durationMs: 1,
  };
  receiveInvocation(db, lease, result, {
    attemptId,
    purpose: "classification",
    requestedModel: result.resolvedModel,
    resolvedModel: result.resolvedModel,
    usage: result.usage,
    costStatus: "known",
    costUsd: 0.000035,
    costCoverage: "complete",
    elapsedMs: 1,
  });
  process.send?.({ stage: "received", lease });
});
