import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { afterEach, it, expect, vi } from "vitest";
import { readDeliveryTombstone } from "../../../src/infra/outbound/delivery-queue-files.js";
import { setActivePluginRegistry } from "../../../src/plugins/runtime.js";
import {
  createTestRegistry,
  createOutboundTestPlugin,
} from "../../../src/test-support/channel-plugins.js";
import type { DeliveryRow } from "./classification-work.js";
import { exportComplaintEvaluation } from "./complaint-evaluation.js";
import { drainDeliveryReceipts } from "./delivery-bridge.js";
import { snapshotHash } from "./provenance.js";
import { positiveFixture } from "./work-test-fixtures.js";
const dirs: string[] = [];
afterEach(() => {
  for (const d of dirs.splice(0)) {
    fs.rmSync(d, { recursive: true, force: true });
  }
});

it("two actual recipients settle one keyed reply at original acceptance before ack", async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "watcher-bridge-"));
  dirs.push(dir);
  const f = positiveFixture(dir, [
    { channel: "telegram", to: "one" },
    { channel: "telegram", to: "two" },
  ]);
  const send = vi.fn(async () => ({ channel: "telegram" as const, messageId: "accepted" }));
  setActivePluginRegistry(
    createTestRegistry([
      {
        pluginId: "telegram",
        source: "test",
        plugin: createOutboundTestPlugin({
          id: "telegram",
          outbound: { deliveryMode: "direct", sendText: send, sendMedia: send },
        }),
      },
    ]),
  );
  const deps = {
    stateDir: dir,
    config: () => ({}),
    authority: async () => f.snapshot.authority,
    destinations: () => f.snapshot.destinations,
  };
  await drainDeliveryReceipts(f.db, deps);
  expect(send).toHaveBeenCalledTimes(2);
  const rows = f.db.prepare("SELECT * FROM pending_replies").all() as Array<{
    id: number;
    expires_at: number;
    created_at: number;
    claimed_by: string | null;
  }>;
  expect(rows).toHaveLength(1);
  expect(rows[0].expires_at - rows[0].created_at).toBe(3600000);
  f.db.prepare("UPDATE pending_replies SET claimed_by='owner' WHERE id=?").run(rows[0].id);
  await drainDeliveryReceipts(f.db, deps);
  expect(send).toHaveBeenCalledTimes(2);
  expect(
    f.db.prepare("SELECT claimed_by,created_at,expires_at FROM pending_replies").get(),
  ).toMatchObject({
    claimed_by: "owner",
    created_at: rows[0].created_at,
    expires_at: rows[0].expires_at,
  });
  for (const row of f.db.prepare("SELECT * FROM alert_delivery_receipts").all() as DeliveryRow[]) {
    expect(await readDeliveryTombstone(row.id, dir)).toMatchObject({ reason: "settled" });
  }
  f.db.close();
});
it("admitted missing queue evidence never reenqueues, and revoked queued recipients never send", async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "watcher-bridge-missing-"));
  dirs.push(dir);
  const f = positiveFixture(dir);
  f.db.prepare("UPDATE alert_delivery_receipts SET state='admitted',admitted_at=?").run(Date.now());
  const send = vi.fn();
  await drainDeliveryReceipts(f.db, {
    stateDir: dir,
    config: () => ({}),
    authority: async () => f.snapshot.authority,
    destinations: () => [],
    send,
  });
  expect(send).not.toHaveBeenCalled();
  expect(f.db.prepare("SELECT state,safe_reason FROM alert_delivery_receipts").get()).toEqual({
    state: "indeterminate",
    safe_reason: "missing_or_mismatched_queue",
  });
  f.db.close();
});

it("first-sent materialization preserves actual owner selection and forwarded state", async () => {
  const { handleOwnerReply } = await import("./reply-flow/handle-reply.js");
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "watcher-owner-reply-"));
  dirs.push(dir);
  const f = positiveFixture(dir);
  f.db
    .prepare("UPDATE classification_work SET suggestion_json=? WHERE id=?")
    .run(JSON.stringify({ state: "received", suggestions: ["alpha", "beta", "gamma"] }), f.id);
  const send = vi.fn(async () => ({ channel: "telegram" as const, messageId: "accepted" }));
  setActivePluginRegistry(
    createTestRegistry([
      {
        pluginId: "telegram",
        source: "test",
        plugin: createOutboundTestPlugin({
          id: "telegram",
          outbound: { deliveryMode: "direct", sendText: send, sendMedia: send },
        }),
      },
    ]),
  );
  const deps = {
    stateDir: dir,
    config: () => ({}),
    authority: async () => f.snapshot.authority,
    destinations: () => f.snapshot.destinations,
  };
  await drainDeliveryReceipts(f.db, deps);
  const forward = vi.fn(async () => ({ ok: true }));
  const api = {
    runtime: {
      channel: {
        telegram: { sendMessageTelegram: forward },
        whatsapp: { sendMessageWhatsApp: forward },
      },
    },
    logger: { info: () => {}, warn: () => {}, error: () => {} },
  };
  expect(
    await handleOwnerReply(f.db, api as never, f.snapshot.replyFlow, {
      sender: "owner",
      message: "2",
    }),
  ).toEqual({ status: "forwarded", kind: "preset_2", text: "beta" });
  expect(forward).toHaveBeenCalledWith("chat", "beta", { accountId: "default" });
  await drainDeliveryReceipts(f.db, deps);
  expect(
    f.db.prepare("SELECT claimed_by,reply_text,forwarded_ok FROM pending_replies").get(),
  ).toEqual({ claimed_by: "owner", reply_text: "beta", forwarded_ok: 1 });
  f.db.close();
});

it.each([
  "revoked_before",
  "unbound",
  "revoked_during_send",
  "reassigned_during_send",
  "source_revoked_during_send",
] as const)("first confirmed send cannot grant an owner reply after %s", async (mode) => {
  const { handleOwnerReply } = await import("./reply-flow/handle-reply.js");
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "watcher-current-reply-"));
  dirs.push(dir);
  const f = positiveFixture(dir, [
    { channel: "telegram", to: "one" },
    { channel: "telegram", to: "revoked" },
  ]);
  if (mode === "unbound") {
    delete f.snapshot.destinationAuthorities![snapshotHash(["telegram", "default", "revoked"])];
    f.db
      .prepare("UPDATE classification_work SET snapshot=? WHERE id=?")
      .run(JSON.stringify(f.snapshot), f.id);
  }
  let configured =
    mode === "revoked_before" ? [f.snapshot.destinations[0]] : f.snapshot.destinations;
  const permitted = new Set(["one", "revoked"]);
  let sourceActive = true;
  let enter: () => void = () => {},
    release: () => void = () => {};
  const entered = new Promise<void>((resolve) => {
      enter = resolve;
    }),
    resume = new Promise<void>((resolve) => {
      release = resolve;
    });
  const during = mode.endsWith("during_send");
  const send = vi.fn(async () => {
    if (during) {
      enter();
      await resume;
    }
    return { channel: "telegram" as const, messageId: "accepted-before-local-settlement" };
  });
  setActivePluginRegistry(
    createTestRegistry([
      {
        pluginId: "telegram",
        source: "test",
        plugin: createOutboundTestPlugin({
          id: "telegram",
          outbound: { deliveryMode: "direct", sendText: send, sendMedia: send },
        }),
      },
    ]),
  );
  const deps = {
    stateDir: dir,
    config: () => ({}),
    authority: async () =>
      sourceActive
        ? f.snapshot.authority
        : { kind: "unavailable" as const, reason: "plugin_disabled" },
    destinations: () => configured,
    recipientAllowed: async (
      snapshot: typeof f.snapshot,
      recipient: (typeof f.snapshot.destinations)[number],
    ) =>
      permitted.has(recipient.to) &&
      !!snapshot.destinationAuthorities?.[
        snapshotHash([recipient.channel, recipient.accountId ?? "default", recipient.to])
      ],
  };
  const draining = drainDeliveryReceipts(f.db, deps);
  if (during) {
    await entered;
    configured = mode === "revoked_during_send" ? [] : [f.snapshot.destinations[0]];
    if (mode === "reassigned_during_send") {
      permitted.delete("one");
    }
    if (mode === "source_revoked_during_send") {
      sourceActive = false;
    }
    release();
  }
  await draining;
  expect(send).toHaveBeenCalledTimes(1);
  expect(f.db.prepare("SELECT state FROM alert_delivery_receipts ORDER BY rowid").all()).toEqual([
    { state: "sent" },
    { state: "canceled" },
  ]);
  const pending = f.db.prepare("SELECT * FROM pending_replies").get() as {
    destinations_json: string;
    created_at: number;
    expires_at: number;
    redacted_at: number | null;
  };
  expect(JSON.parse(pending.destinations_json)).toEqual(during ? [] : ["one"]);
  const forward = vi.fn(async () => ({ ok: true }));
  const api = {
    runtime: {
      channel: {
        telegram: { sendMessageTelegram: forward },
        whatsapp: { sendMessageWhatsApp: forward },
      },
    },
    logger: { info: () => {}, warn: () => {}, error: () => {} },
  };
  expect(
    await handleOwnerReply(
      f.db,
      api as never,
      { ...f.snapshot.replyFlow, notifyLoser: false },
      { sender: "revoked", message: "unapproved" },
    ),
  ).toEqual({ status: "ignored" });
  expect(forward).not.toHaveBeenCalled();
  expect(
    (
      await handleOwnerReply(
        f.db,
        api as never,
        { ...f.snapshot.replyFlow, notifyLoser: false },
        { sender: "one", message: "approved" },
      )
    ).status,
  ).toBe(during ? "ignored" : "forwarded");
  const stable = f.db.prepare("SELECT * FROM pending_replies").get();
  configured = f.snapshot.destinations;
  permitted.add("one");
  sourceActive = true;
  await drainDeliveryReceipts(f.db, deps);
  expect(f.db.prepare("SELECT * FROM pending_replies").get()).toEqual(stable);
  expect(send).toHaveBeenCalledTimes(1);
  expect(f.db.prepare("SELECT first_sent_at FROM classification_work").get()).toEqual({
    first_sent_at: pending.created_at,
  });
  const record = exportComplaintEvaluation(f.db, f.id);
  expect(record.baseline.disposition).toBe("positive");
  expect(record.attempts).toHaveLength(1);
  expect(record.attempts[0].costStatus).toBe("unknown");
  f.db.close();
});
