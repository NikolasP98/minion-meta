import { resolveDefaultAgentId } from "../../agents/agent-scope.js";
import type { MinionConfig } from "../../config/config.js";
import {
  canonicalizeMainSessionAlias,
  resolveAgentIdFromSessionKey,
} from "../../config/sessions.js";
import { normalizeAgentId, toAgentStoreSessionKey } from "../../routing/session-key.js";

/** A supplied binding is never silently downgraded to the default owner. */
export function assertRawCronBinding(raw: unknown): void {
  if (!raw || typeof raw !== "object") {
    return;
  }
  const value = raw as Record<string, unknown>;
  for (const key of ["agentId", "sessionKey"] as const) {
    if (typeof value[key] === "string" && !value[key].trim()) {
      throw new Error(`invalid cron binding: ${key} must not be blank`);
    }
  }
}

export function validateCronBinding(
  cfg: MinionConfig,
  binding: { agentId?: string | null; sessionKey?: string | null },
): { agentId: string; sessionKey?: string } {
  assertRawCronBinding(binding);
  const explicit = typeof binding.agentId === "string";
  const agentId = explicit ? normalizeAgentId(binding.agentId!) : resolveDefaultAgentId(cfg);
  if (explicit && !cfg.agents?.list?.some((entry) => normalizeAgentId(entry.id) === agentId)) {
    throw new Error("invalid cron binding: unknown agent");
  }
  if (binding.sessionKey == null) {
    return { agentId };
  }
  const requested = binding.sessionKey.trim();
  if (requested.toLowerCase() === "global") {
    throw new Error("invalid cron binding: global session");
  }
  const sessionKey = canonicalizeMainSessionAlias({
    cfg,
    agentId,
    sessionKey: toAgentStoreSessionKey({
      agentId,
      requestKey: requested,
      mainKey: cfg.session?.mainKey,
    }),
  });
  if (
    sessionKey === "global" ||
    normalizeAgentId(resolveAgentIdFromSessionKey(sessionKey)) !== agentId
  ) {
    throw new Error("invalid cron binding: session belongs to another agent");
  }
  return { agentId, sessionKey };
}
