import crypto from "node:crypto";
import {
  DeliveryQueueHealthError,
  isRecord,
  type QueuedDelivery,
  type QueuedDeliveryParams,
} from "./delivery-queue-types.js";

export type CallerRetention = {
  version: 1;
  owner: "alert-watcher";
  namespaceHash: string;
  receiptId: string;
  payloadHash: string;
  recipientHash: string;
  expiresAt: number;
};
export function canonicalJson(value: unknown): string {
  if (value === undefined) {
    return "null";
  }
  if (Array.isArray(value)) {
    return `[${value.map(canonicalJson).join(",")}]`;
  }
  if (value !== null && typeof value === "object") {
    return `{${Object.entries(value)
      .filter(([, v]) => v !== undefined)
      .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
      .map(([k, v]) => `${JSON.stringify(k)}:${canonicalJson(v)}`)
      .join(",")}}`;
  }
  const serialized = JSON.stringify(value);
  if (serialized === undefined) {
    throw new DeliveryQueueHealthError("Unsupported canonical value");
  }
  return serialized;
}
export function retentionHash(value: unknown): string {
  return crypto.createHash("sha256").update(canonicalJson(value)).digest("hex");
}
export function recipientBinding(
  entry: Pick<QueuedDeliveryParams, "channel" | "accountId" | "to">,
): string {
  return retentionHash([entry.channel, entry.accountId ?? "default", entry.to]);
}
export function parseCallerRetention(
  value: unknown,
  entry: Pick<
    QueuedDelivery,
    "id" | "completionPolicy" | "channel" | "accountId" | "to" | "payloads"
  >,
): CallerRetention | undefined {
  if (value === undefined) {
    return undefined;
  }
  if (
    !isRecord(value) ||
    Object.keys(value).sort().join(",") !==
      "expiresAt,namespaceHash,owner,payloadHash,receiptId,recipientHash,version" ||
    value.version !== 1 ||
    value.owner !== "alert-watcher" ||
    entry.completionPolicy !== "caller" ||
    value.receiptId !== entry.id ||
    typeof value.receiptId !== "string" ||
    !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(
      value.receiptId,
    ) ||
    !Number.isSafeInteger(value.expiresAt) ||
    (value.expiresAt as number) <= 0
  ) {
    throw new DeliveryQueueHealthError("Invalid caller retention binding");
  }
  for (const key of ["namespaceHash", "payloadHash", "recipientHash"] as const) {
    if (typeof value[key] !== "string" || !/^[a-f0-9]{64}$/.test(value[key])) {
      throw new DeliveryQueueHealthError("Invalid caller retention hash");
    }
  }
  if (
    value.recipientHash !== recipientBinding(entry) ||
    value.payloadHash !== retentionHash(entry.payloads.map((p) => p.payload))
  ) {
    throw new DeliveryQueueHealthError("Mismatched caller retention binding");
  }
  return value as CallerRetention;
}
