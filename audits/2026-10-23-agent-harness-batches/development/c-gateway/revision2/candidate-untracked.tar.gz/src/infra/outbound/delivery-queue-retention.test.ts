import crypto from "node:crypto";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { afterEach, it, expect, vi } from "vitest";
import {
  initializeGlobalHookRunner,
  resetGlobalHookRunner,
} from "../../plugins/hook-runner-global.js";
import {
  acquireDeliveryEntryLease,
  releaseDeliveryQueueLease,
  readQueuedDelivery,
  readDeliveryTombstone,
  resolveEntryPath,
} from "./delivery-queue-files.js";
import { recoverPendingDeliveries } from "./delivery-queue-recovery.js";
import { enqueueDelivery, checkpointQueuedPayload } from "./delivery-queue-store.js";
import { recipientBinding, retentionHash } from "./delivery-retention.js";
const dirs: string[] = [];
afterEach(() => {
  resetGlobalHookRunner();
  vi.restoreAllMocks();
  for (const d of dirs.splice(0)) {
    fs.rmSync(d, { recursive: true, force: true });
  }
});
function dir() {
  const d = fs.mkdtempSync(path.join(os.tmpdir(), "queue-retention-"));
  dirs.push(d);
  return d;
}
function params(expiresAt: number) {
  const id = crypto.randomUUID(),
    payloads = [{ text: "private body" }],
    target = { channel: "telegram" as const, accountId: "default", to: "private-owner" };
  return {
    id,
    ...target,
    payloads,
    completionPolicy: "caller" as const,
    callerRetention: {
      version: 1 as const,
      owner: "alert-watcher" as const,
      namespaceHash: retentionHash("n"),
      receiptId: id,
      payloadHash: retentionHash(payloads),
      recipientHash: recipientBinding(target),
      expiresAt,
    },
  };
}
const log = { info: () => {}, warn: () => {}, error: () => {} };
it("generic recovery before watcher startup expires an unredacted caller entry and fences reenqueues", async () => {
  const stateDir = dir(),
    p = params(Date.now() - 1);
  await enqueueDelivery(p, stateDir);
  expect(fs.readFileSync(resolveEntryPath(p.id, stateDir), "utf8")).toContain("private body");
  const deliver = vi.fn();
  await recoverPendingDeliveries({ stateDir, cfg: {}, log, deliver, delay: async () => {} });
  expect(deliver).not.toHaveBeenCalled();
  const tombstone = await readDeliveryTombstone(p.id, stateDir);
  expect(tombstone?.reason).toBe("expired");
  expect(JSON.stringify(tombstone)).not.toContain("private");
  expect(fs.existsSync(resolveEntryPath(p.id, stateDir))).toBe(false);
  await expect(
    enqueueDelivery(
      { ...p, callerRetention: { ...p.callerRetention, expiresAt: Date.now() + 100000 } },
      stateDir,
    ),
  ).rejects.toThrow();
});
it("retains acceptedAt and uncertain evidence while deleting expired content", async () => {
  const stateDir = dir(),
    p = params(Date.now() + 10000);
  await enqueueDelivery(p, stateDir);
  const lease = await acquireDeliveryEntryLease(p.id, stateDir);
  let entry = await readQueuedDelivery(p.id, stateDir);
  entry = await checkpointQueuedPayload({
    id: entry.id,
    payloadId: entry.payloads[0].id,
    expectedGeneration: entry.generation,
    nextState: "in-flight",
    stateDir,
    lease,
  });
  entry = await checkpointQueuedPayload({
    id: entry.id,
    payloadId: entry.payloads[0].id,
    expectedGeneration: entry.generation,
    nextState: "accepted",
    providerMessageIds: ["private-provider-id"],
    stateDir,
    lease,
  });
  const acceptedAt = entry.payloads[0].acceptedAt;
  await releaseDeliveryQueueLease(lease);
  const raw = JSON.parse(fs.readFileSync(resolveEntryPath(p.id, stateDir), "utf8"));
  raw.callerRetention.expiresAt = Date.now() - 1;
  fs.writeFileSync(resolveEntryPath(p.id, stateDir), JSON.stringify(raw));
  const deliver = vi.fn();
  await recoverPendingDeliveries({ stateDir, cfg: {}, log, deliver, delay: async () => {} });
  expect((await readDeliveryTombstone(p.id, stateDir))?.payloads[0]).toMatchObject({
    state: "accepted",
    acceptedAt,
  });
  expect(JSON.stringify(await readDeliveryTombstone(p.id, stateDir))).not.toContain(
    "private-provider-id",
  );
  expect(
    (await readDeliveryTombstone(p.id, stateDir))?.payloads[0].receipt?.providerMessageIds[0],
  ).toMatch(/^[a-f0-9]{64}$/);
  expect(deliver).not.toHaveBeenCalled();
});
it("checks expiry again after backoff; unrelated callers keep their behavior", async () => {
  const stateDir = dir();
  let clock = Date.now();
  const spy = vi.spyOn(Date, "now").mockImplementation(() => clock);
  const p = params(clock + 1000);
  await enqueueDelivery(p, stateDir);
  const deliver = vi.fn(async () => ({
    delivery: { status: "failed" as const },
    durability: { status: "checkpointed" as const },
  }));
  await recoverPendingDeliveries({
    stateDir,
    cfg: {},
    log,
    deliver,
    delay: async () => {
      clock += 2000;
    },
  });
  expect(deliver).not.toHaveBeenCalled();
  expect(await readDeliveryTombstone(p.id, stateDir)).toBeDefined();
  await enqueueDelivery(
    { channel: "telegram", to: "ordinary", payloads: [{ text: "ordinary" }] },
    stateDir,
  );
  await recoverPendingDeliveries({ stateDir, cfg: {}, log, deliver, delay: async () => {} });
  expect(deliver).toHaveBeenCalledTimes(1);
  spy.mockRestore();
});
it("rejects malformed, unknown and mismatched guard metadata before queue admission", async () => {
  const stateDir = dir(),
    p = params(Date.now() + 1000);
  await expect(
    enqueueDelivery(
      { ...p, callerRetention: { ...p.callerRetention, payloadHash: retentionHash("other") } },
      stateDir,
    ),
  ).rejects.toThrow();
  await expect(enqueueDelivery({ ...p, completionPolicy: undefined }, stateDir)).rejects.toThrow();
});

it("actual provider path stops expired payload between chunks", async () => {
  const { setActivePluginRegistry } = await import("../../plugins/runtime.js");
  const { createTestRegistry, createOutboundTestPlugin } =
    await import("../../test-support/channel-plugins.js");
  const { deliverOutboundPayloadsWithOutcome } = await import("./deliver.js");
  let clock = Date.now();
  const date = vi.spyOn(Date, "now").mockImplementation(() => clock);
  const stateDir = dir(),
    p = params(clock + 1000);
  p.payloads = [{ text: "first|second" }];
  p.callerRetention.payloadHash = retentionHash(p.payloads);
  const send = vi.fn(async () => {
    clock += 2000;
    return { channel: "telegram" as const, messageId: "accepted-first-chunk" };
  });
  const plugin = createOutboundTestPlugin({
    id: "telegram",
    outbound: {
      deliveryMode: "direct",
      textChunkLimit: 2,
      chunker: (text) => text.split("|"),
      sendText: send,
      sendMedia: send,
    },
  });
  setActivePluginRegistry(createTestRegistry([{ pluginId: "telegram", plugin, source: "test" }]));
  await deliverOutboundPayloadsWithOutcome({
    cfg: { channels: { telegram: { botToken: "stub", textChunkLimit: 2 } } },
    channel: p.channel,
    to: p.to,
    accountId: p.accountId,
    payloads: p.payloads,
    queueId: p.id,
    completionPolicy: "caller",
    callerRetention: p.callerRetention,
    stateDir,
    durability: "required",
  });
  expect(send).toHaveBeenCalledTimes(1);
  expect((await readDeliveryTombstone(p.id, stateDir))?.payloads[0].state).toBe("uncertain");
  date.mockRestore();
});

it("tombstone fsync failure and cleanup failure both withhold send, then cleanup retries safely", async () => {
  const stateDir = dir(),
    p = params(Date.now() - 1);
  await enqueueDelivery(p, stateDir);
  const originalOpen = fs.promises.open.bind(fs.promises);
  const open = vi.spyOn(fs.promises, "open").mockImplementation(async (...args) => {
    const handle = await originalOpen(...args);
    if (String(args[0]).includes(".retained")) {
      handle.sync = async () => {
        throw Error("fsync fault");
      };
    }
    return handle;
  });
  const deliver = vi.fn();
  await recoverPendingDeliveries({ cfg: {}, stateDir, log, deliver });
  expect(deliver).not.toHaveBeenCalled();
  expect(fs.existsSync(resolveEntryPath(p.id, stateDir))).toBe(true);
  open.mockRestore();
  const originalUnlink = fs.promises.unlink.bind(fs.promises);
  const unlink = vi.spyOn(fs.promises, "unlink").mockImplementation(async (file) => {
    if (String(file) === resolveEntryPath(p.id, stateDir)) {
      throw Error("unlink fault");
    }
    return originalUnlink(file);
  });
  await recoverPendingDeliveries({ cfg: {}, stateDir, log, deliver });
  expect(await readDeliveryTombstone(p.id, stateDir)).toBeDefined();
  expect(fs.existsSync(resolveEntryPath(p.id, stateDir))).toBe(true);
  await expect(readQueuedDelivery(p.id, stateDir)).rejects.toThrow("tombstone");
  unlink.mockRestore();
  await recoverPendingDeliveries({ cfg: {}, stateDir, log, deliver });
  expect(fs.existsSync(resolveEntryPath(p.id, stateDir))).toBe(false);
  expect(deliver).not.toHaveBeenCalled();
});

it("actual asynchronous message_sending preparation cannot send a payload that expires while awaiting", async () => {
  const { setActivePluginRegistry } = await import("../../plugins/runtime.js");
  const { createTestRegistry, createOutboundTestPlugin } =
    await import("../../test-support/channel-plugins.js");
  const { deliverOutboundPayloadsWithOutcome } = await import("./deliver.js");
  let clock = Date.now();
  vi.spyOn(Date, "now").mockImplementation(() => clock);
  const stateDir = dir(),
    p = params(clock + 1000),
    send = vi.fn(async () => ({ channel: "telegram" as const, messageId: "must-not-send" }));
  const registry = createTestRegistry([
    {
      pluginId: "telegram",
      source: "test",
      plugin: createOutboundTestPlugin({
        id: "telegram",
        outbound: { deliveryMode: "direct", sendText: send, sendMedia: send },
      }),
    },
  ]);
  const preparation = vi.fn(async () => {
    await Promise.resolve();
    clock += 2000;
  });
  registry.typedHooks.push({
    pluginId: "fixture",
    hookName: "message_sending",
    source: "test",
    handler: preparation,
  });
  setActivePluginRegistry(registry);
  initializeGlobalHookRunner(registry);
  await deliverOutboundPayloadsWithOutcome({
    cfg: {},
    channel: p.channel,
    to: p.to,
    accountId: p.accountId,
    payloads: p.payloads,
    queueId: p.id,
    completionPolicy: "caller",
    callerRetention: p.callerRetention,
    stateDir,
    durability: "required",
  });
  expect(preparation).toHaveBeenCalledTimes(1);
  expect(send).not.toHaveBeenCalled();
  expect(await readDeliveryTombstone(p.id, stateDir)).toMatchObject({ reason: "expired" });
});

it("tombstones erase exact atomic backup/temp, failed mirror/error copies and preserve unrelated payloads", async () => {
  const { enforceDeliveryRetention, cleanupRetainedQueueFiles, resolveFailedDir } =
    await import("./delivery-queue-files.js");
  const stateDir = dir(),
    p = params(Date.now() - 1);
  await enqueueDelivery(p, stateDir);
  const raw = JSON.parse(fs.readFileSync(resolveEntryPath(p.id, stateDir), "utf8"));
  raw.mirror = { sessionKey: "private-session", text: "private mirror" };
  raw.lastError = "private error";
  const bytes = JSON.stringify(raw),
    canonical = resolveEntryPath(p.id, stateDir);
  fs.writeFileSync(canonical, bytes);
  const copies = [
    canonical + `.bak-${process.pid}-${crypto.randomUUID()}`,
    canonical + `.tmp-${process.pid}-${crypto.randomUUID()}`,
    path.join(resolveFailedDir(stateDir), `${p.id}.json`),
    path.join(resolveFailedDir(stateDir), `${p.id}.json.tmp-${process.pid}-${crypto.randomUUID()}`),
  ];
  for (const file of copies) {
    fs.writeFileSync(file, bytes);
  }
  const unrelated = [
    canonical + ".bak-not-a-writer",
    canonical + ".tmp-other",
    path.join(path.dirname(canonical), `${crypto.randomUUID()}.json`),
  ];
  for (const file of unrelated) {
    fs.writeFileSync(file, "unrelated live legacy bytes");
  }
  const lease = await acquireDeliveryEntryLease(p.id, stateDir);
  try {
    expect(
      await enforceDeliveryRetention(await readQueuedDelivery(p.id, stateDir), lease, stateDir),
    ).toBe(false);
  } finally {
    await releaseDeliveryQueueLease(lease);
  }
  for (const file of [canonical, ...copies]) {
    expect(fs.existsSync(file)).toBe(false);
  }
  for (const file of unrelated) {
    expect(fs.readFileSync(file, "utf8")).toBe("unrelated live legacy bytes");
  }
  expect(JSON.stringify(await readDeliveryTombstone(p.id, stateDir))).not.toContain("private");
  // A new exact-format leftover after a failed cleanup is retried using the
  // authoritative tombstone even when no canonical queue file remains.
  fs.writeFileSync(copies[0], bytes);
  const unlink = fs.promises.unlink.bind(fs.promises);
  const fault = vi.spyOn(fs.promises, "unlink").mockImplementation(async (file) => {
    if (String(file) === copies[0]) {
      throw Error("cleanup fault");
    }
    return unlink(file);
  });
  await expect(cleanupRetainedQueueFiles(stateDir)).rejects.toThrow("cleanup fault");
  await expect(readQueuedDelivery(p.id, stateDir)).rejects.toThrow("tombstone");
  fault.mockRestore();
  await cleanupRetainedQueueFiles(stateDir);
  expect(fs.existsSync(copies[0])).toBe(false);
  for (const file of unrelated) {
    expect(fs.existsSync(file)).toBe(true);
  }
});
