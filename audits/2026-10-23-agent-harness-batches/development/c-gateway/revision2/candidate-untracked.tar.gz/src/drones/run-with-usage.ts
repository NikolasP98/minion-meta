import { getModel } from "@earendil-works/pi-ai/compat";
import {
  runDrone,
  type Drone,
  type DroneHost,
  type DroneRunInput,
  type DroneRunResult,
  type DroneUsage,
} from "@minion-stack/drone";
import { emitEvent } from "../events/emitter.js";

export type TerminalObserver = {
  signal?: AbortSignal;
  attemptId: string;
  purpose: "classification" | "suggestion";
  /** Synchronous durable fence after SDK auth/preparation and before provider admission. */
  onDispatch?: () => void;
  onTerminal: (result: DroneRunResult<unknown>, usage: InvocationUsage) => void | Promise<void>;
};
export type InvocationUsage = {
  attemptId: string;
  purpose: TerminalObserver["purpose"];
  requestedModel: { provider: string; model: string };
  resolvedModel: { provider: string; model: string } | null;
  usage: DroneUsage;
  costStatus: "known" | "unknown";
  costUsd: number | null;
  costCoverage: "complete" | "incomplete";
  elapsedMs: number;
  dispatchStatus?: "not_submitted" | "may_have_submitted";
};
export function observeInvocation<T>(
  drone: Drone<T>,
  result: DroneRunResult<T>,
  observer: Pick<TerminalObserver, "attemptId" | "purpose">,
  dispatchStatus: NonNullable<InvocationUsage["dispatchStatus"]> = "may_have_submitted",
): InvocationUsage {
  const resolvedModel = result.ok ? result.resolvedModel : null;
  const usage = result.usage ?? {};
  const amounts = [
    usage.inputTokens,
    usage.outputTokens,
    usage.cacheReadTokens,
    usage.cacheCreationTokens,
  ];
  let costUsd: number | null = null;
  if (
    resolvedModel &&
    amounts.every((v) => typeof v === "number" && Number.isFinite(v) && v >= 0)
  ) {
    try {
      const model = getModel(resolvedModel.provider as never, resolvedModel.model as never);
      if (model && model.cost) {
        const rates = [
          model.cost.input,
          model.cost.output,
          model.cost.cacheRead,
          model.cost.cacheWrite,
        ];
        if (rates.every((r) => Number.isFinite(r) && r >= 0)) {
          costUsd = amounts.reduce<number>((sum, v, i) => sum + (v! * rates[i]) / 1_000_000, 0);
        }
      }
    } catch {
      /* Unknown models are not priced as defaults. */
    }
  }
  return {
    attemptId: observer.attemptId,
    purpose: observer.purpose,
    requestedModel: {
      provider: drone.definition.model.provider,
      model: drone.definition.model.model,
    },
    resolvedModel,
    usage,
    dispatchStatus,
    costStatus: dispatchStatus === "not_submitted" || costUsd !== null ? "known" : "unknown",
    costUsd: dispatchStatus === "not_submitted" ? 0 : costUsd,
    costCoverage:
      dispatchStatus === "not_submitted" ||
      (result.ok && costUsd !== null && !drone.definition.model.fallbacks?.length)
        ? "complete"
        : "incomplete",
    elapsedMs: result.durationMs,
  };
}
/** SDK lifecycle runs normally. Durable observer comes before best-effort analytics. */
export async function runDroneWithUsage<T>(
  drone: Drone<T>,
  input: DroneRunInput,
  host: DroneHost,
  observer?: TerminalObserver,
): Promise<DroneRunResult<T>> {
  if (!observer) {
    return runDrone(drone, input, host);
  }
  let prepared = false;
  const observedHost: DroneHost = {
    resolveApiKey: (spec) => host.resolveApiKey(spec),
    resolveSkillsPrompt: (filter) => {
      const prompt = host.resolveSkillsPrompt(filter);
      // Installed Drone0.6.0 returns NO_API_KEY before this callback. No provider
      // can start until this synchronous persistence fence has succeeded.
      observer.onDispatch?.();
      prepared = true;
      return prompt;
    },
    ...(host.emitEvent ? { emitEvent: (event) => host.emitEvent!(event) } : {}),
  };
  const result = await runDrone(drone, input, observedHost);
  const notSubmitted = !prepared && !result.ok && result.error.code === "NO_API_KEY";
  const observation = observeInvocation(
    drone,
    result,
    observer,
    notSubmitted ? "not_submitted" : "may_have_submitted",
  );
  await observer.onTerminal(result, observation);
  // Invocation history is not a provider bill or usage event.
  if (notSubmitted) {
    return result;
  }
  try {
    emitEvent({
      category: "agent",
      severity: "info",
      event: result.ok ? "agent.llm.usage" : "agent.llm.usage.unknown",
      message: "Drone terminal usage",
      correlationId: observer.attemptId,
      timestamp: Date.now(),
      metadata: {
        ...observation,
        kind: "drone",
        droneId: drone.definition.id,
        provider: observation.resolvedModel?.provider,
        model: observation.resolvedModel?.model,
        source: "system",
        channel: "drone",
        tokens: result.ok
          ? {
              input: result.usage.inputTokens,
              output: result.usage.outputTokens,
              cacheRead: result.usage.cacheReadTokens,
              cacheCreation: result.usage.cacheCreationTokens,
            }
          : undefined,
      },
    });
  } catch {
    /* Receipt, not analytics, is the accounting authority. */
  }
  return result;
}
