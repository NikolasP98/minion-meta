import crypto from "node:crypto";
import type { DatabaseSync } from "node:sqlite";
import type { InvocationUsage } from "../../../src/drones/run-with-usage.js";
import {
  assertWorkLease,
  boundedJson,
  type WorkLease,
  type WorkSnapshot,
} from "./classification-work.js";
import type { ModelIdentity } from "./complaint-evaluation.js";
import type { ApprovedShadowContext } from "./jev-shadow-eligibility.js";
export type GateDisposition = "forward" | "negative" | "abstain" | "unavailable";
export type ShadowReceipt = {
  state: "unavailable" | "admitted" | "received" | "indeterminate";
  revision: string;
  requestedModel: ModelIdentity;
  resolvedModel: ModelIdentity | null;
  disposition: GateDisposition;
  attemptId?: string;
  usage?: InvocationUsage;
};
export type TrustedShadowAdapter = {
  context: ApprovedShadowContext & { classifierModel: string; requestedGateModel: ModelIdentity };
  run: (input: {
    text: string;
    attemptId: string;
    signal: AbortSignal;
  }) => Promise<{ disposition: GateDisposition; usage: InvocationUsage }>;
};
export function qualifiedShadowContext(
  snapshot: Pick<WorkSnapshot, "model" | "policyHash">,
  adapter: TrustedShadowAdapter | undefined,
): boolean {
  const c = adapter?.context;
  return (
    !!c &&
    /^[a-f0-9]{64}$/.test(c.manifestHash) &&
    c.policyHash === snapshot.policyHash &&
    c.classifierModel === snapshot.model &&
    !!c.modelRevision &&
    c.modelRevision !== "unqualified" &&
    !!c.gateRevision &&
    c.expiresAt > Date.now() &&
    Number.isFinite(c.remainingExposureUsd) &&
    Number.isFinite(c.maxInvocationCostUsd) &&
    c.maxInvocationCostUsd >= 0 &&
    c.remainingExposureUsd >= c.maxInvocationCostUsd
  );
}
/** Software shadow mode cannot acquire this trusted adapter through plugin config or RPC. */
export async function completeShadowReceipt(
  db: DatabaseSync,
  lease: WorkLease,
  snapshot: WorkSnapshot,
  signal: AbortSignal,
  adapter?: TrustedShadowAdapter,
): Promise<void> {
  const row = assertWorkLease(db, lease) as ReturnType<typeof assertWorkLease> & {
    shadow_json: string;
  };
  const previous = JSON.parse(row.shadow_json) as ShadowReceipt | null;
  if (previous) {
    return;
  }
  const unavailable: ShadowReceipt = {
    state: "unavailable",
    revision: "unavailable",
    requestedModel: { provider: "unavailable", model: "unavailable", revision: "unqualified" },
    resolvedModel: null,
    disposition: "unavailable",
  };
  const save = (value: ShadowReceipt) => {
    assertWorkLease(db, lease);
    db.prepare(
      "UPDATE classification_work SET shadow_json=?,receipt_revision=receipt_revision+1 WHERE id=?",
    ).run(boundedJson(value, 16384), lease.id);
  };
  if (
    snapshot.mode !== "shadow" ||
    snapshot.customPolicy ||
    !qualifiedShadowContext(snapshot, adapter)
  ) {
    if (snapshot.mode === "shadow") {
      save(unavailable);
    }
    return;
  }
  const approved = adapter!,
    attemptId = crypto.randomUUID();
  const admitted: ShadowReceipt = {
    state: "admitted",
    revision: approved.context.gateRevision,
    requestedModel: approved.context.requestedGateModel,
    resolvedModel: null,
    disposition: "unavailable",
    attemptId,
  };
  save(admitted); // One durable SDK admission, before the injected adapter can invoke anything.
  const timeout = new AbortController(),
    timer = setTimeout(() => timeout.abort(), 15000);
  timer.unref();
  const combined = AbortSignal.any([signal, timeout.signal]);
  try {
    const response = await Promise.race([
      approved.run({ text: snapshot.source.text, attemptId, signal: combined }),
      new Promise<never>((_, reject) =>
        combined.addEventListener("abort", () => reject(Error("gate_timeout")), { once: true }),
      ),
    ]);
    if (response.usage.attemptId !== attemptId) {
      throw Error("gate_receipt_mismatch");
    }
    const cost = response.usage.costUsd;
    const decision =
      ["forward", "negative", "abstain"].includes(response.disposition) &&
      response.usage.costStatus === "known" &&
      cost !== null &&
      Number.isFinite(cost) &&
      cost >= 0 &&
      cost <= approved.context.maxInvocationCostUsd
        ? response.disposition
        : "unavailable";
    save({
      ...admitted,
      state: "received",
      disposition: decision,
      usage: response.usage,
      resolvedModel: response.usage.resolvedModel
        ? {
            ...response.usage.resolvedModel,
            revision:
              response.usage.resolvedModel.provider ===
                approved.context.requestedGateModel.provider &&
              response.usage.resolvedModel.model === approved.context.requestedGateModel.model
                ? approved.context.requestedGateModel.revision
                : "unqualified",
          }
        : null,
    });
  } catch {
    save({ ...admitted, state: "indeterminate", disposition: "unavailable" });
  } finally {
    clearTimeout(timer);
  }
}
