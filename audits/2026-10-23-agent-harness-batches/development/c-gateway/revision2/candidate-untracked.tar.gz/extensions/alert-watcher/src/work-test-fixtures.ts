import path from "node:path";
import { DatabaseSync } from "node:sqlite";
import {
  admitSource,
  claimWork,
  admitInvocation,
  receiveInvocation,
  materializePositive,
  finishWork,
} from "./classification-work.js";
import type { WorkSnapshot } from "./classification-work.js";
import { snapshotHash } from "./provenance.js";
import { initReplySchema } from "./reply-flow/store.js";
import { initSchema } from "./store.js";
export function testDb(file = ":memory:"): DatabaseSync {
  const db = new DatabaseSync(file);
  initSchema(db);
  initReplySchema(db);
  return db;
}
export function workFixture(overrides: Partial<WorkSnapshot> = {}): WorkSnapshot {
  const destinations: WorkSnapshot["destinations"] = overrides.destinations ?? [
    { channel: "telegram", accountId: "default", to: "owner" },
  ];
  const authority = overrides.authority ?? {
    kind: "local_unscoped" as const,
    source: "json_config" as const,
    evidenceHash: snapshotHash("authority"),
  };
  return {
    source: {
      channel: "telegram",
      accountId: "default",
      conversationId: "chat",
      messageId: "message",
      senderId: "customer",
      text: "  broken product \n",
    },
    authority: {
      kind: "local_unscoped",
      source: "json_config",
      evidenceHash: snapshotHash("authority"),
    },
    model: "claude-haiku-4-5",
    language: "es",
    overrides: {},
    minSeverity: "low",
    cooldown: { enabled: false, maxMessages: 12, windowMinutes: 30 },
    destinations,
    destinationAuthorities: Object.fromEntries(
      destinations.map((recipient) => [
        snapshotHash([recipient.channel, recipient.accountId ?? "default", recipient.to]),
        authority,
      ]),
    ),
    replyFlow: {
      enabled: true,
      windowMs: 3600000,
      notifyLoser: true,
      suggestions: { enabled: false, count: 3, maxChars: 140 },
    },
    mode: "census",
    policyHash: snapshotHash("policy"),
    defaultPolicyHash: snapshotHash("policy"),
    customPolicy: false,
    ...overrides,
  };
}

export function positiveFixture(dir: string, destinations = workFixture().destinations) {
  const db = testDb(path.join(dir, "alerts.db")),
    snapshot = workFixture({ destinations });
  const work = admitSource(db, "namespace", snapshot);
  if (work.kind !== "admitted") {
    throw Error();
  }
  const lease = claimWork(db, work.work.id, "owner")!,
    attemptId = admitInvocation(db, lease),
    result = {
      is_complaint: true,
      severity: "high" as const,
      category: "other" as const,
      summary: "broken",
    };
  receiveInvocation(
    db,
    lease,
    {
      ok: true,
      data: result,
      usage: {},
      durationMs: 1,
      resolvedModel: { provider: "anthropic", model: snapshot.model },
    },
    {
      attemptId,
      purpose: "classification",
      requestedModel: { provider: "anthropic", model: snapshot.model },
      resolvedModel: { provider: "anthropic", model: snapshot.model },
      usage: {},
      costStatus: "unknown",
      costUsd: null,
      costCoverage: "incomplete",
      elapsedMs: 1,
    },
  );
  materializePositive(db, lease, result, "private alert", destinations);
  finishWork(db, lease, "completed");
  return { db, snapshot, id: work.work.id };
}
