import fs from "node:fs";
import { Ajv } from "ajv";
import { it, expect, vi } from "vitest";
import {
  admitSource,
  claimWork,
  admitInvocation,
  receiveInvocation,
  finishWork,
} from "./classification-work.js";
import { exportComplaintEvaluation } from "./complaint-evaluation.js";
import { complaintEligibility, runComplaintShadow } from "./jev-shadow-eligibility.js";
import { testDb, workFixture } from "./work-test-fixtures.js";
const eligible = {
  mode: "census" as const,
  enabled: true,
  matched: true,
  certified: true,
  customPolicy: false,
  modelQualified: true,
  bindingValid: true,
};
it("qualifies certified reviewed defaults and bypasses custom, missing originals and model drift", () => {
  expect(complaintEligibility(eligible)).toEqual({ status: "eligible", reason: "eligible" });
  for (const [patch, reason] of [
    [{ customPolicy: true }, "custom_policy"],
    [{ certified: false }, "uncertified_source"],
    [{ modelQualified: false }, "model_drift"],
    [{ bindingValid: false }, "invalid_binding"],
    [{ mode: "off" }, "mode_off"],
  ] as const) {
    expect(complaintEligibility({ ...eligible, ...patch })).toHaveProperty("reason", reason);
  }
});
it("software config does not grant paid admission; missing or unbounded context is unavailable", async () => {
  const adapter = vi.fn(async () => "negative" as const);
  expect(
    await runComplaintShadow(undefined, { policyHash: "x", modelRevision: "x" }, adapter),
  ).toBe("unavailable");
  expect(adapter).not.toHaveBeenCalled();
});
it("durable exporter uses monotonic revisions, schema validity and stable single-source identity", () => {
  const db = testDb();
  const work = admitSource(db, "namespace", workFixture());
  if (work.kind !== "admitted") {
    throw Error();
  }
  const initial = exportComplaintEvaluation(db, work.work.id);
  const lease = claimWork(db, work.work.id, "owner")!,
    attemptId = admitInvocation(db, lease);
  const admitted = exportComplaintEvaluation(db, work.work.id);
  expect(admitted.receiptRevision).toBeGreaterThan(initial.receiptRevision);
  const result = {
    ok: false as const,
    error: { code: "SCHEMA_INVALID" as const, message: "stub" },
    usage: { inputTokens: 10, outputTokens: 5 },
    durationMs: 5,
  };
  receiveInvocation(db, lease, result, {
    attemptId,
    purpose: "classification",
    requestedModel: { provider: "anthropic", model: workFixture().model },
    resolvedModel: null,
    usage: result.usage,
    costStatus: "unknown",
    costUsd: null,
    costCoverage: "incomplete",
    elapsedMs: 5,
  });
  finishWork(db, lease, "failed", "SCHEMA_INVALID");
  const terminal = exportComplaintEvaluation(db, work.work.id);
  expect(terminal.receiptRevision).toBeGreaterThan(admitted.receiptRevision);
  expect(terminal.recordId).toBe(initial.recordId);
  expect(terminal.logicalSourceId).toBe(initial.logicalSourceId);
  expect(terminal.baseline.disposition).toBe("failed");
  expect(terminal.attempts[0]).toMatchObject({ attemptId, costStatus: "unknown", costUsd: null });
  const schema = JSON.parse(
    fs.readFileSync(new URL("./complaint-evaluation.schema.json", import.meta.url), "utf8"),
  );
  const ajv = new Ajv({ strict: false, validateFormats: false });
  const validate = ajv.compile(schema);
  expect(validate(terminal), JSON.stringify(validate.errors)).toBe(true);
  expect(exportComplaintEvaluation(db, work.work.id)).toEqual(terminal);
  db.close();
});
