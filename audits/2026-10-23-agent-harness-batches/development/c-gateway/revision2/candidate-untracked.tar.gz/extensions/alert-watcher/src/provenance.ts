import { canonicalJson, retentionHash } from "../../../src/infra/outbound/delivery-retention.js";
import type {
  CanonicalTransportSourceUnit,
  TransportSourceProvenance,
} from "../../../src/plugins/types/hooks.js";
export { canonicalJson as canonicalSnapshot, retentionHash as snapshotHash };
export const WATCHER_POLICY_ID = "alert-watcher:default";
export function certifiedOriginals(
  provenance: TransportSourceProvenance | undefined,
  context: { channel: string; accountId: string; conversationId: string },
): readonly CanonicalTransportSourceUnit[] | null {
  if (
    !provenance ||
    provenance.version !== 1 ||
    !Array.isArray(provenance.sources) ||
    !provenance.sources.length ||
    provenance.sources.length > 256 ||
    context.channel !== "telegram"
  ) {
    return null;
  }
  if (
    provenance.sources.some(
      (s) =>
        !s ||
        s.channel !== context.channel ||
        s.accountId !== context.accountId ||
        s.conversationId !== context.conversationId ||
        !s.messageId ||
        typeof s.messageId !== "string" ||
        typeof s.text !== "string" ||
        (s.providerRevision !== undefined &&
          (typeof s.providerRevision !== "string" || !s.providerRevision)),
    )
  ) {
    return null;
  }
  return provenance.sources;
}
export function sourceIdentity(source: CanonicalTransportSourceUnit): string {
  return canonicalJson([
    1,
    source.channel,
    source.accountId,
    source.conversationId,
    source.messageId,
    source.providerRevision ?? null,
  ]);
}
export function admissionIdentity(
  namespace: string,
  source: CanonicalTransportSourceUnit,
  generation = 0,
): string {
  return retentionHash([1, namespace, WATCHER_POLICY_ID, sourceIdentity(source), generation]);
}

export function classifierInput(text: string): { prompt: string; maxTokens: number } {
  return { prompt: `Message to classify:\n"${text}"`, maxTokens: 256 };
}
