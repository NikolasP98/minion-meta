import crypto from "node:crypto";
import type { DatabaseSync } from "node:sqlite";
import { createGatewayDroneHost } from "../../../src/drones/host.js";
import type { MinionPluginApi } from "../../../src/plugins/types.js";
import type { PluginHookMessageMetadata } from "../../../src/plugins/types/hooks.js";
import type { ResolvedConfig } from "../index.js";
import { resolveWatcherAuthority, sameAuthority } from "./authority.js";
import {
  admitSource,
  admitInvocation,
  receiveInvocation,
  markInvocationDispatch,
  markSuggestionDispatch,
  getWork,
  createWorkDispatcher,
  assertWorkLease,
  observeWorkAuthority,
  retryNoCredentials,
  finishWork,
  setSuggestion,
  materializePositive,
  type WorkLease,
  type WorkSnapshot,
  type SuggestionReceipt,
  type WorkRow,
} from "./classification-work.js";
import { buildClassifierDrone, classifyMessage } from "./classifier.js";
import { drainDeliveryReceipts } from "./delivery-bridge.js";
import { certifiedOriginals, snapshotHash } from "./provenance.js";
import { appendSuggestionsBlock } from "./reply-flow/format.js";
import { runSuggestionsDrone } from "./reply-flow/suggestions-drone.js";
import {
  completeShadowReceipt,
  qualifiedShadowContext,
  type TrustedShadowAdapter,
} from "./shadow-receipt.js";
import { matchesChannelSub, matchesAgentSub } from "./subscriptions.js";
import type { ComplaintResult } from "./types.js";

const severity = { low: 0, med: 1, high: 2 };
async function boundedOperation<T>(
  parent: AbortSignal,
  operation: (signal: AbortSignal) => Promise<T>,
  timeoutMs = 30000,
): Promise<T> {
  const controller = new AbortController(),
    timer = setTimeout(() => controller.abort(), timeoutMs);
  timer.unref();
  const signal = AbortSignal.any([parent, controller.signal]);
  let rejectAbort: () => void = () => {};
  const aborted = new Promise<never>((_, reject) => {
    rejectAbort = () => reject(new Error("operation_interrupted"));
    if (signal.aborted) {
      rejectAbort();
    } else {
      signal.addEventListener("abort", rejectAbort, { once: true });
    }
  });
  try {
    return await Promise.race([operation(signal), aborted]);
  } finally {
    clearTimeout(timer);
    signal.removeEventListener("abort", rejectAbort);
  }
}
export function createCertifiedWatcher(
  api: MinionPluginApi,
  db: DatabaseSync,
  stateDir: string,
  config: () => ResolvedConfig,
  format: (snapshot: WorkSnapshot, result: ComplaintResult) => string,
  trustedShadow?: TrustedShadowAdapter,
) {
  const namespace = snapshotHash(["alert-watcher", stateDir]);
  const currentConfig = () => api.runtime.config?.loadConfig?.() ?? api.config;
  const authority = (s: WorkSnapshot) => {
    const current = config();
    if (
      !matchesChannelSub(current.subscriptions, {
        channel: s.source.channel,
        accountId: s.source.accountId,
      }) &&
      !matchesAgentSub(current.subscriptions, s.agentId)
    ) {
      return Promise.resolve({ kind: "unavailable" as const, reason: "policy_unmatched" });
    }
    return resolveWatcherAuthority(currentConfig(), s.source.channel, s.source.accountId);
  };
  const stillAuthorized = async (lease: WorkLease, s: WorkSnapshot) => {
    const current = await authority(s);
    return observeWorkAuthority(db, assertWorkLease(db, lease), s, current);
  };
  function suppressed(snapshot: WorkSnapshot, result: ComplaintResult, row: WorkRow): boolean {
    if (!snapshot.cooldown.enabled) {
      return false;
    }
    const recent = db
      .prepare(
        "SELECT * FROM classification_work WHERE namespace=? AND first_sent_at IS NOT NULL ORDER BY first_sent_at DESC LIMIT 5000",
      )
      .all(namespace) as WorkRow[];
    for (const previous of recent) {
      if (!previous.snapshot) {
        continue;
      }
      const p = JSON.parse(previous.snapshot) as WorkSnapshot;
      if (
        snapshotHash([
          p.source.channel,
          p.source.accountId,
          p.source.conversationId,
          p.source.senderId ?? "unknown",
        ]) !==
        snapshotHash([
          snapshot.source.channel,
          snapshot.source.accountId,
          snapshot.source.conversationId,
          snapshot.source.senderId ?? "unknown",
        ])
      ) {
        continue;
      }
      const elapsed = Date.now() - previous.first_sent_at!;
      if (elapsed >= snapshot.cooldown.windowMinutes * 60000) {
        return false;
      }
      const originals = db
        .prepare(
          "SELECT snapshot FROM classification_work WHERE namespace=? AND source_counted_at>=? AND source_counted_at<=? AND id!=?",
        )
        .all(namespace, previous.first_sent_at!, row.source_counted_at, previous.id) as Array<{
        snapshot: string | null;
      }>;
      const count = originals.filter((r) => {
        if (!r.snapshot) {
          return false;
        }
        const source = (JSON.parse(r.snapshot) as WorkSnapshot).source;
        return (
          snapshotHash([
            source.channel,
            source.accountId,
            source.conversationId,
            source.senderId ?? "unknown",
          ]) ===
          snapshotHash([
            snapshot.source.channel,
            snapshot.source.accountId,
            snapshot.source.conversationId,
            snapshot.source.senderId ?? "unknown",
          ])
        );
      }).length;
      const terminal = JSON.parse(previous.terminal_result ?? "null");
      return (
        count < snapshot.cooldown.maxMessages &&
        !(
          snapshot.cooldown.allowEscalation !== false &&
          severity[result.severity] > severity[terminal?.data?.severity as keyof typeof severity]
        )
      );
    }
    return false;
  }
  async function process(lease: WorkLease, signal: AbortSignal) {
    let row = assertWorkLease(db, lease);
    if (!row.snapshot) {
      throw new Error("missing_snapshot");
    }
    const snapshot = JSON.parse(row.snapshot) as WorkSnapshot;
    if (signal.aborted) {
      throw new Error("work_stopped");
    }
    if (!(await stillAuthorized(lease, snapshot))) {
      finishWork(db, lease, "canceled", "authority_unavailable");
      return;
    }
    if (row.state === "queued") {
      const attemptId = admitInvocation(db, lease);
      const host = createGatewayDroneHost({ config: currentConfig(), usageMode: "result" });
      const timeoutController = new AbortController();
      const deadline = setTimeout(() => timeoutController.abort(), 30000);
      deadline.unref();
      const combined = AbortSignal.any([signal, timeoutController.signal]);
      try {
        await Promise.race([
          classifyMessage(
            [{ role: "user", content: snapshot.source.text, ts: row.created_at }],
            host,
            snapshot.model,
            combined,
            snapshot.language,
            snapshot.overrides,
            {
              attemptId,
              purpose: "classification",
              onDispatch: () => markInvocationDispatch(db, lease, attemptId),
              onTerminal: (result, usage) => receiveInvocation(db, lease, result, usage),
            },
          ),
          new Promise<never>((_, reject) =>
            combined.addEventListener(
              "abort",
              () => reject(new Error("classification_interrupted")),
              { once: true },
            ),
          ),
        ]);
      } catch {
        if (getWork(db, row.id)?.state !== "received") {
          throw new Error("classification_receipt_missing");
        }
      } finally {
        clearTimeout(deadline);
      }

      row = assertWorkLease(db, lease);
    }
    const terminal = JSON.parse(row.terminal_result ?? "null") as {
      ok: boolean;
      data?: ComplaintResult;
      error?: { code: string };
    } | null;
    if (!terminal) {
      finishWork(db, lease, "failed", "missing_terminal_result");
      return;
    }
    if (!terminal.ok) {
      if (terminal.error?.code === "NO_API_KEY") {
        retryNoCredentials(db, lease);
        return;
      }
      finishWork(db, lease, "failed", terminal.error?.code ?? "invalid_sdk_result");
      return;
    }
    if (signal.aborted) {
      throw new Error("work_stopped");
    }
    if (!(await stillAuthorized(lease, snapshot))) {
      finishWork(db, lease, "canceled", "authority_unavailable");
      return;
    }
    await completeShadowReceipt(db, lease, snapshot, signal, trustedShadow);
    const result = terminal.data;
    if (
      !result ||
      typeof result.is_complaint !== "boolean" ||
      !(result.severity in severity) ||
      typeof result.category !== "string" ||
      typeof result.summary !== "string"
    ) {
      finishWork(db, lease, "failed", "invalid_classification");
      return;
    }
    if (signal.aborted) {
      throw new Error("work_stopped");
    }
    if (!(await stillAuthorized(lease, snapshot))) {
      finishWork(db, lease, "canceled", "authority_unavailable");
      return;
    }
    if (
      !result.is_complaint ||
      severity[result.severity] < severity[snapshot.minSeverity] ||
      suppressed(snapshot, result, row)
    ) {
      finishWork(db, lease, "completed");
      return;
    }
    let suggestion = JSON.parse(row.suggestion_json) as SuggestionReceipt;
    if (suggestion.state === "not_requested") {
      if (snapshot.replyFlow.enabled && snapshot.replyFlow.suggestions.enabled) {
        setSuggestion(db, lease, { state: "queued" });
        suggestion = { state: "queued" };
      } else {
        suggestion = { state: "received", suggestions: [] };
        setSuggestion(db, lease, suggestion);
      }
    }
    if (suggestion.state === "queued") {
      if (signal.aborted) {
        throw new Error("work_stopped");
      }
      if (!(await stillAuthorized(lease, snapshot))) {
        finishWork(db, lease, "canceled", "authority_unavailable");
        return;
      }
      const attemptId = crypto.randomUUID();
      suggestion = { state: "admitted", attemptId, dispatchStatus: "preparing" };
      setSuggestion(db, lease, suggestion);
      try {
        await boundedOperation(signal, (suggestionSignal) =>
          runSuggestionsDrone(
            createGatewayDroneHost({ config: currentConfig(), usageMode: "result" }),
            snapshot.model,
            {
              language: snapshot.language,
              severity: result.severity,
              category: result.category,
              summary: result.summary,
              senderMessage: snapshot.source.text,
              systemPrompt: snapshot.overrides.systemPrompt ?? "",
              count: snapshot.replyFlow.suggestions.count,
              maxChars: snapshot.replyFlow.suggestions.maxChars,
            },
            {
              attemptId,
              purpose: "suggestion",
              onDispatch: () => markSuggestionDispatch(db, lease, attemptId),
              signal: suggestionSignal,
              onTerminal: (terminalResult, usage) => {
                if (suggestionSignal.aborted) {
                  throw new Error("suggestion_interrupted");
                }
                const replies = terminalResult.ok
                  ? (terminalResult.data as { replies?: unknown }).replies
                  : undefined;
                const suggestions = Array.isArray(replies)
                  ? replies
                      .filter((s): s is string => typeof s === "string")
                      .map((s) => s.trim())
                      .filter(Boolean)
                      .slice(0, snapshot.replyFlow.suggestions.count)
                  : [];
                setSuggestion(db, lease, {
                  state: "received",
                  attemptId,
                  result: terminalResult,
                  usage,
                  suggestions,
                  ...(!terminalResult.ok ? { reason: "suggestions_unavailable" } : {}),
                });
              },
            },
          ),
        );
      } catch {
        const latest = JSON.parse(getWork(db, row.id)!.suggestion_json) as SuggestionReceipt;
        if (latest.state !== "received") {
          setSuggestion(db, lease, {
            state: "indeterminate",
            attemptId,
            suggestions: [],
            reason: "suggestions_unavailable",
          });
        }
      }
      row = assertWorkLease(db, lease);
      suggestion = JSON.parse(row.suggestion_json) as SuggestionReceipt;
    }
    if (signal.aborted) {
      throw new Error("work_stopped");
    }
    if (!(await stillAuthorized(lease, snapshot))) {
      finishWork(db, lease, "canceled", "authority_unavailable");
      return;
    }
    let text = format(snapshot, result);
    if (snapshot.replyFlow.enabled) {
      text = appendSuggestionsBlock(text, suggestion.suggestions ?? [], snapshot.language);
    }
    if (suggestion.reason) {
      text +=
        snapshot.language === "es" ? "\nSugerencias no disponibles." : "\nSuggestions unavailable.";
    }
    const configured = config().destinations;
    const recipients = snapshot.destinations.filter((d) =>
      configured.some(
        (c) =>
          snapshotHash([c.channel, c.accountId ?? "default", c.to]) ===
          snapshotHash([d.channel, d.accountId ?? "default", d.to]),
      ),
    );
    materializePositive(db, lease, result, text, recipients);
    finishWork(db, lease, "completed");
  }
  const dispatcher = createWorkDispatcher(db, {
    authority,
    process,
    deliver: (signal) =>
      drainDeliveryReceipts(db, {
        stateDir,
        signal,
        config: currentConfig,
        recipientAllowed: async (snapshot, recipient) => {
          const bound =
            snapshot.destinationAuthorities?.[
              snapshotHash([recipient.channel, recipient.accountId ?? "default", recipient.to])
            ];
          if (!bound) {
            return false;
          }
          const current = await resolveWatcherAuthority(
            currentConfig(),
            recipient.channel,
            recipient.accountId ?? "default",
          );
          return sameAuthority(bound, current);
        },
        authority,
        destinations: () => config().destinations,
      }),
    onError: () =>
      api.logger.warn("alert-watcher: durable work processing failed; receipt retained"),
  });
  return {
    async admit(
      event: {
        channel: string;
        accountId: string;
        chatId: string;
        metadata?: PluginHookMessageMetadata;
      },
      agentId?: string,
    ): Promise<boolean> {
      const sources = certifiedOriginals(event.metadata?.sourceProvenance, {
        channel: event.channel,
        accountId: event.accountId,
        conversationId: event.chatId,
      });
      if (!sources) {
        return false;
      }
      for (const source of sources) {
        const cfg = config();
        const resolved = await resolveWatcherAuthority(
          currentConfig(),
          source.channel,
          source.accountId,
        );
        if (resolved.kind === "unavailable") {
          continue;
        }
        const overrides = {
          systemPrompt: cfg.classifier.systemPrompt,
          severityRubric: cfg.classifier.severityRubric,
          categories: cfg.classifier.categories,
        };
        const policyHash = snapshotHash(
          buildClassifierDrone(cfg.classifier.model, cfg.language, overrides).definition,
        );
        const defaultPolicyHash = snapshotHash(
          buildClassifierDrone(cfg.classifier.model, cfg.language, undefined).definition,
        );
        const destinationAuthorities: NonNullable<WorkSnapshot["destinationAuthorities"]> = {};
        for (const recipient of cfg.destinations) {
          const target = await resolveWatcherAuthority(
            currentConfig(),
            recipient.channel,
            recipient.accountId ?? "default",
          );
          if (target.kind === "unavailable") {
            continue;
          }
          if (
            resolved.kind === "scoped" &&
            target.kind === "scoped" &&
            snapshotHash(resolved.orgIds) !== snapshotHash(target.orgIds)
          ) {
            continue;
          }
          destinationAuthorities[
            snapshotHash([recipient.channel, recipient.accountId ?? "default", recipient.to])
          ] = target;
        }
        admitSource(db, namespace, {
          source,
          authority: resolved,
          agentId,
          model: cfg.classifier.model,
          language: cfg.language,
          overrides,
          minSeverity: cfg.classifier.minSeverity,
          cooldown: cfg.cooldown,
          destinations: cfg.destinations,
          destinationAuthorities,
          replyFlow: cfg.replyFlow,
          mode: cfg.complaintExperiment.mode,
          policyHash,
          defaultPolicyHash,
          qualifiedModelRevision: qualifiedShadowContext(
            { model: cfg.classifier.model, policyHash },
            trustedShadow,
          )
            ? trustedShadow!.context.modelRevision
            : undefined,
          customPolicy:
            cfg.classifier.systemPrompt !== undefined ||
            cfg.classifier.severityRubric !== undefined ||
            cfg.classifier.categories !== undefined,
        });
      }
      await dispatcher.tick();
      return true;
    },
    tick: dispatcher.tick,
    stop: dispatcher.stop,
  };
}
