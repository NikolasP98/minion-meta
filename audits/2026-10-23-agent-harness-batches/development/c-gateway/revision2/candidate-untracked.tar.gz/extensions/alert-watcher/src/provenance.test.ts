import { it, expect } from "vitest";
import { certifiedOriginals, admissionIdentity, snapshotHash } from "./provenance.js";
import { workFixture } from "./work-test-fixtures.js";
it("preserves exact ordered constituents and scopes equal provider IDs", () => {
  const source = workFixture().source;
  const context = {
    channel: source.channel,
    accountId: source.accountId,
    conversationId: source.conversationId,
  };
  const next = { ...source, messageId: "second", text: " next\n" };
  expect(certifiedOriginals({ version: 1, sources: [source, next] }, context)).toEqual([
    source,
    next,
  ]);
  expect(admissionIdentity("n", source)).not.toBe(
    admissionIdentity("n", { ...source, accountId: "another" }),
  );
  expect(snapshotHash(source)).not.toBe(snapshotHash({ ...source, text: source.text.trim() }));
  expect(
    certifiedOriginals({ version: 1, sources: [source] }, { ...context, channel: "whatsapp" }),
  ).toBeNull();
  expect(certifiedOriginals(undefined, context)).toBeNull();
});
