import { spawn, type ChildProcess } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { afterEach, it, expect, vi } from "vitest";
import { readQueuedDelivery } from "../../../src/infra/outbound/delivery-queue-files.js";
import { recoverPendingDeliveries } from "../../../src/infra/outbound/delivery-queue-recovery.js";
import { drainDeliveryReceipts } from "./delivery-bridge.js";
import { positiveFixture } from "./work-test-fixtures.js";
const dirs: string[] = [],
  children: ChildProcess[] = [];
afterEach(() => {
  for (const c of children.splice(0)) {
    c.kill("SIGKILL");
  }
  for (const d of dirs.splice(0)) {
    fs.rmSync(d, { recursive: true, force: true });
  }
});
for (const stage of [
  "sqlite-admitted",
  "enqueued",
  "provider-accepted",
  "queue-accepted",
  "settled",
]) {
  it(`real subprocess kill at ${stage} preserves queue evidence and owner reply settlement`, async () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "watcher-delivery-kill-"));
    dirs.push(dir);
    const f = positiveFixture(dir),
      receipt = f.db.prepare("SELECT id FROM alert_delivery_receipts").get() as { id: string };
    const marker = path.join(dir, "calls");
    const c = spawn(
      process.execPath,
      [
        "--import",
        "tsx",
        fileURLToPath(new URL("../test-support/delivery-process.ts", import.meta.url)),
        path.join(dir, "alerts.db"),
        receipt.id,
        dir,
        stage,
        marker,
      ],
      { stdio: ["ignore", "pipe", "pipe", "ipc"] },
    );
    children.push(c);
    let error = "";
    c.stderr?.on("data", (data) => {
      error += data;
    });
    await new Promise<void>((resolve, reject) => {
      const timeout = setTimeout(() => reject(Error(`barrier timeout ${error}`)), 25000);
      c.once("message", () => {
        clearTimeout(timeout);
        resolve();
      });
      c.once("exit", (code) => {
        if (code) {
          reject(Error(error));
        }
      });
    });
    c.kill("SIGKILL");
    await new Promise((resolve) => c.once("exit", resolve));
    f.db.prepare("UPDATE alert_delivery_receipts SET lease_expires_at=0").run();
    const send = vi.fn();
    const deps = {
      stateDir: dir,
      config: () => ({}),
      authority: async () => f.snapshot.authority,
      destinations: () => f.snapshot.destinations,
      send,
    };
    if (stage === "provider-accepted") {
      const replay = vi.fn();
      await recoverPendingDeliveries({
        cfg: {},
        stateDir: dir,
        log: { info: () => {}, warn: () => {}, error: () => {} },
        deliver: replay,
        delay: async () => {},
      });
      expect(replay).not.toHaveBeenCalled();
      expect((await readQueuedDelivery(receipt.id, dir)).payloads[0].state).toBe("uncertain");
    }
    if (stage === "enqueued") {
      // Existing queue recovery owns safe pending dispatch; no fresh queue identity.
      await drainDeliveryReceipts(f.db, {
        ...deps,
        send: async (params) => {
          expect(params.skipQueue).toBe(true);
          throw Error("stub pre-provider failure");
        },
      }).catch(() => {});
    } else {
      await drainDeliveryReceipts(f.db, deps);
    }
    if (stage === "queue-accepted" || stage === "settled") {
      expect(f.db.prepare("SELECT state FROM alert_delivery_receipts").get()).toEqual({
        state: "sent",
      });
      expect(f.db.prepare("SELECT count(*) n FROM pending_replies").get()).toEqual({ n: 1 });
    } else if (stage !== "enqueued") {
      expect(f.db.prepare("SELECT state FROM alert_delivery_receipts").get()).toEqual({
        state: "indeterminate",
      });
    }
    expect(send).not.toHaveBeenCalled();
    expect(
      fs.existsSync(marker) ? fs.readFileSync(marker, "utf8").trim().split("\n").length : 0,
    ).toBe(["provider-accepted", "queue-accepted", "settled"].includes(stage) ? 1 : 0);
    f.db.close();
  }, 35000);
}
