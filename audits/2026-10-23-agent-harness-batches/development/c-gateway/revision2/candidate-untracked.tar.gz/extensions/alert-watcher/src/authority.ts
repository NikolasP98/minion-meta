import { getChannelPlugin } from "../../../src/channels/plugins/index.js";
import type { MinionConfig } from "../../../src/config/config.js";
import { getMirrorEntry, mirrorMeta, orgScopeSource } from "../../../src/gateway/channel-mirror.js";
import { retentionHash } from "../../../src/infra/outbound/delivery-retention.js";
import { isPluginEnabledForAnyOrg } from "../../../src/plugins/org-enforcement.js";
import { normalizeAccountId } from "../../../src/routing/session-key.js";

export type WatcherAuthority =
  | { kind: "scoped"; source: "db_mirror" | "json_config"; orgIds: string[]; evidenceHash: string }
  | { kind: "local_unscoped"; source: "json_config"; evidenceHash: string }
  | { kind: "unavailable"; reason: string };
export type BoundAuthority = Exclude<WatcherAuthority, { kind: "unavailable" }>;
const unavailable = (reason: string): WatcherAuthority => ({ kind: "unavailable", reason });
/** This deliberately does not use the compatibility resolver's JSON fallback. */
export async function resolveWatcherAuthority(
  cfg: MinionConfig,
  channel: string,
  accountId: string,
  now = Date.now(),
): Promise<WatcherAuthority> {
  if (!channel || !accountId || channel.trim() !== channel || accountId.trim() !== accountId) {
    return unavailable("invalid_account");
  }
  if (cfg.plugins?.entries?.["alert-watcher"]?.enabled === false) {
    return unavailable("plugin_disabled");
  }
  if (orgScopeSource() === "db") {
    const entry = getMirrorEntry(channel, accountId);
    const at = mirrorMeta().lastHydratedAt;
    if (
      !entry ||
      entry.type !== channel ||
      entry.accountId !== accountId ||
      typeof entry.orgId !== "string" ||
      !entry.orgId.trim() ||
      entry.orgId.trim() !== entry.orgId ||
      !Object.is(entry.projection?.enabled, true) ||
      !Number.isSafeInteger(at) ||
      at <= 0 ||
      at > now ||
      now - at > 300000
    ) {
      return unavailable("unavailable_mirror");
    }
    const orgIds = [entry.orgId];
    if (
      !isPluginEnabledForAnyOrg(cfg, "alert-watcher", orgIds) ||
      !isPluginEnabledForAnyOrg(cfg, channel, orgIds)
    ) {
      return unavailable("plugin_disabled");
    }
    return {
      kind: "scoped",
      source: "db_mirror",
      orgIds,
      evidenceHash: retentionHash([channel, accountId, "db_mirror", orgIds]),
    };
  }
  const plugin = getChannelPlugin(channel);
  const section = cfg.channels?.[channel] as Record<string, unknown> | undefined;
  if (!plugin || !section || typeof section !== "object" || section.enabled === false) {
    return unavailable("missing_account");
  }
  const accounts = section.accounts as Record<string, unknown> | undefined;
  if (
    accounts &&
    Object.keys(accounts).filter((key) => normalizeAccountId(key) === normalizeAccountId(accountId))
      .length > 1
  ) {
    return unavailable("ambiguous_account");
  }
  const exact = accounts && Object.hasOwn(accounts, accountId);
  // A synthesized default from account enumeration is not a configured account.
  if (
    !exact &&
    !(
      accountId === "default" &&
      (typeof section.botToken === "string" ||
        typeof section.tokenFile === "string" ||
        typeof section.token === "string")
    )
  ) {
    return unavailable("missing_account");
  }
  const ids = plugin.config.listAccountIds(cfg);
  if (
    ids.filter((id) => id.toLowerCase() === accountId.toLowerCase()).length !== 1 ||
    !ids.includes(accountId)
  ) {
    return unavailable("ambiguous_account");
  }
  try {
    const resolved = plugin.config.resolveAccount(cfg, accountId);
    const described = plugin.config.describeAccount?.(resolved, cfg);
    if (
      (plugin.config.isEnabled && !plugin.config.isEnabled(resolved, cfg)) ||
      described?.enabled === false ||
      !plugin.config.isConfigured ||
      !(await plugin.config.isConfigured(resolved, cfg))
    ) {
      return unavailable("unconfigured_account");
    }
  } catch {
    return unavailable("unconfigured_account");
  }
  const mapping = cfg.channels?.accountOrgs?.[channel];
  if (!mapping || !Object.hasOwn(mapping, accountId)) {
    return unavailable("missing_mapping");
  }
  const raw = mapping[accountId];
  if (
    !Array.isArray(raw) ||
    raw.some((id) => typeof id !== "string" || !id.trim() || id.trim() !== id)
  ) {
    return unavailable("invalid_mapping");
  }
  const orgIds = [...new Set(raw)].sort();
  if (
    !isPluginEnabledForAnyOrg(cfg, "alert-watcher", orgIds) ||
    !isPluginEnabledForAnyOrg(cfg, channel, orgIds)
  ) {
    return unavailable("plugin_disabled");
  }
  const evidenceHash = retentionHash([channel, accountId, "json_config", orgIds]);
  return orgIds.length
    ? { kind: "scoped", source: "json_config", orgIds, evidenceHash }
    : { kind: "local_unscoped", source: "json_config", evidenceHash };
}
export function sameAuthority(bound: BoundAuthority, current: WatcherAuthority): boolean {
  return current.kind !== "unavailable" && bound.evidenceHash === current.evidenceHash;
}
