export type ExperimentMode = "off" | "census" | "shadow";
export type Eligibility = {
  status: "eligible" | "bypass" | "disabled";
  reason:
    | "eligible"
    | "mode_off"
    | "plugin_disabled"
    | "unmatched"
    | "uncertified_source"
    | "custom_policy"
    | "model_drift"
    | "invalid_binding";
};
export function resolveComplaintExperiment(value: unknown): { mode: ExperimentMode } {
  if (value === undefined) {
    return { mode: "off" };
  }
  if (
    !value ||
    typeof value !== "object" ||
    Array.isArray(value) ||
    Object.keys(value).some((k) => k !== "mode")
  ) {
    throw new Error("invalid complaintExperiment");
  }
  const mode = (value as { mode?: unknown }).mode;
  if (mode !== undefined && mode !== "off" && mode !== "census" && mode !== "shadow") {
    throw new Error("invalid complaintExperiment.mode");
  }
  return { mode: mode ?? "off" };
}
export function complaintEligibility(i: {
  mode: ExperimentMode;
  enabled: boolean;
  matched: boolean;
  certified: boolean;
  customPolicy: boolean;
  modelQualified: boolean;
  bindingValid: boolean;
}): Eligibility {
  if (!i.enabled) {
    return { status: "disabled", reason: "plugin_disabled" };
  }
  if (i.mode === "off") {
    return { status: "disabled", reason: "mode_off" };
  }
  for (const [pass, reason] of [
    [i.matched, "unmatched"],
    [i.certified, "uncertified_source"],
    [!i.customPolicy, "custom_policy"],
    [i.bindingValid, "invalid_binding"],
    [i.modelQualified, "model_drift"],
  ] as const) {
    if (!pass) {
      return { status: "bypass", reason };
    }
  }
  return { status: "eligible", reason: "eligible" };
}
/** No config/RPC can mint this separately trusted experiment context. */
export type ApprovedShadowContext = {
  manifestHash: string;
  policyHash: string;
  modelRevision: string;
  gateRevision: string;
  remainingExposureUsd: number;
  expiresAt: number;
  maxInvocationCostUsd: number;
};
export async function runComplaintShadow(
  context: ApprovedShadowContext | undefined,
  binding: { policyHash: string; modelRevision: string },
  adapter:
    | ((context: ApprovedShadowContext) => Promise<"forward" | "negative" | "abstain">)
    | undefined,
): Promise<"forward" | "negative" | "abstain" | "unavailable"> {
  if (
    !context ||
    !adapter ||
    !/^[a-f0-9]{64}$/.test(context.manifestHash) ||
    context.policyHash !== binding.policyHash ||
    context.modelRevision !== binding.modelRevision ||
    !context.gateRevision ||
    context.expiresAt <= Date.now() ||
    !Number.isFinite(context.remainingExposureUsd) ||
    !Number.isFinite(context.maxInvocationCostUsd) ||
    context.maxInvocationCostUsd < 0 ||
    context.remainingExposureUsd < context.maxInvocationCostUsd
  ) {
    return "unavailable";
  }
  try {
    const result = await adapter(context);
    return result === "forward" || result === "negative" || result === "abstain"
      ? result
      : "unavailable";
  } catch {
    return "unavailable";
  }
}
