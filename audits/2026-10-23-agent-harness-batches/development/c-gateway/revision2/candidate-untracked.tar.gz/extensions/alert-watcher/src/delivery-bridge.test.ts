import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { afterEach, it, expect, vi } from "vitest";
import { readDeliveryTombstone } from "../../../src/infra/outbound/delivery-queue-files.js";
import {
  initializeGlobalHookRunner,
  resetGlobalHookRunner,
} from "../../../src/plugins/hook-runner-global.js";
import { setActivePluginRegistry } from "../../../src/plugins/runtime.js";
import {
  createTestRegistry,
  createOutboundTestPlugin,
} from "../../../src/test-support/channel-plugins.js";
import type { DeliveryRow } from "./classification-work.js";
import { exportComplaintEvaluation } from "./complaint-evaluation.js";
import { drainDeliveryReceipts } from "./delivery-bridge.js";
import { snapshotHash } from "./provenance.js";
import { positiveFixture } from "./work-test-fixtures.js";
const dirs: string[] = [];
afterEach(() => {
  resetGlobalHookRunner();
  vi.restoreAllMocks();
  for (const d of dirs.splice(0)) {
    fs.rmSync(d, { recursive: true, force: true });
  }
});

it("two actual recipients settle one keyed reply at original acceptance before ack", async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "watcher-bridge-"));
  dirs.push(dir);
  const f = positiveFixture(dir, [
    { channel: "telegram", to: "one" },
    { channel: "telegram", to: "two" },
  ]);
  const send = vi.fn(async () => ({ channel: "telegram" as const, messageId: "accepted" }));
  setActivePluginRegistry(
    createTestRegistry([
      {
        pluginId: "telegram",
        source: "test",
        plugin: createOutboundTestPlugin({
          id: "telegram",
          outbound: { deliveryMode: "direct", sendText: send, sendMedia: send },
        }),
      },
    ]),
  );
  const deps = {
    stateDir: dir,
    config: () => ({}),
    authority: async () => f.snapshot.authority,
    destinations: () => f.snapshot.destinations,
  };
  await drainDeliveryReceipts(f.db, deps);
  expect(send).toHaveBeenCalledTimes(2);
  const rows = f.db.prepare("SELECT * FROM pending_replies").all() as Array<{
    id: number;
    expires_at: number;
    created_at: number;
    claimed_by: string | null;
  }>;
  expect(rows).toHaveLength(1);
  expect(rows[0].expires_at - rows[0].created_at).toBe(3600000);
  f.db.prepare("UPDATE pending_replies SET claimed_by='owner' WHERE id=?").run(rows[0].id);
  await drainDeliveryReceipts(f.db, deps);
  expect(send).toHaveBeenCalledTimes(2);
  expect(
    f.db.prepare("SELECT claimed_by,created_at,expires_at FROM pending_replies").get(),
  ).toMatchObject({
    claimed_by: "owner",
    created_at: rows[0].created_at,
    expires_at: rows[0].expires_at,
  });
  for (const row of f.db.prepare("SELECT * FROM alert_delivery_receipts").all() as DeliveryRow[]) {
    expect(await readDeliveryTombstone(row.id, dir)).toMatchObject({ reason: "settled" });
  }
  f.db.close();
});
it("admitted missing queue evidence never reenqueues, and revoked queued recipients never send", async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "watcher-bridge-missing-"));
  dirs.push(dir);
  const f = positiveFixture(dir);
  f.db.prepare("UPDATE alert_delivery_receipts SET state='admitted',admitted_at=?").run(Date.now());
  const send = vi.fn();
  await drainDeliveryReceipts(f.db, {
    stateDir: dir,
    config: () => ({}),
    authority: async () => f.snapshot.authority,
    destinations: () => [],
    send,
  });
  expect(send).not.toHaveBeenCalled();
  expect(f.db.prepare("SELECT state,safe_reason FROM alert_delivery_receipts").get()).toEqual({
    state: "indeterminate",
    safe_reason: "missing_or_mismatched_queue",
  });
  f.db.close();
});

it("first-sent materialization preserves actual owner selection and forwarded state", async () => {
  const { handleOwnerReply } = await import("./reply-flow/handle-reply.js");
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "watcher-owner-reply-"));
  dirs.push(dir);
  const f = positiveFixture(dir);
  f.db
    .prepare("UPDATE classification_work SET suggestion_json=? WHERE id=?")
    .run(JSON.stringify({ state: "received", suggestions: ["alpha", "beta", "gamma"] }), f.id);
  const send = vi.fn(async () => ({ channel: "telegram" as const, messageId: "accepted" }));
  setActivePluginRegistry(
    createTestRegistry([
      {
        pluginId: "telegram",
        source: "test",
        plugin: createOutboundTestPlugin({
          id: "telegram",
          outbound: { deliveryMode: "direct", sendText: send, sendMedia: send },
        }),
      },
    ]),
  );
  const deps = {
    stateDir: dir,
    config: () => ({}),
    authority: async () => f.snapshot.authority,
    destinations: () => f.snapshot.destinations,
  };
  await drainDeliveryReceipts(f.db, deps);
  const forward = vi.fn(async () => ({ ok: true }));
  const api = {
    runtime: {
      channel: {
        telegram: { sendMessageTelegram: forward },
        whatsapp: { sendMessageWhatsApp: forward },
      },
    },
    logger: { info: () => {}, warn: () => {}, error: () => {} },
  };
  expect(
    await handleOwnerReply(f.db, api as never, f.snapshot.replyFlow, {
      sender: "owner",
      message: "2",
    }),
  ).toEqual({ status: "forwarded", kind: "preset_2", text: "beta" });
  expect(forward).toHaveBeenCalledWith("chat", "beta", { accountId: "default" });
  await drainDeliveryReceipts(f.db, deps);
  expect(
    f.db.prepare("SELECT claimed_by,reply_text,forwarded_ok FROM pending_replies").get(),
  ).toEqual({ claimed_by: "owner", reply_text: "beta", forwarded_ok: 1 });
  f.db.close();
});

it.each([
  "revoked_before",
  "unbound",
  "revoked_during_send",
  "reassigned_during_send",
  "source_revoked_during_send",
] as const)("first confirmed send cannot grant an owner reply after %s", async (mode) => {
  const { handleOwnerReply } = await import("./reply-flow/handle-reply.js");
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "watcher-current-reply-"));
  dirs.push(dir);
  const f = positiveFixture(dir, [
    { channel: "telegram", to: "one" },
    { channel: "telegram", to: "revoked" },
  ]);
  if (mode === "unbound") {
    delete f.snapshot.destinationAuthorities![snapshotHash(["telegram", "default", "revoked"])];
    f.db
      .prepare("UPDATE classification_work SET snapshot=? WHERE id=?")
      .run(JSON.stringify(f.snapshot), f.id);
  }
  let configured =
    mode === "revoked_before" ? [f.snapshot.destinations[0]] : f.snapshot.destinations;
  const permitted = new Set(["one", "revoked"]);
  let sourceActive = true;
  let enter: () => void = () => {},
    release: () => void = () => {};
  const entered = new Promise<void>((resolve) => {
      enter = resolve;
    }),
    resume = new Promise<void>((resolve) => {
      release = resolve;
    });
  const during = mode.endsWith("during_send");
  const send = vi.fn(async () => {
    if (during) {
      enter();
      await resume;
    }
    return { channel: "telegram" as const, messageId: "accepted-before-local-settlement" };
  });
  setActivePluginRegistry(
    createTestRegistry([
      {
        pluginId: "telegram",
        source: "test",
        plugin: createOutboundTestPlugin({
          id: "telegram",
          outbound: { deliveryMode: "direct", sendText: send, sendMedia: send },
        }),
      },
    ]),
  );
  const deps = {
    stateDir: dir,
    config: () => ({}),
    authority: async () =>
      sourceActive
        ? f.snapshot.authority
        : { kind: "unavailable" as const, reason: "plugin_disabled" },
    destinations: () => configured,
    recipientAllowed: async (
      snapshot: typeof f.snapshot,
      recipient: (typeof f.snapshot.destinations)[number],
    ) =>
      permitted.has(recipient.to) &&
      !!snapshot.destinationAuthorities?.[
        snapshotHash([recipient.channel, recipient.accountId ?? "default", recipient.to])
      ],
  };
  const draining = drainDeliveryReceipts(f.db, deps);
  if (during) {
    await entered;
    configured = mode === "revoked_during_send" ? [] : [f.snapshot.destinations[0]];
    if (mode === "reassigned_during_send") {
      permitted.delete("one");
    }
    if (mode === "source_revoked_during_send") {
      sourceActive = false;
    }
    release();
  }
  await draining;
  expect(send).toHaveBeenCalledTimes(1);
  expect(f.db.prepare("SELECT state FROM alert_delivery_receipts ORDER BY rowid").all()).toEqual([
    { state: "sent" },
    { state: "canceled" },
  ]);
  const pending = f.db.prepare("SELECT * FROM pending_replies").get() as {
    destinations_json: string;
    created_at: number;
    expires_at: number;
    redacted_at: number | null;
  };
  expect(JSON.parse(pending.destinations_json)).toEqual(during ? [] : ["one"]);
  const forward = vi.fn(async () => ({ ok: true }));
  const api = {
    runtime: {
      channel: {
        telegram: { sendMessageTelegram: forward },
        whatsapp: { sendMessageWhatsApp: forward },
      },
    },
    logger: { info: () => {}, warn: () => {}, error: () => {} },
  };
  expect(
    await handleOwnerReply(
      f.db,
      api as never,
      { ...f.snapshot.replyFlow, notifyLoser: false },
      { sender: "revoked", message: "unapproved" },
    ),
  ).toEqual({ status: "ignored" });
  expect(forward).not.toHaveBeenCalled();
  expect(
    (
      await handleOwnerReply(
        f.db,
        api as never,
        { ...f.snapshot.replyFlow, notifyLoser: false },
        { sender: "one", message: "approved" },
      )
    ).status,
  ).toBe(during ? "ignored" : "forwarded");
  const stable = f.db.prepare("SELECT * FROM pending_replies").get();
  configured = f.snapshot.destinations;
  permitted.add("one");
  sourceActive = true;
  await drainDeliveryReceipts(f.db, deps);
  expect(f.db.prepare("SELECT * FROM pending_replies").get()).toEqual(stable);
  expect(send).toHaveBeenCalledTimes(1);
  expect(f.db.prepare("SELECT first_sent_at FROM classification_work").get()).toEqual({
    first_sent_at: pending.created_at,
  });
  const record = exportComplaintEvaluation(f.db, f.id);
  expect(record.baseline.disposition).toBe("positive");
  expect(record.attempts).toHaveLength(1);
  expect(record.attempts[0].costStatus).toBe("unknown");
  f.db.close();
});

it("actual message_sending cancellation durably cancels then acknowledges on the next tick without sent effects", async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "watcher-suppression-"));
  dirs.push(dir);
  const f = positiveFixture(dir),
    send = vi.fn(async () => ({ channel: "telegram" as const, messageId: "must-not-send" }));
  const registry = createTestRegistry([
    {
      pluginId: "telegram",
      source: "test",
      plugin: createOutboundTestPlugin({
        id: "telegram",
        outbound: { deliveryMode: "direct", sendText: send, sendMedia: send },
      }),
    },
  ]);
  const hook = vi.fn(async () => ({ cancel: true }));
  registry.typedHooks.push({
    pluginId: "fixture",
    hookName: "message_sending",
    source: "test",
    handler: hook,
  });
  setActivePluginRegistry(registry);
  initializeGlobalHookRunner(registry);
  const first = vi.fn(),
    deps = {
      stateDir: dir,
      config: () => ({}),
      authority: async () => f.snapshot.authority,
      destinations: () => f.snapshot.destinations,
      onFirstSent: first,
    };
  const id = String(f.db.prepare("SELECT id FROM alert_delivery_receipts").get()!.id);
  await drainDeliveryReceipts(f.db, deps);
  const settled = f.db
    .prepare("SELECT state,safe_reason,settled_at FROM alert_delivery_receipts")
    .get();
  expect(settled).toMatchObject({ state: "canceled", safe_reason: "payload_suppressed" });
  const { readQueuedDelivery, resolveEntryPath } =
    await import("../../../src/infra/outbound/delivery-queue-files.js");
  expect((await readQueuedDelivery(id, dir)).payloads[0].state).toBe("suppressed");
  const unlink = fs.promises.unlink.bind(fs.promises);
  let commitObserved = false;
  vi.spyOn(fs.promises, "unlink").mockImplementation(async (file) => {
    if (String(file) === resolveEntryPath(id, dir)) {
      commitObserved = true;
      expect(
        f.db.prepare("SELECT state,safe_reason,settled_at FROM alert_delivery_receipts").get(),
      ).toEqual(settled);
    }
    return unlink(file);
  });
  await drainDeliveryReceipts(f.db, deps);
  await drainDeliveryReceipts(f.db, deps);
  expect(commitObserved).toBe(true);
  expect(fs.existsSync(resolveEntryPath(id, dir))).toBe(false);
  expect((await readDeliveryTombstone(id, dir))?.payloads[0].state).toBe("suppressed");
  expect(
    f.db.prepare("SELECT state,safe_reason,settled_at FROM alert_delivery_receipts").get(),
  ).toEqual(settled);
  expect(f.db.prepare("SELECT queue_generation FROM alert_delivery_receipts").get()).toEqual({
    queue_generation: -1,
  });
  expect(send).not.toHaveBeenCalled();
  expect(hook).toHaveBeenCalledTimes(1);
  expect(first).not.toHaveBeenCalled();
  expect(f.db.prepare("SELECT first_sent_at FROM classification_work").get()).toEqual({
    first_sent_at: null,
  });
  expect(f.db.prepare("SELECT notified_at FROM complaints").get()).toEqual({ notified_at: null });
  expect(f.db.prepare("SELECT count(*) n FROM pending_replies").get()).toEqual({ n: 0 });
  f.db.close();
});
for (const mixed of ["suppressed", "uncertain"] as const) {
  it(`recovered accepted plus ${mixed} preserves partial acceptance without first-sent effects`, async () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "watcher-mixed-"));
    dirs.push(dir);
    const f = positiveFixture(dir);
    const { enqueueDelivery, checkpointQueuedPayload } =
      await import("../../../src/infra/outbound/delivery-queue-store.js");
    const { acquireDeliveryEntryLease, releaseDeliveryQueueLease, readQueuedDelivery } =
      await import("../../../src/infra/outbound/delivery-queue-files.js");
    const row = f.db.prepare("SELECT * FROM alert_delivery_receipts").get() as DeliveryRow;
    const payloads = [{ text: "first" }, { text: "second" }],
      hash = snapshotHash(payloads);
    f.db
      .prepare(
        "UPDATE alert_delivery_receipts SET state='admitted',admitted_at=1,payload_json=?,payload_hash=? WHERE id=?",
      )
      .run(JSON.stringify(payloads), hash, row.id);
    await enqueueDelivery(
      {
        id: row.id,
        channel: "telegram",
        accountId: "default",
        to: "owner",
        payloads,
        completionPolicy: "caller",
        callerRetention: {
          version: 1,
          owner: "alert-watcher",
          namespaceHash: snapshotHash("namespace"),
          receiptId: row.id,
          payloadHash: hash,
          recipientHash: row.recipient_hash,
          expiresAt: row.payload_expires_at,
        },
      },
      dir,
    );
    const lease = await acquireDeliveryEntryLease(row.id, dir);
    let entry = await readQueuedDelivery(row.id, dir);
    entry = await checkpointQueuedPayload({
      id: row.id,
      payloadId: entry.payloads[0].id,
      expectedGeneration: entry.generation,
      nextState: "in-flight",
      lease,
      stateDir: dir,
    });
    entry = await checkpointQueuedPayload({
      id: row.id,
      payloadId: entry.payloads[0].id,
      expectedGeneration: entry.generation,
      nextState: "accepted",
      providerMessageIds: ["known-accepted"],
      lease,
      stateDir: dir,
    });
    if (mixed === "uncertain") {
      entry = await checkpointQueuedPayload({
        id: row.id,
        payloadId: entry.payloads[1].id,
        expectedGeneration: entry.generation,
        nextState: "in-flight",
        lease,
        stateDir: dir,
      });
    }
    entry = await checkpointQueuedPayload({
      id: row.id,
      payloadId: entry.payloads[1].id,
      expectedGeneration: entry.generation,
      nextState: mixed,
      lease,
      stateDir: dir,
    });
    await releaseDeliveryQueueLease(lease);
    const send = vi.fn(),
      deps = {
        stateDir: dir,
        config: () => ({}),
        authority: async () => f.snapshot.authority,
        destinations: () => f.snapshot.destinations,
        send,
      };
    await drainDeliveryReceipts(f.db, deps);
    await drainDeliveryReceipts(f.db, deps);
    const result = f.db
      .prepare("SELECT state,provider_receipts FROM alert_delivery_receipts")
      .get()!;
    expect(result.state).toBe(mixed === "suppressed" ? "canceled" : "indeterminate");
    expect(JSON.parse(String(result.provider_receipts))[0].receipt.providerMessageIds).toEqual([
      "known-accepted",
    ]);
    expect(send).not.toHaveBeenCalled();
    expect(f.db.prepare("SELECT first_sent_at FROM classification_work").get()).toEqual({
      first_sent_at: null,
    });
    expect(f.db.prepare("SELECT count(*) n FROM pending_replies").get()).toEqual({ n: 0 });
    if (mixed === "suppressed") {
      expect((await readDeliveryTombstone(row.id, dir))?.payloads.map((p) => p.state)).toEqual([
        "accepted",
        "suppressed",
      ]);
    }
    f.db.close();
  });
}
