import fs from "node:fs";
import path from "node:path";
import { setActivePluginRegistry } from "../../../src/plugins/runtime.js";
// Preserve the supported native bootstrap before importing outbound recovery.
setActivePluginRegistry({
  plugins: [],
  tools: [],
  hooks: [],
  typedHooks: [],
  channels: [],
  providers: [],
  gatewayHandlers: {},
  httpHandlers: {},
  httpRoutes: [],
  cliRegistrars: [],
  services: [],
  commands: [],
  diagnostics: [],
});
const { recoverPendingDeliveries } =
  await import("../../../src/infra/outbound/delivery-queue-recovery.js");
const [stateDir] = process.argv.slice(2);
await recoverPendingDeliveries({
  stateDir,
  cfg: { plugins: { entries: { "alert-watcher": { enabled: false } } } },
  log: { info: () => {}, warn: () => {}, error: () => {} },
  deliver: async () => {
    fs.appendFileSync(path.join(stateDir, "unexpected-recovery-send"), "sent\n");
    throw Error("expired bytes must not dispatch");
  },
  delay: async () => {},
});
