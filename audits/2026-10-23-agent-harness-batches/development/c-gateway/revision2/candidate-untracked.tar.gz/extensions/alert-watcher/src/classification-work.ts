import crypto from "node:crypto";
import type { DatabaseSync } from "node:sqlite";
import type { DroneRunResult } from "@minion-stack/drone";
import type { InvocationUsage } from "../../../src/drones/run-with-usage.js";
import type { CanonicalTransportSourceUnit } from "../../../src/plugins/types/hooks.js";
import { type BoundAuthority, type WatcherAuthority, sameAuthority } from "./authority.js";
import type { ClassifierOverrides } from "./classifier.js";
import type { CooldownConfig } from "./cooldown.js";
import { redactDeliveryEvidence } from "./delivery-evidence.js";
import type { Destination } from "./destinations.js";
import type { ExperimentMode } from "./jev-shadow-eligibility.js";
import {
  admissionIdentity,
  canonicalSnapshot,
  snapshotHash,
  sourceIdentity,
  WATCHER_POLICY_ID,
  classifierInput,
} from "./provenance.js";
import type { ReplyFlowConfig } from "./reply-flow/types.js";
import type { ComplaintResult } from "./types.js";

export const RAW_RETENTION_MS = 7 * 24 * 60 * 60 * 1000;
export type WorkState =
  | "queued"
  | "admitted"
  | "received"
  | "completed"
  | "failed"
  | "canceled"
  | "indeterminate";
export type WorkSnapshot = {
  sourceCertification?: "uncertified" | "idless";
  qualifiedModelRevision?: string;
  invocationPurpose?: "classification" | "suggestion";
  source: CanonicalTransportSourceUnit;
  authority: BoundAuthority;
  agentId?: string;
  model: string;
  language: "en" | "es";
  overrides: ClassifierOverrides;
  minSeverity: "low" | "med" | "high";
  cooldown: CooldownConfig;
  destinations: Destination[];
  destinationAuthorities?: Record<string, BoundAuthority>;
  replyFlow: ReplyFlowConfig;
  mode: ExperimentMode;
  policyHash: string;
  defaultPolicyHash: string;
  customPolicy: boolean;
};
export type SuggestionReceipt = {
  state: "not_requested" | "queued" | "admitted" | "received" | "indeterminate";
  attemptId?: string;
  result?: DroneRunResult<unknown>;
  usage?: InvocationUsage;
  suggestions?: string[];
  reason?: string;
  dispatchStatus?: "preparing" | "may_have_submitted" | "not_submitted";
};
export type WorkRow = {
  id: string;
  namespace: string;
  policy_id: string;
  admission_key: string;
  source_key: string;
  source_hash: string;
  input_hash: string;
  policy_hash: string;
  computation_key: string;
  reevaluation_generation: number;
  prior_work_id: string | null;
  snapshot: string | null;
  state: WorkState;
  lease_owner: string | null;
  generation: number;
  lease_expires_at: number | null;
  attempt_count: number;
  next_attempt_at: number;
  attempt_id: string | null;
  admitted_at: number | null;
  received_at: number | null;
  completed_at: number | null;
  terminal_result: string | null;
  usage_json: string | null;
  attempts_json: string;
  safe_error: string | null;
  source_counted_at: number;
  first_sent_at: number | null;
  complaint_id: number | null;
  suggestion_json: string;
  created_at: number;
  payload_expires_at: number;
  redacted_at: number | null;
  namespace_retired: number;
  receipt_revision: number;
  authority_observation: string | null;
};
export type WorkLease = { id: string; owner: string; generation: number };
export type DeliveryRow = {
  id: string;
  work_id: string;
  result_revision: number;
  recipient_hash: string;
  policy_hash: string;
  recipient_json: string | null;
  payload_json: string | null;
  payload_hash: string;
  state: "queued" | "admitted" | "sent" | "failed" | "canceled" | "indeterminate";
  lease_owner: string | null;
  generation: number;
  lease_expires_at: number | null;
  admitted_at: number | null;
  settled_at: number | null;
  queue_generation: number | null;
  next_attempt_at: number;
  provider_receipts: string | null;
  safe_reason: string | null;
  payload_expires_at: number;
  redacted_at: number | null;
};
export function boundedJson(value: unknown, max = 65536): string {
  const text = canonicalSnapshot(value);
  if (Buffer.byteLength(text) > max) {
    throw new Error("snapshot_too_large");
  }
  return text;
}
export function immediate<T>(db: DatabaseSync, fn: () => T): T {
  db.exec("BEGIN IMMEDIATE");
  try {
    const value = fn();
    db.exec("COMMIT");
    return value;
  } catch (err) {
    db.exec("ROLLBACK");
    throw err;
  }
}
export function initWorkSchema(db: DatabaseSync): void {
  db.exec(`PRAGMA busy_timeout=5000;
    CREATE TABLE IF NOT EXISTS classification_work (
      id TEXT PRIMARY KEY, namespace TEXT NOT NULL, policy_id TEXT NOT NULL,
      admission_key TEXT NOT NULL UNIQUE, source_key TEXT NOT NULL, source_hash TEXT NOT NULL,
      input_hash TEXT NOT NULL, policy_hash TEXT NOT NULL, computation_key TEXT NOT NULL UNIQUE,
      reevaluation_generation INTEGER NOT NULL DEFAULT 0 CHECK(reevaluation_generation>=0), prior_work_id TEXT,
      evaluation_binding TEXT NOT NULL,
      authority_observation TEXT CHECK(authority_observation IS NULL OR length(CAST(authority_observation AS BLOB))<=1024),
      snapshot TEXT CHECK(snapshot IS NULL OR length(CAST(snapshot AS BLOB))<=65536),
      state TEXT NOT NULL CHECK(state IN ('queued','admitted','received','completed','failed','canceled','indeterminate')),
      lease_owner TEXT, generation INTEGER NOT NULL DEFAULT 0 CHECK(generation>=0), lease_expires_at INTEGER,
      attempt_count INTEGER NOT NULL DEFAULT 0 CHECK(attempt_count BETWEEN 0 AND 3), next_attempt_at INTEGER NOT NULL,
      attempt_id TEXT, admitted_at INTEGER, received_at INTEGER, completed_at INTEGER,
      terminal_result TEXT CHECK(terminal_result IS NULL OR length(CAST(terminal_result AS BLOB))<=65536),
      usage_json TEXT, attempts_json TEXT NOT NULL DEFAULT '[]', safe_error TEXT CHECK(length(safe_error)<=128),
      source_counted_at INTEGER NOT NULL, first_sent_at INTEGER, complaint_id INTEGER,
      shadow_json TEXT NOT NULL DEFAULT 'null' CHECK(length(CAST(shadow_json AS BLOB))<=16384),
      suggestion_json TEXT NOT NULL DEFAULT '{"state":"not_requested"}' CHECK(length(CAST(suggestion_json AS BLOB))<=16384),
      created_at INTEGER NOT NULL, payload_expires_at INTEGER NOT NULL, redacted_at INTEGER,
      namespace_retired INTEGER NOT NULL DEFAULT 0 CHECK(namespace_retired IN (0,1)),
      receipt_revision INTEGER NOT NULL DEFAULT 1 CHECK(receipt_revision>0),
      CHECK(state NOT IN ('admitted','indeterminate') OR (admitted_at IS NOT NULL AND attempt_id IS NOT NULL)),
      CHECK(state NOT IN ('received','completed') OR terminal_result IS NOT NULL OR redacted_at IS NOT NULL)
    );
    CREATE INDEX IF NOT EXISTS idx_work_due ON classification_work(state,next_attempt_at,lease_expires_at);
    CREATE INDEX IF NOT EXISTS idx_work_retention ON classification_work(payload_expires_at) WHERE redacted_at IS NULL;
    CREATE TABLE IF NOT EXISTS alert_delivery_receipts (
      id TEXT PRIMARY KEY, work_id TEXT NOT NULL REFERENCES classification_work(id), result_revision INTEGER NOT NULL,
      recipient_hash TEXT NOT NULL, policy_hash TEXT NOT NULL, recipient_json TEXT,
      payload_json TEXT CHECK(payload_json IS NULL OR length(CAST(payload_json AS BLOB))<=65536), payload_hash TEXT NOT NULL,
      state TEXT NOT NULL CHECK(state IN ('queued','admitted','sent','failed','canceled','indeterminate')),
      lease_owner TEXT, generation INTEGER NOT NULL DEFAULT 0, lease_expires_at INTEGER,
      admitted_at INTEGER, settled_at INTEGER, queue_generation INTEGER, provider_receipts TEXT, next_attempt_at INTEGER NOT NULL DEFAULT 0,
      safe_reason TEXT CHECK(length(safe_reason)<=128), payload_expires_at INTEGER NOT NULL, redacted_at INTEGER,
      UNIQUE(work_id,result_revision,policy_hash,recipient_hash),
      CHECK(state!='sent' OR provider_receipts IS NOT NULL),
      CHECK(state!='indeterminate' OR (admitted_at IS NOT NULL AND safe_reason IS NOT NULL))
    );
    CREATE INDEX IF NOT EXISTS idx_delivery_work ON alert_delivery_receipts(work_id,state);
  `);
  const columns = db.prepare("PRAGMA table_info(classification_work)").all() as Array<{
    name: string;
  }>;
  if (!columns.some((column) => column.name === "authority_observation")) {
    db.exec(
      "ALTER TABLE classification_work ADD COLUMN authority_observation TEXT CHECK(authority_observation IS NULL OR length(CAST(authority_observation AS BLOB))<=1024)",
    );
  }
}
export type AuthorityObservation = {
  status: "valid" | "disabled" | "unmatched" | "invalid";
  source: "db_mirror" | "json_config" | "unavailable";
  reason: string | null;
  observedAt: number;
};
/** Persist only source-qualified authority facts, fenced against a successor generation. */
export function observeWorkAuthority(
  db: DatabaseSync,
  row: WorkRow,
  snapshot: WorkSnapshot,
  current: WatcherAuthority,
  now = Date.now(),
): boolean {
  const valid = sameAuthority(snapshot.authority, current);
  const reason =
    current.kind === "unavailable" && /^[a-z_]{1,128}$/.test(current.reason)
      ? current.reason
      : null;
  const observation: AuthorityObservation = {
    status: valid
      ? "valid"
      : reason === "plugin_disabled"
        ? "disabled"
        : reason === "policy_unmatched"
          ? "unmatched"
          : "invalid",
    source: current.kind === "unavailable" ? "unavailable" : current.source,
    reason,
    observedAt: now,
  };
  const prior = row.authority_observation
    ? (JSON.parse(row.authority_observation) as AuthorityObservation)
    : null;
  if (
    !prior ||
    prior.status !== observation.status ||
    prior.source !== observation.source ||
    prior.reason !== reason
  ) {
    db.prepare(
      "UPDATE classification_work SET authority_observation=?,receipt_revision=receipt_revision+1 WHERE id=? AND generation=?",
    ).run(boundedJson(observation, 1024), row.id, row.generation);
  }
  return valid;
}
export function getWork(db: DatabaseSync, id: string): WorkRow | undefined {
  return db.prepare("SELECT * FROM classification_work WHERE id=?").get(id) as WorkRow | undefined;
}
export function admitSource(
  db: DatabaseSync,
  namespace: string,
  snapshot: WorkSnapshot,
  now = Date.now(),
  reevaluation?: { generation: number; priorWorkId: string; actor: string; reason: string },
): { kind: "admitted" | "existing"; work: WorkRow } | { kind: "identity_conflict" | "retired" } {
  const sourceKey = snapshotHash(sourceIdentity(snapshot.source)),
    sourceHash = snapshotHash(snapshot.source);
  const generation = reevaluation?.generation ?? 0;
  const admissionKey = admissionIdentity(namespace, snapshot.source, generation);
  return immediate(db, () => {
    if (
      db
        .prepare(
          "SELECT 1 FROM classification_work WHERE namespace=? AND namespace_retired=1 LIMIT 1",
        )
        .get(namespace)
    ) {
      return { kind: "retired" };
    }
    const existing = db
      .prepare("SELECT * FROM classification_work WHERE admission_key=?")
      .get(admissionKey) as WorkRow | undefined;
    if (existing) {
      return existing.source_hash !== sourceHash
        ? { kind: "identity_conflict" }
        : { kind: "existing", work: existing };
    }
    if (reevaluation) {
      const previous = getWork(db, reevaluation.priorWorkId);
      if (
        !previous ||
        previous.namespace !== namespace ||
        previous.source_key !== sourceKey ||
        generation !== previous.reevaluation_generation + 1 ||
        !reevaluation.actor ||
        !reevaluation.reason ||
        !sameAuthority(JSON.parse(previous.snapshot ?? "null")?.authority, snapshot.authority)
      ) {
        throw new Error("invalid_reevaluation");
      }
    }
    if (
      (
        db
          .prepare("SELECT COUNT(*) AS n FROM classification_work WHERE redacted_at IS NULL")
          .get() as { n: number }
      ).n >= 10000
    ) {
      throw new Error("retention_capacity");
    }
    let raw: string | null = null;
    try {
      raw = boundedJson({
        ...snapshot,
        ...(reevaluation
          ? { reevaluation: { actor: reevaluation.actor, reason: reevaluation.reason } }
          : {}),
      });
    } catch {
      /* Retain identity with explicit terminal failure; never truncate source bytes. */
    }
    const inputHash = snapshotHash(classifierInput(snapshot.source.text));
    const id = crypto.randomUUID();
    db.prepare(`INSERT INTO classification_work(id,namespace,policy_id,admission_key,source_key,source_hash,input_hash,policy_hash,computation_key,reevaluation_generation,prior_work_id,snapshot,evaluation_binding,state,next_attempt_at,source_counted_at,created_at,payload_expires_at)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?, 'queued',?,?,?,?)`).run(
      id,
      namespace,
      WATCHER_POLICY_ID,
      admissionKey,
      sourceKey,
      sourceHash,
      inputHash,
      snapshot.policyHash,
      snapshotHash([admissionKey, inputHash, snapshot.policyHash]),
      generation,
      reevaluation?.priorWorkId ?? null,
      raw,
      boundedJson({
        model: snapshot.model,
        defaultPolicyHash: snapshot.defaultPolicyHash,
        customPolicy: snapshot.customPolicy,
        mode: snapshot.mode,
        modelRevision: snapshot.qualifiedModelRevision ?? "unqualified",
        modelQualified: snapshot.qualifiedModelRevision !== undefined,
        sourceCertification: snapshot.sourceCertification ?? "certified",
        invocationPurpose: snapshot.invocationPurpose ?? "classification",
        replyEnabled: snapshot.replyFlow.enabled,
        replyWindowMs: snapshot.replyFlow.windowMs,
      }),
      now,
      now,
      now,
      now + RAW_RETENTION_MS,
    );
    if (raw === null) {
      db.prepare(
        "UPDATE classification_work SET state='failed',safe_error='snapshot_too_large',completed_at=?,redacted_at=? WHERE id=?",
      ).run(now, now, id);
    }
    return { kind: "admitted", work: getWork(db, id)! };
  });
}
export function claimWork(
  db: DatabaseSync,
  id: string,
  owner: string,
  now = Date.now(),
): WorkLease | undefined {
  return immediate(db, () => {
    const row = getWork(db, id);
    if (
      !row ||
      row.namespace_retired ||
      row.payload_expires_at <= now ||
      !["queued", "received"].includes(row.state) ||
      row.next_attempt_at > now ||
      (row.lease_owner !== null && (row.lease_expires_at ?? 0) > now) ||
      (row.attempt_count >= 3 && row.state === "queued")
    ) {
      return undefined;
    }
    const r = db
      .prepare(
        `UPDATE classification_work SET lease_owner=?, generation=generation+1,lease_expires_at=? WHERE id=? AND generation=? AND state=? AND next_attempt_at<=? AND (lease_owner IS NULL OR lease_expires_at<=?)`,
      )
      .run(owner, now + 30000, id, row.generation, row.state, now, now);
    return r.changes ? { id, owner, generation: row.generation + 1 } : undefined;
  });
}
export function assertWorkLease(db: DatabaseSync, lease: WorkLease, now = Date.now()): WorkRow {
  const row = getWork(db, lease.id);
  if (
    !row ||
    row.lease_owner !== lease.owner ||
    row.generation !== lease.generation ||
    (row.lease_expires_at ?? 0) <= now ||
    row.namespace_retired
  ) {
    throw new Error("work_lease_lost");
  }
  return row;
}
export function renewWork(db: DatabaseSync, lease: WorkLease, now = Date.now()): void {
  const r = db
    .prepare(
      "UPDATE classification_work SET lease_expires_at=? WHERE id=? AND lease_owner=? AND generation=? AND lease_expires_at>?",
    )
    .run(now + 30000, lease.id, lease.owner, lease.generation, now);
  if (!r.changes) {
    throw new Error("work_lease_lost");
  }
}
export function admitInvocation(db: DatabaseSync, lease: WorkLease, now = Date.now()): string {
  return immediate(db, () => {
    const row = assertWorkLease(db, lease, now);
    if (row.state !== "queued" || row.attempt_count >= 3 || row.next_attempt_at > now) {
      throw new Error("invalid_dispatch");
    }
    const id = crypto.randomUUID();
    const attempts = JSON.parse(row.attempts_json) as Array<Record<string, unknown>>;
    attempts.push({ attemptId: id, disposition: "admitted", dispatchStatus: "preparing" });
    db.prepare(
      "UPDATE classification_work SET state='admitted',attempt_id=?,attempt_count=attempt_count+1,admitted_at=?,attempts_json=?,terminal_result=NULL,usage_json=NULL,received_at=NULL,receipt_revision=receipt_revision+1 WHERE id=?",
    ).run(id, now, boundedJson(attempts), row.id);
    return id;
  });
}
/** A provider-capable invocation must cross this owner/generation fence first. */
export function markInvocationDispatch(
  db: DatabaseSync,
  lease: WorkLease,
  attemptId: string,
): void {
  immediate(db, () => {
    const row = assertWorkLease(db, lease);
    if (row.state !== "admitted" || row.attempt_id !== attemptId) {
      throw new Error("invalid_dispatch_fence");
    }
    const attempts = JSON.parse(row.attempts_json) as Array<Record<string, unknown>>;
    const current = attempts[attempts.length - 1];
    if (current.attemptId !== attemptId) {
      throw new Error("invalid_dispatch_fence");
    }
    if (current.dispatchStatus === "may_have_submitted") {
      return;
    }
    if (current.dispatchStatus !== "preparing") {
      throw new Error("invalid_dispatch_fence");
    }
    current.dispatchStatus = "may_have_submitted";
    db.prepare(
      "UPDATE classification_work SET attempts_json=?,receipt_revision=receipt_revision+1 WHERE id=?",
    ).run(boundedJson(attempts), row.id);
  });
}
export function markSuggestionDispatch(
  db: DatabaseSync,
  lease: WorkLease,
  attemptId: string,
): void {
  immediate(db, () => {
    const row = assertWorkLease(db, lease),
      suggestion = JSON.parse(row.suggestion_json) as SuggestionReceipt;
    if (
      suggestion.state !== "admitted" ||
      suggestion.attemptId !== attemptId ||
      suggestion.dispatchStatus !== "preparing"
    ) {
      throw new Error("invalid_suggestion_dispatch_fence");
    }
    suggestion.dispatchStatus = "may_have_submitted";
    db.prepare(
      "UPDATE classification_work SET suggestion_json=?,receipt_revision=receipt_revision+1 WHERE id=?",
    ).run(boundedJson(suggestion, 16384), row.id);
  });
}
export function receiveInvocation(
  db: DatabaseSync,
  lease: WorkLease,
  result: DroneRunResult<unknown>,
  usage: InvocationUsage,
  now = Date.now(),
): void {
  immediate(db, () => {
    const row = assertWorkLease(db, lease, now);
    if (row.state !== "admitted" || row.attempt_id !== usage.attemptId) {
      throw new Error("invalid_receipt");
    }
    let terminal: string;
    try {
      terminal = boundedJson(result);
    } catch {
      terminal = boundedJson({
        ok: false,
        error: { code: "RESULT_TOO_LARGE" },
        usage: result.usage,
        durationMs: result.durationMs,
      });
    }
    const attempts = JSON.parse(row.attempts_json) as Array<Record<string, unknown>>;
    const previous = attempts[attempts.length - 1];
    const notSubmitted =
      previous.dispatchStatus === "preparing" &&
      usage.dispatchStatus !== "may_have_submitted" &&
      !result.ok &&
      result.error.code === "NO_API_KEY";
    const recordedUsage: InvocationUsage = notSubmitted
      ? {
          ...usage,
          dispatchStatus: "not_submitted",
          costStatus: "known",
          costUsd: 0,
          costCoverage: "complete",
        }
      : {
          ...usage,
          dispatchStatus: "may_have_submitted",
          ...(!result.ok
            ? ({ costStatus: "unknown", costUsd: null, costCoverage: "incomplete" } as const)
            : {}),
        };
    attempts[attempts.length - 1] = {
      ...recordedUsage,
      disposition: result.ok ? "received" : "failed",
      ...(!result.ok ? { errorCode: result.error.code } : {}),
    };
    db.prepare(
      "UPDATE classification_work SET state='received',terminal_result=?,usage_json=?,attempts_json=?,received_at=?,receipt_revision=receipt_revision+1 WHERE id=?",
    ).run(terminal, boundedJson(recordedUsage), boundedJson(attempts), now, row.id);
  });
}
export function finishWork(
  db: DatabaseSync,
  lease: WorkLease,
  state: "completed" | "failed" | "canceled" | "indeterminate",
  reason?: string,
  now = Date.now(),
): void {
  const row = assertWorkLease(db, lease, now);
  db.prepare(
    "UPDATE classification_work SET state=?,safe_error=?,completed_at=?,lease_owner=NULL,lease_expires_at=NULL,receipt_revision=receipt_revision+1 WHERE id=?",
  ).run(state, reason?.slice(0, 128) ?? null, now, row.id);
}
export function retryNoCredentials(db: DatabaseSync, lease: WorkLease, now = Date.now()): void {
  const row = assertWorkLease(db, lease, now);
  if (
    row.state !== "received" ||
    JSON.parse(row.terminal_result ?? "null")?.error?.code !== "NO_API_KEY" ||
    JSON.parse(row.attempts_json).at(-1)?.dispatchStatus !== "not_submitted"
  ) {
    throw new Error("retry_not_proven_safe");
  }
  if (row.attempt_count >= 3) {
    finishWork(db, lease, "failed", "no_credentials", now);
    return;
  }
  db.prepare(
    "UPDATE classification_work SET state='queued',next_attempt_at=?,lease_owner=NULL,lease_expires_at=NULL,receipt_revision=receipt_revision+1 WHERE id=?",
  ).run(now + (row.attempt_count === 1 ? 5000 : 30000), row.id);
}
export function recoverExpiredInvocations(db: DatabaseSync, now = Date.now()): void {
  immediate(db, () => {
    db.prepare(
      "UPDATE classification_work SET state='indeterminate',safe_error='admitted_owner_expired',lease_owner=NULL,lease_expires_at=NULL,completed_at=?,receipt_revision=receipt_revision+1 WHERE state='admitted' AND lease_expires_at<=?",
    ).run(now, now);
    const rows = db
      .prepare(
        "SELECT * FROM classification_work WHERE state='received' AND (lease_owner IS NULL OR lease_expires_at<=?)",
      )
      .all(now) as WorkRow[];
    for (const row of rows) {
      const shadow = JSON.parse((row as WorkRow & { shadow_json: string }).shadow_json) as {
        state: string;
      } | null;
      if (shadow?.state === "admitted") {
        db.prepare(
          "UPDATE classification_work SET shadow_json=?,receipt_revision=receipt_revision+1 WHERE id=?",
        ).run(
          boundedJson({ ...shadow, state: "indeterminate", disposition: "unavailable" }),
          row.id,
        );
      }
      const s = JSON.parse(row.suggestion_json) as SuggestionReceipt;
      if (s.state === "admitted") {
        db.prepare(
          "UPDATE classification_work SET suggestion_json=?,receipt_revision=receipt_revision+1 WHERE id=?",
        ).run(
          boundedJson(
            { ...s, state: "indeterminate", suggestions: [], reason: "admitted_owner_expired" },
            16384,
          ),
          row.id,
        );
      }
    }
  });
}
export function setSuggestion(
  db: DatabaseSync,
  lease: WorkLease,
  suggestion: SuggestionReceipt,
): void {
  const row = assertWorkLease(db, lease);
  const previous = JSON.parse(row.suggestion_json) as SuggestionReceipt;
  const allowed: Record<SuggestionReceipt["state"], SuggestionReceipt["state"][]> = {
    not_requested: ["queued", "received"],
    queued: ["admitted"],
    admitted: ["received", "indeterminate"],
    received: [],
    indeterminate: [],
  };
  if (!allowed[previous.state].includes(suggestion.state)) {
    throw new Error("invalid_suggestion_transition");
  }
  if (previous.attemptId && suggestion.attemptId !== previous.attemptId) {
    throw new Error("suggestion_identity_conflict");
  }
  if (suggestion.state === "received" && suggestion.result) {
    const notSubmitted =
      previous.dispatchStatus === "preparing" &&
      suggestion.usage?.dispatchStatus !== "may_have_submitted" &&
      !suggestion.result.ok &&
      suggestion.result.error.code === "NO_API_KEY";
    suggestion = {
      ...suggestion,
      dispatchStatus: notSubmitted ? "not_submitted" : "may_have_submitted",
      ...(suggestion.usage && !suggestion.result.ok
        ? {
            usage: {
              ...suggestion.usage,
              dispatchStatus: notSubmitted ? "not_submitted" : "may_have_submitted",
              costStatus: notSubmitted ? "known" : "unknown",
              costUsd: notSubmitted ? 0 : null,
              costCoverage: notSubmitted ? "complete" : "incomplete",
            },
          }
        : {}),
    };
  }
  let serialized: string;
  try {
    serialized = boundedJson(suggestion, 16384);
  } catch {
    if (suggestion.state !== "received" || !suggestion.result) {
      throw new Error("suggestion_snapshot_too_large");
    }
    serialized = boundedJson(
      {
        ...suggestion,
        suggestions: [],
        reason: "suggestions_result_too_large",
        result: {
          ok: false,
          error: { code: "RESULT_TOO_LARGE", message: "bounded result unavailable" },
          durationMs: suggestion.result.durationMs,
          usage: suggestion.result.usage,
        },
      },
      16384,
    );
  }
  db.prepare(
    "UPDATE classification_work SET suggestion_json=?,receipt_revision=receipt_revision+1 WHERE id=?",
  ).run(serialized, row.id);
}
export function materializePositive(
  db: DatabaseSync,
  lease: WorkLease,
  result: ComplaintResult,
  text: string,
  recipients: Destination[],
  now = Date.now(),
): number {
  return immediate(db, () => {
    const row = assertWorkLease(db, lease, now);
    if (row.state !== "received" || !row.snapshot || row.payload_expires_at <= now) {
      throw new Error("invalid_materialization");
    }
    if (row.complaint_id !== null) {
      return row.complaint_id;
    }
    const snapshot = JSON.parse(row.snapshot) as WorkSnapshot;
    const complaint = db
      .prepare(
        "INSERT INTO complaints(agent_id,channel_id,chat_id,from_sender,content,is_complaint,severity,category,summary,created_at,delivery_disposition) VALUES(?,?,?,?,?,1,?,?,?,?, 'certified')",
      )
      .run(
        snapshot.agentId ?? null,
        snapshot.source.channel,
        snapshot.source.conversationId,
        snapshot.source.senderId ?? "unknown",
        snapshot.source.text,
        result.severity,
        result.category,
        result.summary,
        now,
      );
    const complaintId = Number(complaint.lastInsertRowid),
      payload = boundedJson([{ text }]);
    for (const recipient of recipients) {
      const identity = [recipient.channel, recipient.accountId ?? "default", recipient.to],
        recipientHash = snapshotHash(identity),
        policyHash = snapshotHash({ recipient, policy: row.policy_hash });
      db.prepare(
        "INSERT OR IGNORE INTO alert_delivery_receipts(id,work_id,result_revision,recipient_hash,policy_hash,recipient_json,payload_json,payload_hash,state,payload_expires_at) VALUES(?,?,1,?,?,?,?,?,'queued',?)",
      ).run(
        crypto.randomUUID(),
        row.id,
        recipientHash,
        policyHash,
        boundedJson(recipient),
        payload,
        snapshotHash([{ text }]),
        row.payload_expires_at,
      );
    }
    db.prepare(
      "UPDATE classification_work SET complaint_id=?,receipt_revision=receipt_revision+1 WHERE id=?",
    ).run(complaintId, row.id);
    return complaintId;
  });
}
export function redactExpiredWork(db: DatabaseSync, now = Date.now(), limit = 10): number {
  return immediate(db, () => {
    const rows = db
      .prepare(
        "SELECT * FROM classification_work WHERE payload_expires_at<=? AND redacted_at IS NULL LIMIT ?",
      )
      .all(now, Math.min(10, limit)) as WorkRow[];
    for (const row of rows) {
      if (row.complaint_id !== null) {
        db.prepare(
          "UPDATE complaints SET content='',summary='',from_sender='',chat_id='' WHERE id=?",
        ).run(row.complaint_id);
      }
      const binding = snapshotHash([row.id, 1]);
      db.prepare(
        "UPDATE pending_replies SET origin_channel='',origin_account_id=NULL,origin_chat_id='',destinations_json='[]',suggestions_json='[]',reply_text=NULL,claimed_by=CASE WHEN claimed_by IS NULL THEN NULL ELSE '' END,redacted_at=?,expires_at=MIN(expires_at,?) WHERE receipt_binding=?",
      ).run(now, now, binding);
      const deliveries = db
        .prepare(
          "SELECT id,provider_receipts FROM alert_delivery_receipts WHERE work_id=? AND provider_receipts IS NOT NULL",
        )
        .all(row.id) as Array<{ id: string; provider_receipts: string }>;
      for (const delivery of deliveries) {
        db.prepare("UPDATE alert_delivery_receipts SET provider_receipts=? WHERE id=?").run(
          redactDeliveryEvidence(delivery.provider_receipts),
          delivery.id,
        );
      }
      db.prepare(
        "UPDATE alert_delivery_receipts SET recipient_json=NULL,payload_json=NULL,redacted_at=?,safe_reason=CASE WHEN state IN ('queued','admitted') THEN 'payload_expired' ELSE safe_reason END,state=CASE WHEN state='queued' THEN 'canceled' ELSE state END WHERE work_id=?",
      ).run(now, row.id);
      const terminal = row.terminal_result ? JSON.parse(row.terminal_result) : null;
      const minimalTerminal = terminal
        ? boundedJson({
            ok: terminal.ok,
            usage: terminal.usage,
            durationMs: terminal.durationMs,
            ...(terminal.ok
              ? {
                  data: {
                    is_complaint: terminal.data?.is_complaint,
                    severity: terminal.data?.severity,
                  },
                }
              : { error: { code: terminal.error?.code } }),
          })
        : null;
      const suggestion = JSON.parse(row.suggestion_json) as SuggestionReceipt;
      const minimalSuggestion = boundedJson(
        {
          ...suggestion,
          suggestions: [],
          reason: suggestion.reason ?? "redacted",
          result: suggestion.result
            ? {
                ok: suggestion.result.ok,
                usage: suggestion.result.usage,
                durationMs: suggestion.result.durationMs,
                ...(!suggestion.result.ok
                  ? { error: { code: suggestion.result.error.code, message: "redacted" } }
                  : { data: {} }),
              }
            : undefined,
        },
        16384,
      );
      db.prepare(
        "UPDATE classification_work SET snapshot=NULL,terminal_result=?,suggestion_json=?,redacted_at=?,state=CASE WHEN state IN ('queued','received') THEN 'canceled' WHEN state='admitted' THEN 'indeterminate' ELSE state END,safe_error=CASE WHEN state IN ('queued','admitted') THEN 'payload_expired' ELSE safe_error END,receipt_revision=receipt_revision+1 WHERE id=?",
      ).run(minimalTerminal, minimalSuggestion, now, row.id);
    }
    return rows.length;
  });
}
export function retireNamespace(db: DatabaseSync, namespace: string): void {
  db.prepare(
    "UPDATE classification_work SET namespace_retired=1,receipt_revision=receipt_revision+1 WHERE namespace=?",
  ).run(namespace);
}
export type WorkDispatcherDeps = {
  authority: (snapshot: WorkSnapshot) => Promise<WatcherAuthority>;
  process: (lease: WorkLease, signal: AbortSignal) => Promise<void>;
  deliver: (signal: AbortSignal) => Promise<void>;
  onError: (error: unknown) => void;
};
/** Bounded local lifecycle; SQLite remains the cross-process owner. */
export function createWorkDispatcher(db: DatabaseSync, deps: WorkDispatcherDeps) {
  const owner = crypto.randomUUID();
  let stopped = false;
  let current: Promise<void> | undefined;
  let controller: AbortController | undefined;
  const tick = (): Promise<void> => {
    if (stopped) {
      return Promise.resolve();
    }
    if (current) {
      return current;
    }
    current = (async () => {
      recoverExpiredInvocations(db);
      redactExpiredWork(db);
      const rows = db
        .prepare(
          "SELECT * FROM classification_work WHERE state IN ('queued','received') AND next_attempt_at<=? AND namespace_retired=0 ORDER BY next_attempt_at,created_at LIMIT 10",
        )
        .all(Date.now()) as WorkRow[];
      for (const row of rows) {
        if (stopped) {
          break;
        }
        if (!row.snapshot) {
          continue;
        }
        const snapshot = JSON.parse(row.snapshot) as WorkSnapshot;
        const authority = await deps.authority(snapshot);
        if (!observeWorkAuthority(db, row, snapshot, authority)) {
          // A fenced deferral preserves the frozen receipt without starving later sources.
          db.prepare(
            "UPDATE classification_work SET next_attempt_at=? WHERE id=? AND generation=? AND state=? AND (lease_owner IS NULL OR lease_expires_at<=?)",
          ).run(Date.now() + 5000, row.id, row.generation, row.state, Date.now());
          continue;
        }
        const lease = claimWork(db, row.id, owner);
        if (!lease) {
          continue;
        }
        controller = new AbortController();
        let leaseLost = false;
        const renewal = setInterval(() => {
          try {
            renewWork(db, lease);
          } catch {
            leaseLost = true;
            controller?.abort();
          }
        }, 10000);
        renewal.unref();
        try {
          await deps.process(lease, controller.signal);
        } catch (err) {
          deps.onError(err);
          if (!leaseLost) {
            const latest = getWork(db, row.id);
            try {
              if (latest?.state === "admitted") {
                finishWork(db, lease, "indeterminate", "invocation_interrupted");
              } else if (latest?.state === "received") {
                finishWork(db, lease, "failed", "local_processing_failed");
              } else {
                finishWork(db, lease, "failed", "dispatch_failed");
              }
            } catch {
              /* Successor owns settlement. */
            }
          }
        } finally {
          clearInterval(renewal);
          controller = undefined;
        }
      }
      if (!stopped) {
        controller = new AbortController();
        try {
          await deps.deliver(controller.signal);
        } finally {
          controller = undefined;
        }
      }
    })()
      .catch(deps.onError)
      .finally(() => {
        current = undefined;
      });
    return current;
  };
  const interval = setInterval(() => {
    void tick();
  }, 5000);
  interval.unref();
  return {
    tick,
    async stop() {
      stopped = true;
      clearInterval(interval);
      controller?.abort();
      if (current) {
        await Promise.race([
          current,
          new Promise<void>((resolve) => {
            const timer = setTimeout(resolve, 31000);
            timer.unref();
          }),
        ]);
      }
      return current === undefined;
    },
  };
}
