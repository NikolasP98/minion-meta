import crypto from "node:crypto";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { afterEach, it, expect, vi } from "vitest";
import {
  acquireDeliveryEntryLease,
  releaseDeliveryQueueLease,
  readQueuedDelivery,
  readDeliveryTombstone,
  resolveEntryPath,
  resolveFailedDir,
} from "../../../src/infra/outbound/delivery-queue-files.js";
import {
  enqueueDelivery,
  checkpointQueuedPayload,
} from "../../../src/infra/outbound/delivery-queue-store.js";
import type { MinionPluginApi } from "../../../src/plugins/types.js";
import type { ResolvedConfig } from "../index.js";
import { createCertifiedWatcher } from "./certified-runtime.js";
import { redactExpiredWork, type DeliveryRow } from "./classification-work.js";
import { drainDeliveryReceipts } from "./delivery-bridge.js";
import { snapshotHash } from "./provenance.js";
import { positiveFixture } from "./work-test-fixtures.js";
const dirs: string[] = [];
afterEach(() => {
  vi.restoreAllMocks();
  for (const dir of dirs.splice(0)) {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});
function fixture(count = 1) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "live-retention-"));
  dirs.push(dir);
  return {
    dir,
    ...positiveFixture(
      dir,
      Array.from({ length: count }, (_, i) => ({
        channel: "telegram",
        accountId: "default",
        to: `owner-${i}`,
      })),
    ),
  };
}
async function enqueue(f: ReturnType<typeof fixture>, row: DeliveryRow) {
  await enqueueDelivery(
    {
      id: row.id,
      channel: "telegram",
      accountId: "default",
      to: JSON.parse(row.recipient_json!).to,
      payloads: JSON.parse(row.payload_json!),
      completionPolicy: "caller",
      callerRetention: {
        version: 1,
        owner: "alert-watcher",
        namespaceHash: snapshotHash("namespace"),
        receiptId: row.id,
        payloadHash: row.payload_hash,
        recipientHash: row.recipient_hash,
        expiresAt: row.payload_expires_at,
      },
    },
    f.dir,
  );
}
function watcher(f: ReturnType<typeof fixture>) {
  const api = {
    config: {},
    runtime: { config: { loadConfig: () => ({}) } },
    logger: { warn: vi.fn() },
  } as unknown as MinionPluginApi;
  return createCertifiedWatcher(
    api,
    f.db,
    f.dir,
    () => ({ subscriptions: [], destinations: [] }) as unknown as ResolvedConfig,
    () => {
      throw Error("must not classify");
    },
  );
}
for (const state of ["indeterminate", "failed", "canceled", "sent"] as const) {
  it(`live tick expires ${state} raw/failed copies without changing external-effect truth`, async () => {
    const f = fixture(),
      row = f.db.prepare("SELECT * FROM alert_delivery_receipts").get() as DeliveryRow;
    await enqueue(f, row);
    let acceptedAt: number | undefined;
    if (state === "indeterminate" || state === "sent") {
      const lease = await acquireDeliveryEntryLease(row.id, f.dir);
      let entry = await readQueuedDelivery(row.id, f.dir);
      entry = await checkpointQueuedPayload({
        id: row.id,
        payloadId: entry.payloads[0].id,
        expectedGeneration: entry.generation,
        nextState: "in-flight",
        lease,
        stateDir: f.dir,
      });
      if (state === "sent") {
        entry = await checkpointQueuedPayload({
          id: row.id,
          payloadId: entry.payloads[0].id,
          expectedGeneration: entry.generation,
          nextState: "accepted",
          providerMessageIds: ["private-provider-id"],
          lease,
          stateDir: f.dir,
        });
        acceptedAt = entry.payloads[0].acceptedAt;
      }
      await releaseDeliveryQueueLease(lease);
    }
    f.db
      .prepare(
        "UPDATE alert_delivery_receipts SET state=?,queue_generation=0,admitted_at=?,safe_reason='fixture_terminal',provider_receipts='[]' WHERE id=?",
      )
      .run(state, Date.now(), row.id);
    // Failed-directory copies carry the same body, mirror and errors; expiry
    // cannot depend on the normal executable root file still existing.
    const raw = resolveEntryPath(row.id, f.dir),
      failed = path.join(resolveFailedDir(f.dir), `${row.id}.json`);
    if (state === "failed") {
      fs.renameSync(raw, failed);
    } else {
      fs.copyFileSync(raw, raw + `.bak-${process.pid}-${crypto.randomUUID()}`);
    }
    vi.spyOn(Date, "now").mockReturnValue(row.payload_expires_at + 1);
    const w = watcher(f);
    await w.tick();
    await w.stop();
    expect(fs.existsSync(raw)).toBe(false);
    expect(fs.existsSync(failed)).toBe(false);
    const tombstone = await readDeliveryTombstone(row.id, f.dir);
    expect(tombstone?.reason).toBe("expired");
    expect(tombstone?.payloads[0].state).toBe(
      state === "sent" ? "accepted" : state === "indeterminate" ? "uncertain" : "pending",
    );
    if (state === "sent") {
      expect(tombstone?.payloads[0].acceptedAt).toBe(acceptedAt);
    }
    expect(
      f.db.prepare("SELECT state,queue_generation FROM alert_delivery_receipts").get(),
    ).toEqual({ state, queue_generation: -1 });
    expect(f.db.prepare("SELECT snapshot FROM classification_work").get()).toEqual({
      snapshot: null,
    });
    expect(f.db.prepare("SELECT count(*) n FROM pending_replies").get()).toEqual({ n: 0 });
    f.db.close();
  });
}
it("live terminal housekeeping retries unlink failures behind tombstone and bounds each tick to ten receipts", async () => {
  const f = fixture(11),
    rows = f.db
      .prepare("SELECT * FROM alert_delivery_receipts ORDER BY rowid")
      .all() as DeliveryRow[];
  for (const row of rows) {
    await enqueue(f, row);
  }
  f.db
    .prepare(
      "UPDATE alert_delivery_receipts SET state='indeterminate',admitted_at=1,safe_reason='fixture_terminal'",
    )
    .run();
  let clock = rows[0].payload_expires_at + 1;
  vi.spyOn(Date, "now").mockImplementation(() => clock);
  const original = fs.promises.unlink.bind(fs.promises),
    fault = vi.spyOn(fs.promises, "unlink").mockImplementation(async (file) => {
      if (String(file) === resolveEntryPath(rows[0].id, f.dir)) {
        throw Error("unlink fault");
      }
      return original(file);
    });
  const w = watcher(f);
  await w.tick();
  expect(await readDeliveryTombstone(rows[0].id, f.dir)).toBeDefined();
  await expect(readQueuedDelivery(rows[0].id, f.dir)).rejects.toThrow("tombstone");
  expect(
    f.db.prepare("SELECT count(*) n FROM alert_delivery_receipts WHERE queue_generation=-1").get(),
  ).toEqual({ n: 9 });
  expect(fs.existsSync(resolveEntryPath(rows[10].id, f.dir))).toBe(true);
  fault.mockRestore();
  clock += 5001;
  await w.tick();
  await w.stop();
  expect(
    f.db.prepare("SELECT count(*) n FROM alert_delivery_receipts WHERE queue_generation=-1").get(),
  ).toEqual({ n: 11 });
  for (const row of rows) {
    expect(fs.existsSync(resolveEntryPath(row.id, f.dir))).toBe(false);
  }
  expect(f.db.prepare("SELECT count(*) n FROM pending_replies").get()).toEqual({ n: 0 });
  f.db.close();
});

it("actual recovered uncertain bridge outcome is cleaned by later watcher tick without restart", async () => {
  const f = fixture(),
    row = f.db.prepare("SELECT * FROM alert_delivery_receipts").get() as DeliveryRow;
  await enqueue(f, row);
  const lease = await acquireDeliveryEntryLease(row.id, f.dir),
    entry = await readQueuedDelivery(row.id, f.dir);
  await checkpointQueuedPayload({
    id: row.id,
    payloadId: entry.payloads[0].id,
    expectedGeneration: entry.generation,
    nextState: "in-flight",
    lease,
    stateDir: f.dir,
  });
  await releaseDeliveryQueueLease(lease);
  f.db.prepare("UPDATE alert_delivery_receipts SET state='admitted',admitted_at=1").run();
  const send = vi.fn();
  await drainDeliveryReceipts(f.db, {
    stateDir: f.dir,
    config: () => ({}),
    authority: async () => f.snapshot.authority,
    destinations: () => f.snapshot.destinations,
    send,
  });
  expect(f.db.prepare("SELECT state FROM alert_delivery_receipts").get()).toEqual({
    state: "indeterminate",
  });
  vi.spyOn(Date, "now").mockReturnValue(row.payload_expires_at + 1);
  const w = watcher(f);
  await w.tick();
  await w.stop();
  expect(send).not.toHaveBeenCalled();
  expect(fs.existsSync(resolveEntryPath(row.id, f.dir))).toBe(false);
  expect((await readDeliveryTombstone(row.id, f.dir))?.payloads[0].state).toBe("uncertain");
  f.db.close();
});

for (const mode of ["unknown", "accepted", "legacy-hash"] as const) {
  const known = mode === "accepted",
    wasSent = mode !== "unknown";
  it(`partial-temp-only terminal cleanup preserves ${mode} across fsync/unlink faults and a fresh disabled process`, async () => {
    const { spawn } = await import("node:child_process"),
      { fileURLToPath } = await import("node:url");
    const f = fixture(),
      row = f.db.prepare("SELECT * FROM alert_delivery_receipts").get() as DeliveryRow;
    const copy = resolveEntryPath(row.id, f.dir) + `.tmp-${process.pid}-${crypto.randomUUID()}`;
    fs.mkdirSync(path.dirname(copy), { recursive: true });
    fs.writeFileSync(copy, '{"private":"incomplete private alert');
    const acceptedAt = Date.now(),
      payloadId = crypto.randomUUID(),
      receipts = known
        ? [
            {
              id: payloadId,
              acceptedAt,
              receipt: {
                providerMessageIdCount: 1,
                providerMessageIds: ["private-accepted-id"],
                truncated: false,
              },
            },
          ]
        : [];
    f.db
      .prepare(
        "UPDATE alert_delivery_receipts SET state=?,admitted_at=1,safe_reason='checkpoint_missing',queue_generation=13,provider_receipts=? WHERE id=?",
      )
      .run(
        wasSent ? "sent" : "indeterminate",
        mode === "legacy-hash"
          ? JSON.stringify({ receiptHash: snapshotHash("legacy-evidence") })
          : JSON.stringify(receipts),
        row.id,
      );
    if (wasSent) {
      f.db.prepare("UPDATE classification_work SET first_sent_at=?").run(acceptedAt);
    }
    let clock = row.payload_expires_at + 1;
    vi.spyOn(Date, "now").mockImplementation(() => clock);
    const open = fs.promises.open.bind(fs.promises),
      fault = vi.spyOn(fs.promises, "open").mockImplementation(async (...args) => {
        const handle = await open(...args);
        if (String(args[0]).includes(".retained") && String(args[0]).includes(".tmp-")) {
          handle.sync = async () => {
            throw Error("fsync fault");
          };
        }
        return handle;
      });
    const w = watcher(f);
    await w.tick();
    expect(await readDeliveryTombstone(row.id, f.dir)).toBeUndefined();
    expect(fs.existsSync(copy)).toBe(true);
    fault.mockRestore();
    clock += 5001;
    const unlink = fs.promises.unlink.bind(fs.promises),
      removeFault = vi.spyOn(fs.promises, "unlink").mockImplementation(async (file) => {
        if (String(file) === copy) {
          throw Error("unlink fault");
        }
        return unlink(file);
      });
    await w.tick();
    await w.stop();
    removeFault.mockRestore();
    const tombstone = await readDeliveryTombstone(row.id, f.dir);
    expect(tombstone).toMatchObject({
      id: row.id,
      generation: 13,
      namespaceHash: snapshotHash("namespace"),
      payloadHash: row.payload_hash,
      recipientHash: row.recipient_hash,
      reason: "expired",
      outcomeUncertain: true,
    });
    expect(tombstone?.payloads).toHaveLength(known ? 1 : 0);
    if (known) {
      expect(tombstone?.payloads[0]).toMatchObject({
        id: payloadId,
        state: "accepted",
        acceptedAt,
      });
      expect(tombstone?.payloads[0].receipt?.providerMessageIds[0]).toMatch(/^[a-f0-9]{64}$/);
    }
    const minimal = JSON.parse(
      String(
        f.db.prepare("SELECT provider_receipts FROM alert_delivery_receipts").get()!
          .provider_receipts,
      ),
    );
    expect(JSON.stringify(minimal)).not.toContain("private");
    if (mode === "legacy-hash") {
      expect(minimal.receiptHash).toBe(snapshotHash("legacy-evidence"));
    }
    if (known) {
      expect(tombstone?.payloads[0].receipt?.providerMessageIds[0]).toBe(
        crypto.createHash("sha256").update("private-accepted-id").digest("hex"),
      );
    }
    expect(fs.existsSync(copy)).toBe(true);
    await expect(readQueuedDelivery(row.id, f.dir)).rejects.toThrow("tombstone");
    const child = spawn(
      process.execPath,
      [
        "--import",
        "tsx",
        fileURLToPath(new URL("../test-support/retention-process.ts", import.meta.url)),
        f.dir,
      ],
      {
        stdio: ["ignore", "pipe", "pipe"],
        env: {
          ...process.env,
          MINION_STATE_DIR: f.dir,
          OPENCLAW_STATE_DIR: f.dir,
          MINION_CONFIG_PATH: path.join(f.dir, "config.json"),
          OPENCLAW_CONFIG_PATH: path.join(f.dir, "config.json"),
        },
      },
    );
    let stderr = "";
    child.stderr?.on("data", (chunk) => {
      stderr += String(chunk);
    });
    const code = await new Promise((resolve) => child.once("exit", resolve));
    expect(code, stderr).toBe(0);
    expect(fs.existsSync(copy)).toBe(false);
    expect(fs.existsSync(path.join(f.dir, "unexpected-recovery-send"))).toBe(false);
    expect(await readDeliveryTombstone(row.id, f.dir)).toEqual(tombstone);
    expect(f.db.prepare("SELECT state FROM alert_delivery_receipts").get()).toEqual({
      state: wasSent ? "sent" : "indeterminate",
    });
    expect(f.db.prepare("SELECT first_sent_at FROM classification_work").get()).toEqual({
      first_sent_at: wasSent ? acceptedAt : null,
    });
    f.db.close();
  }, 20000);
}

it("an existing tombstone without the additive uncertainty field survives fresh-process cleanup unchanged", async () => {
  const { enforceDeliveryRetention } =
    await import("../../../src/infra/outbound/delivery-queue-files.js");
  const { spawn } = await import("node:child_process"),
    { fileURLToPath } = await import("node:url");
  const f = fixture(),
    row = f.db.prepare("SELECT * FROM alert_delivery_receipts").get() as DeliveryRow;
  await enqueue(f, row);
  const raw = fs.readFileSync(resolveEntryPath(row.id, f.dir), "utf8");
  const lease = await acquireDeliveryEntryLease(row.id, f.dir),
    entry = await readQueuedDelivery(row.id, f.dir);
  vi.spyOn(Date, "now").mockReturnValue(row.payload_expires_at + 1);
  try {
    await enforceDeliveryRetention(entry, lease, f.dir);
  } finally {
    await releaseDeliveryQueueLease(lease);
  }
  const original = await readDeliveryTombstone(row.id, f.dir);
  expect(original).toBeDefined();
  expect(original?.outcomeUncertain).toBeUndefined();
  const copy = resolveEntryPath(row.id, f.dir) + `.bak-${process.pid}-${crypto.randomUUID()}`;
  fs.writeFileSync(copy, raw);
  const child = spawn(
    process.execPath,
    [
      "--import",
      "tsx",
      fileURLToPath(new URL("../test-support/retention-process.ts", import.meta.url)),
      f.dir,
    ],
    {
      stdio: ["ignore", "pipe", "pipe"],
      env: {
        ...process.env,
        MINION_STATE_DIR: f.dir,
        OPENCLAW_STATE_DIR: f.dir,
        MINION_CONFIG_PATH: path.join(f.dir, "config.json"),
        OPENCLAW_CONFIG_PATH: path.join(f.dir, "config.json"),
      },
    },
  );
  let stderr = "";
  child.stderr?.on("data", (chunk) => {
    stderr += String(chunk);
  });
  const code = await new Promise((resolve) => child.once("exit", resolve));
  expect(code, stderr).toBe(0);
  expect(fs.existsSync(copy)).toBe(false);
  expect(await readDeliveryTombstone(row.id, f.dir)).toEqual(original);
  expect(fs.existsSync(path.join(f.dir, "unexpected-recovery-send"))).toBe(false);
  f.db.close();
}, 20000);

it("backup-only cleanup preserves newer authoritative accepted evidence without double hashing", async () => {
  const f = fixture(),
    row = f.db.prepare("SELECT * FROM alert_delivery_receipts").get() as DeliveryRow;
  await enqueue(f, row);
  const entry = await readQueuedDelivery(row.id, f.dir),
    acceptedAt = Date.now(),
    payloadId = entry.payloads[0].id;
  const hash = crypto.createHash("sha256").update("private-accepted-id").digest("hex");
  const evidence = {
    receiptHash: snapshotHash("accepted evidence"),
    acceptances: [
      {
        id: payloadId,
        state: "accepted",
        acceptedAt,
        receipt: { providerMessageIdCount: 1, providerMessageIds: [hash], truncated: false },
      },
    ],
  };
  f.db
    .prepare(
      "UPDATE alert_delivery_receipts SET state='sent',admitted_at=1,queue_generation=17,provider_receipts=? WHERE id=?",
    )
    .run(JSON.stringify(evidence), row.id);
  f.db.prepare("UPDATE classification_work SET first_sent_at=?").run(acceptedAt);
  const raw = resolveEntryPath(row.id, f.dir),
    copy = raw + `.bak-${process.pid}-${crypto.randomUUID()}`;
  fs.renameSync(raw, copy);
  vi.spyOn(Date, "now").mockReturnValue(row.payload_expires_at + 1);
  const w = watcher(f);
  await w.tick();
  await w.stop();
  const tombstone = await readDeliveryTombstone(row.id, f.dir);
  expect(tombstone?.generation).toBe(17);
  expect(tombstone?.payloads).toEqual(evidence.acceptances);
  expect(fs.existsSync(copy)).toBe(false);
  expect(f.db.prepare("SELECT first_sent_at FROM classification_work").get()).toEqual({
    first_sent_at: acceptedAt,
  });
  expect(f.db.prepare("SELECT state FROM alert_delivery_receipts").get()).toEqual({
    state: "sent",
  });
  expect(JSON.stringify(tombstone)).not.toContain("private");
  f.db.close();
});

it("acceptance settled from a tombstone before the next work-redaction batch is never hashed twice", async () => {
  const f = fixture(),
    row = f.db.prepare("SELECT * FROM alert_delivery_receipts").get() as DeliveryRow;
  await enqueue(f, row);
  const lease = await acquireDeliveryEntryLease(row.id, f.dir);
  let entry = await readQueuedDelivery(row.id, f.dir);
  entry = await checkpointQueuedPayload({
    id: row.id,
    payloadId: entry.payloads[0].id,
    expectedGeneration: entry.generation,
    nextState: "in-flight",
    lease,
    stateDir: f.dir,
  });
  entry = await checkpointQueuedPayload({
    id: row.id,
    payloadId: entry.payloads[0].id,
    expectedGeneration: entry.generation,
    nextState: "accepted",
    providerMessageIds: ["private-provider-id"],
    lease,
    stateDir: f.dir,
  });
  await releaseDeliveryQueueLease(lease);
  f.db
    .prepare("UPDATE alert_delivery_receipts SET state='admitted',admitted_at=1 WHERE id=?")
    .run(row.id);
  vi.spyOn(Date, "now").mockReturnValue(row.payload_expires_at + 1);
  const send = vi.fn();
  // Simulate a later work's expired recipient settling before the bounded
  // ten-work compaction batch reaches its classification row.
  await drainDeliveryReceipts(f.db, {
    stateDir: f.dir,
    config: () => ({}),
    authority: async () => f.snapshot.authority,
    destinations: () => f.snapshot.destinations,
    send,
  });
  const before = JSON.parse(
    String(
      f.db.prepare("SELECT provider_receipts FROM alert_delivery_receipts").get()!
        .provider_receipts,
    ),
  );
  const digest = crypto.createHash("sha256").update("private-provider-id").digest("hex");
  expect(before.acceptances[0].receipt.providerMessageIds).toEqual([digest]);
  expect(f.db.prepare("SELECT state FROM alert_delivery_receipts").get()).toEqual({
    state: "sent",
  });
  expect(f.db.prepare("SELECT redacted_at FROM classification_work").get()).toEqual({
    redacted_at: null,
  });
  redactExpiredWork(f.db);
  const after = JSON.parse(
    String(
      f.db.prepare("SELECT provider_receipts FROM alert_delivery_receipts").get()!
        .provider_receipts,
    ),
  );
  expect(after.receiptHash).toBe(before.receiptHash);
  expect(after.acceptances[0].receipt.providerMessageIds).toEqual([digest]);
  expect(
    (await readDeliveryTombstone(row.id, f.dir))?.payloads[0].receipt?.providerMessageIds,
  ).toEqual([digest]);
  expect(f.db.prepare("SELECT first_sent_at FROM classification_work").get()).toEqual({
    first_sent_at: entry.payloads[0].acceptedAt,
  });
  expect(send).not.toHaveBeenCalled();
  expect(JSON.stringify(after)).not.toContain("private");
  f.db.close();
});
