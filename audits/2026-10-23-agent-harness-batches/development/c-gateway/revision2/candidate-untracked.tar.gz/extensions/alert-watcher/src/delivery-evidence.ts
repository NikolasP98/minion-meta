import crypto from "node:crypto";
import type { DeliveryTombstone } from "../../../src/infra/outbound/delivery-queue-files.js";
import { snapshotHash } from "./provenance.js";
const record = (value: unknown): value is Record<string, unknown> =>
  value !== null && typeof value === "object" && !Array.isArray(value);
/** Read both original acceptance arrays and additive, already-redacted evidence.
 * Historical hash-only rows remain valid and cannot invent payload acceptance. */
export function deliveryAcceptances(serialized: string | null): {
  payloads: DeliveryTombstone["payloads"];
  receiptsHashed: boolean;
} {
  const value: unknown = serialized ? JSON.parse(serialized) : null;
  const receiptsHashed = record(value),
    candidates = Array.isArray(value)
      ? value
      : record(value) && Array.isArray(value.acceptances)
        ? value.acceptances
        : [];
  const payloads: DeliveryTombstone["payloads"] = [];
  for (const item of candidates.slice(0, 256)) {
    if (
      !record(item) ||
      typeof item.id !== "string" ||
      !/^[A-Za-z0-9_-]{1,128}$/.test(item.id) ||
      !Number.isSafeInteger(item.acceptedAt) ||
      Number(item.acceptedAt) <= 0 ||
      !record(item.receipt)
    ) {
      continue;
    }
    const receipt = item.receipt;
    if (
      !Number.isSafeInteger(receipt.providerMessageIdCount) ||
      Number(receipt.providerMessageIdCount) < 0 ||
      !Array.isArray(receipt.providerMessageIds) ||
      receipt.providerMessageIds.length > 32 ||
      !receipt.providerMessageIds.every(
        (id: unknown) => typeof id === "string" && id.length <= 2048,
      )
    ) {
      continue;
    }
    if (
      receiptsHashed &&
      !receipt.providerMessageIds.every(
        (id: unknown) => typeof id === "string" && /^[a-f0-9]{64}$/.test(id),
      )
    ) {
      continue;
    }
    payloads.push({
      id: item.id,
      state: "accepted",
      acceptedAt: Number(item.acceptedAt),
      receipt: {
        providerMessageIdCount: Number(receipt.providerMessageIdCount),
        providerMessageIds: receipt.providerMessageIds as string[],
        truncated: receipt.truncated === true,
      },
    });
  }
  return { payloads, receiptsHashed };
}
export function redactDeliveryEvidence(serialized: string): string {
  const { payloads, receiptsHashed } = deliveryAcceptances(serialized);
  const value: unknown = JSON.parse(serialized);
  const receiptHash =
    record(value) &&
    typeof value.receiptHash === "string" &&
    /^[a-f0-9]{64}$/.test(value.receiptHash)
      ? value.receiptHash
      : snapshotHash(value);
  return JSON.stringify({
    receiptHash,
    acceptances: payloads.map((payload) => ({
      ...payload,
      receipt: payload.receipt
        ? {
            ...payload.receipt,
            providerMessageIds: payload.receipt.providerMessageIds.map((id) =>
              receiptsHashed ? id : crypto.createHash("sha256").update(id).digest("hex"),
            ),
          }
        : undefined,
    })),
  });
}
