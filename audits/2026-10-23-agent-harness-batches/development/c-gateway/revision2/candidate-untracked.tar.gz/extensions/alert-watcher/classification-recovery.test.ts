import { spawn, type ChildProcess } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { afterEach, it, expect } from "vitest";
import {
  admitSource,
  getWork,
  recoverExpiredInvocations,
  claimWork,
  finishWork,
} from "./src/classification-work.js";
import { testDb, workFixture } from "./src/work-test-fixtures.js";
const children: ChildProcess[] = [],
  dirs: string[] = [];
afterEach(() => {
  for (const child of children.splice(0)) {
    child.kill("SIGKILL");
  }
  for (const dir of dirs.splice(0)) {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});
function message(child: ChildProcess): Promise<{ stage: string }> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(Error("child barrier timeout")), 10000);
    child.once("message", (value) => {
      clearTimeout(timer);
      resolve(value as { stage: string });
    });
    child.once("error", reject);
  });
}
function child(file: string, id: string, stage: string, marker: string) {
  const c = spawn(
    process.execPath,
    [
      "--import",
      "tsx",
      fileURLToPath(new URL("./test-support/work-process.ts", import.meta.url)),
      file,
      id,
      stage,
      marker,
    ],
    {
      stdio: ["ignore", "pipe", "pipe", "ipc"],
      env: { ...process.env, ANTHROPIC_API_KEY: "", OPENAI_API_KEY: "" },
    },
  );
  children.push(c);
  return c;
}
function fixture() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "watcher-process-"));
  dirs.push(dir);
  const file = path.join(dir, "alerts.db"),
    db = testDb(file);
  const admitted = admitSource(db, "namespace", workFixture());
  if (admitted.kind !== "admitted") {
    throw Error();
  }
  return { dir, file, db, id: admitted.work.id, marker: path.join(dir, "calls") };
}
it("two independent SQLite processes contend for one due generation", async () => {
  const f = fixture(),
    a = child(f.file, f.id, "claim", f.marker),
    b = child(f.file, f.id, "claim", f.marker);
  await Promise.all([message(a), message(b)]);
  const replies = [message(a), message(b)];
  a.send("go");
  b.send("go");
  expect((await Promise.all(replies)).map((r) => r.stage).sort()).toEqual(["claimed", "unclaimed"]);
  f.db.close();
}, 20000);
for (const stage of ["admitted", "provider-marker", "response", "received"]) {
  it(`kill after ${stage} retains durable disposition and never replays inference`, async () => {
    const f = fixture(),
      c = child(f.file, f.id, stage, f.marker);
    await message(c);
    const barrier = message(c);
    c.send("go");
    expect((await barrier).stage).toBe(stage);
    c.kill("SIGKILL");
    await new Promise((resolve) => c.once("exit", resolve));
    recoverExpiredInvocations(f.db, Date.now() + 31000);
    const row = getWork(f.db, f.id)!;
    if (stage === "provider-marker") {
      expect(JSON.parse(row.attempts_json)[0].dispatchStatus).toBe("may_have_submitted");
    }
    if (stage === "received") {
      expect(row.state).toBe("received");
      const lease = claimWork(f.db, f.id, "recovery", Date.now() + 31000)!;
      finishWork(f.db, lease, "completed", undefined, Date.now() + 31000);
      expect(getWork(f.db, f.id)?.state).toBe("completed");
    } else {
      expect(row.state).toBe("indeterminate");
      expect(claimWork(f.db, f.id, "recovery", Date.now() + 31000)).toBeUndefined();
    }
    expect(
      fs.existsSync(f.marker) ? fs.readFileSync(f.marker, "utf8").trim().split("\n").length : 0,
    ).toBe(["admitted", "provider-marker"].includes(stage) ? 0 : 1);
    f.db.close();
  }, 20000);
}
