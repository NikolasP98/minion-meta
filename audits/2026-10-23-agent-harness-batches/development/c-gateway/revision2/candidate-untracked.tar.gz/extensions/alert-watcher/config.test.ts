import fs from "node:fs";
import { Ajv } from "ajv";
import { it, expect } from "vitest";
import { resolveConfig } from "./index.js";
const manifest = JSON.parse(
  fs.readFileSync(new URL("./minion.plugin.json", import.meta.url), "utf8"),
);
it("strict manifest and actual resolver agree on omitted/off/census/shadow and reject active/extra/malformed config", () => {
  const ajv = new Ajv({ strict: false });
  const validate = ajv.compile(manifest.configSchema);
  for (const value of [undefined, {}, { mode: "off" }, { mode: "census" }, { mode: "shadow" }]) {
    const config = value === undefined ? {} : { complaintExperiment: value };
    expect(validate(config)).toBe(true);
    expect(resolveConfig(config).complaintExperiment.mode).toBe(value?.mode ?? "off");
  }
  for (const value of [
    null,
    [],
    "shadow",
    { mode: 1 },
    { mode: "active" },
    { mode: "shadow", approved: true },
  ]) {
    expect(validate({ complaintExperiment: value })).toBe(false);
    expect(() => resolveConfig({ complaintExperiment: value })).toThrow();
  }
});
