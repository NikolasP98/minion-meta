import { spawn, type ChildProcess } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { afterEach, it, expect } from "vitest";
import { testDb } from "./src/work-test-fixtures.js";
const children: ChildProcess[] = [],
  directories: string[] = [];
afterEach(() => {
  for (const child of children.splice(0)) {
    child.kill("SIGKILL");
  }
  for (const directory of directories.splice(0)) {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});
function launch(directory: string, stage: string) {
  const child = spawn(
    process.execPath,
    [
      "--import",
      "tsx",
      fileURLToPath(new URL("./test-support/suggestion-process.ts", import.meta.url)),
      directory,
      stage,
    ],
    {
      stdio: ["ignore", "pipe", "pipe"],
      env: {
        ...process.env,
        MINION_STATE_DIR: directory,
        OPENCLAW_STATE_DIR: directory,
        MINION_CONFIG_PATH: path.join(directory, "config.json"),
        OPENCLAW_CONFIG_PATH: path.join(directory, "config.json"),
        ANTHROPIC_API_KEY: "",
        OPENAI_API_KEY: "",
      },
    },
  );
  children.push(child);
  let stderr = "";
  child.stderr?.on("data", (chunk) => {
    stderr += String(chunk);
  });
  return { child, stderr: () => stderr };
}
async function barrier(directory: string, process: ReturnType<typeof launch>) {
  for (let i = 0; i < 800; i++) {
    if (fs.existsSync(path.join(directory, "barrier"))) {
      return fs.readFileSync(path.join(directory, "barrier"), "utf8");
    }
    if (process.child.exitCode !== null) {
      throw Error(process.stderr());
    }
    await new Promise((resolve) => setTimeout(resolve, 25));
  }
  throw Error(`barrier timeout: ${process.stderr()}`);
}
function calls(directory: string, name: string) {
  const file = path.join(directory, name);
  return fs.existsSync(file) ? fs.readFileSync(file, "utf8").trim().split("\n").length : 0;
}
for (const stage of ["admitted", "received", "materialized"]) {
  it(`actual watcher suggestion kill after ${stage} never recalls and recovers locally`, async () => {
    const directory = fs.mkdtempSync(path.join(os.tmpdir(), "suggestion-process-"));
    directories.push(directory);
    const running = launch(directory, stage);
    expect(await barrier(directory, running)).toBe(stage);
    const exit = new Promise((resolve) => running.child.once("exit", resolve));
    running.child.kill("SIGKILL");
    await exit;
    const db = testDb(path.join(directory, "alerts.db"));
    const before = db
      .prepare("SELECT suggestion_json,complaint_id FROM classification_work")
      .get()!;
    const suggestion = JSON.parse(String(before.suggestion_json));
    expect(suggestion.state).toBe(stage === "admitted" ? "admitted" : "received");
    expect(calls(directory, "provider-calls")).toBe(stage === "admitted" ? 0 : 1);
    expect(calls(directory, "send-calls")).toBe(0);
    if (stage === "materialized") {
      expect(db.prepare("SELECT count(*) n FROM alert_delivery_receipts").get()).toEqual({ n: 1 });
    }
    db.close();
    const recovery = launch(directory, "recover");
    const code = await new Promise((resolve) => recovery.child.once("exit", resolve));
    expect(code, recovery.stderr()).toBe(0);
    const recovered = testDb(path.join(directory, "alerts.db"));
    const row = recovered.prepare("SELECT state,suggestion_json FROM classification_work").get()!;
    expect(row.state).toBe("completed");
    const after = JSON.parse(String(row.suggestion_json));
    expect(after.attemptId).toBe(suggestion.attemptId);
    expect(after.state).toBe(stage === "admitted" ? "indeterminate" : "received");
    if (stage !== "admitted") {
      expect(after.suggestions).toEqual(["alpha", "beta", "gamma"]);
      expect(after.usage).toEqual(suggestion.usage);
    }
    expect(recovered.prepare("SELECT count(*) n FROM complaints").get()).toEqual({ n: 1 });
    expect(
      recovered.prepare("SELECT count(*) n FROM alert_delivery_receipts WHERE state='sent'").get(),
    ).toEqual({ n: 1 });
    expect(recovered.prepare("SELECT count(*) n FROM pending_replies").get()).toEqual({ n: 1 });
    expect(calls(directory, "provider-calls")).toBe(stage === "admitted" ? 0 : 1);
    expect(calls(directory, "send-calls")).toBe(1);
    recovered.close();
  }, 30000);
}
