import crypto from "node:crypto";
import type { DatabaseSync } from "node:sqlite";
import type { MinionConfig } from "../../../src/config/config.js";
import { deliverOutboundPayloadsWithOutcome } from "../../../src/infra/outbound/deliver.js";
import {
  acquireDeliveryEntryLease,
  releaseDeliveryQueueLease,
  readQueuedDelivery,
  readDeliveryTombstone,
  enforceDeliveryRetention,
  retireExpiredCallerDelivery,
  type DeliveryTombstone,
} from "../../../src/infra/outbound/delivery-queue-files.js";
import {
  acknowledgeCallerManagedDelivery,
  markRecoveredInFlightUncertain,
} from "../../../src/infra/outbound/delivery-queue-store.js";
import type { QueuedDelivery } from "../../../src/infra/outbound/delivery-queue-types.js";
import type { OutboundChannel } from "../../../src/infra/outbound/targets.js";
import { sameAuthority, type WatcherAuthority } from "./authority.js";
import {
  getWork,
  observeWorkAuthority,
  immediate,
  boundedJson,
  type DeliveryRow,
  type WorkSnapshot,
  type SuggestionReceipt,
} from "./classification-work.js";
import { deliveryAcceptances } from "./delivery-evidence.js";
import type { Destination } from "./destinations.js";
import { snapshotHash } from "./provenance.js";
import { insertBoundPending } from "./reply-flow/store.js";

export type DeliveryBridgeDeps = {
  signal?: AbortSignal;
  stateDir: string;
  config: () => MinionConfig;
  authority: (snapshot: WorkSnapshot) => Promise<WatcherAuthority>;
  destinations: () => Destination[];
  recipientAllowed?: (snapshot: WorkSnapshot, recipient: Destination) => Promise<boolean>;
  send?: typeof deliverOutboundPayloadsWithOutcome;
  onFirstSent?: (snapshot: WorkSnapshot, at: number) => void;
};
function getDelivery(db: DatabaseSync, id: string): DeliveryRow {
  return db.prepare("SELECT * FROM alert_delivery_receipts WHERE id=?").get(id) as DeliveryRow;
}
function destinationAllowed(recipient: Destination, current: Destination[]): boolean {
  return current.some(
    (d) =>
      snapshotHash([d.channel, d.accountId ?? "default", d.to]) ===
      snapshotHash([recipient.channel, recipient.accountId ?? "default", recipient.to]),
  );
}
export function settleDelivery(
  db: DatabaseSync,
  id: string,
  owner: string,
  generation: number,
  state: "sent" | "failed" | "canceled" | "indeterminate",
  evidence: {
    acceptedAt?: number;
    queueGeneration?: number;
    receipts?: unknown;
    reason?: string;
    authorizedReplyDestinations?: Destination[];
  },
  now = Date.now(),
): { first: boolean; snapshot: WorkSnapshot | null } {
  return immediate(db, () => {
    const row = getDelivery(db, id);
    if (
      row.lease_owner !== owner ||
      row.generation !== generation ||
      (row.lease_expires_at ?? 0) <= now
    ) {
      throw new Error("delivery_lease_lost");
    }
    const work = getWork(db, row.work_id);
    if (!work) {
      throw new Error("missing_work");
    }
    const snapshot = work.snapshot ? (JSON.parse(work.snapshot) as WorkSnapshot) : null;
    if (state === "sent" && (!evidence.acceptedAt || !evidence.receipts)) {
      throw new Error("sent_requires_acceptance");
    }
    const first = state === "sent" && work.first_sent_at === null;
    db.prepare(
      "UPDATE alert_delivery_receipts SET state=?,settled_at=?,queue_generation=?,provider_receipts=?,safe_reason=?,lease_owner=NULL,lease_expires_at=NULL WHERE id=? AND generation=? AND lease_owner=?",
    ).run(
      state,
      now,
      evidence.queueGeneration ?? null,
      evidence.receipts ? boundedJson(evidence.receipts) : null,
      evidence.reason ?? null,
      id,
      generation,
      owner,
    );
    if (first) {
      const at = evidence.acceptedAt!;
      db.prepare(
        "UPDATE classification_work SET first_sent_at=?,receipt_revision=receipt_revision+1 WHERE id=? AND first_sent_at IS NULL",
      ).run(at, work.id);
      if (snapshot?.replyFlow.enabled && work.complaint_id !== null) {
        const suggestion = JSON.parse(work.suggestion_json) as SuggestionReceipt;
        // Only a current, explicitly proven subset may become a fresh local reply grant.
        const recipients = evidence.authorizedReplyDestinations ?? [];
        if (recipients.some((recipient) => !destinationAllowed(recipient, snapshot.destinations))) {
          throw new Error("reply_recipient_binding_conflict");
        }
        const destinations = [...new Set(recipients.map((d) => d.to).filter(Boolean))];
        insertBoundPending(db, {
          alertId: work.complaint_id,
          originChannel: snapshot.source.channel,
          originAccountId: snapshot.source.accountId,
          originChatId: snapshot.source.conversationId,
          destinations,
          suggestions: suggestion.suggestions ?? [],
          language: snapshot.language,
          receiptBinding: snapshotHash([work.id, 1]),
          createdAt: at,
          payloadExpiresAt: work.payload_expires_at,
          expiresAt: Math.min(
            destinations.length ? at + snapshot.replyFlow.windowMs : at,
            work.payload_expires_at,
          ),
        });
      }
      if (!snapshot && work.complaint_id !== null) {
        const binding = JSON.parse(
          (work as typeof work & { evaluation_binding: string }).evaluation_binding,
        ) as { replyEnabled: boolean; replyWindowMs: number };
        if (binding.replyEnabled) {
          insertBoundPending(db, {
            alertId: work.complaint_id,
            originChannel: "",
            originAccountId: null,
            originChatId: "",
            destinations: [],
            suggestions: [],
            language: null,
            receiptBinding: snapshotHash([work.id, 1]),
            createdAt: at,
            payloadExpiresAt: work.payload_expires_at,
            expiresAt: Math.min(at + binding.replyWindowMs, work.payload_expires_at),
          });
        }
      }
      if (work.complaint_id !== null) {
        db.prepare("UPDATE complaints SET notified_at=COALESCE(notified_at,?) WHERE id=?").run(
          at,
          work.complaint_id,
        );
      }
    } else {
      db.prepare(
        "UPDATE classification_work SET receipt_revision=receipt_revision+1 WHERE id=?",
      ).run(work.id);
    }
    return { first, snapshot };
  });
}
/** Resolve only original, currently configured owner grants after external awaits. */
async function authorizedReplyRecipients(
  db: DatabaseSync,
  workId: string,
  snapshot: WorkSnapshot | null,
  deps: DeliveryBridgeDeps,
): Promise<Destination[]> {
  if (!snapshot || !snapshot.replyFlow.enabled) {
    return [];
  }
  const permitted: Destination[] = [];
  for (const recipient of snapshot.destinations) {
    if (!destinationAllowed(recipient, deps.destinations())) {
      continue;
    }
    const bound =
      snapshot.destinationAuthorities?.[
        snapshotHash([recipient.channel, recipient.accountId ?? "default", recipient.to])
      ];
    if (!bound) {
      continue;
    }
    // Same-account source evidence is sufficient for local bridge callers; other
    // accounts require the existing source-qualified recipient authority callback.
    const allowed = deps.recipientAllowed
      ? await deps.recipientAllowed(snapshot, recipient)
      : recipient.channel === snapshot.source.channel &&
        (recipient.accountId ?? "default") === snapshot.source.accountId &&
        sameAuthority(bound, await deps.authority(snapshot));
    if (allowed) {
      permitted.push(recipient);
    }
  }
  const current = await deps.authority(snapshot),
    work = getWork(db, workId);
  if (!work || !observeWorkAuthority(db, work, snapshot, current)) {
    return [];
  }
  return permitted.filter((recipient) => destinationAllowed(recipient, deps.destinations()));
}
/** Bounded live housekeeping is independent of terminal send eligibility. */
async function cleanupExpiredReceipts(db: DatabaseSync, deps: DeliveryBridgeDeps): Promise<void> {
  const rows = db
    .prepare(
      "SELECT r.* FROM alert_delivery_receipts r WHERE r.state IN ('sent','failed','canceled','indeterminate') AND r.payload_expires_at<=? AND COALESCE(r.queue_generation,0)>=0 AND r.next_attempt_at<=? AND (r.lease_owner IS NULL OR r.lease_expires_at<=?) ORDER BY r.next_attempt_at,r.rowid LIMIT 10",
    )
    .all(Date.now(), Date.now(), Date.now()) as DeliveryRow[];
  for (const row of rows) {
    if (deps.signal?.aborted) {
      break;
    }
    const work = getWork(db, row.work_id);
    if (!work) {
      continue;
    }
    try {
      const lease = await acquireDeliveryEntryLease(row.id, deps.stateDir);
      try {
        await retireExpiredCallerDelivery(
          {
            version: 1,
            owner: "alert-watcher",
            namespaceHash: snapshotHash(work.namespace),
            receiptId: row.id,
            payloadHash: row.payload_hash,
            recipientHash: row.recipient_hash,
            expiresAt: row.payload_expires_at,
          },
          lease,
          deps.stateDir,
          {
            generation: row.queue_generation ?? 0,
            ...deliveryAcceptances(row.provider_receipts),
          },
        );
        db.prepare(
          "UPDATE alert_delivery_receipts SET queue_generation=-1 WHERE id=? AND generation=?",
        ).run(row.id, row.generation);
      } finally {
        await releaseDeliveryQueueLease(lease);
      }
    } catch {
      db.prepare(
        "UPDATE alert_delivery_receipts SET next_attempt_at=? WHERE id=? AND generation=?",
      ).run(Date.now() + 5000, row.id, row.generation);
    }
  }
}
/** Reconcile the original queue identity; absence is never permission to enqueue again. */
export async function drainDeliveryReceipts(
  db: DatabaseSync,
  deps: DeliveryBridgeDeps,
): Promise<void> {
  await cleanupExpiredReceipts(db, deps);
  const owner = crypto.randomUUID();
  const sendBound = async (params: Parameters<typeof deliverOutboundPayloadsWithOutcome>[0]) => {
    const timeout = new AbortController();
    const timer = setTimeout(() => timeout.abort(), 30000);
    timer.unref();
    const signal = deps.signal ? AbortSignal.any([deps.signal, timeout.signal]) : timeout.signal;
    try {
      return await Promise.race([
        (deps.send ?? deliverOutboundPayloadsWithOutcome)({ ...params, abortSignal: signal }),
        new Promise<never>((_, reject) => {
          if (signal.aborted) {
            reject(new Error("delivery_interrupted"));
          } else {
            signal.addEventListener("abort", () => reject(new Error("delivery_interrupted")), {
              once: true,
            });
          }
        }),
      ]);
    } finally {
      clearTimeout(timer);
    }
  };
  const rows = db
    .prepare(
      "SELECT * FROM alert_delivery_receipts WHERE (state IN ('queued','admitted') OR (state IN ('sent','canceled') AND queue_generation>=0 AND (state='sent' OR safe_reason='payload_suppressed'))) AND next_attempt_at<=? AND (lease_owner IS NULL OR lease_expires_at<=?) ORDER BY next_attempt_at,rowid LIMIT 10",
    )
    .all(Date.now(), Date.now()) as DeliveryRow[];
  for (const scanned of rows) {
    if (deps.signal?.aborted) {
      break;
    }
    const work = getWork(db, scanned.work_id);
    if (!work) {
      continue;
    }
    const snapshot = work.snapshot ? (JSON.parse(work.snapshot) as WorkSnapshot) : null;
    const recipient = scanned.recipient_json
      ? (JSON.parse(scanned.recipient_json) as Destination)
      : null;
    const authorized =
      !!snapshot &&
      observeWorkAuthority(db, work, snapshot, await deps.authority(snapshot)) &&
      !!recipient &&
      destinationAllowed(recipient, deps.destinations()) &&
      (!deps.recipientAllowed || (await deps.recipientAllowed(snapshot, recipient)));
    if (scanned.state === "sent" || scanned.state === "canceled") {
      try {
        await acknowledgeCallerManagedDelivery(scanned.id, deps.stateDir);
        db.prepare(
          "UPDATE alert_delivery_receipts SET queue_generation=-1 WHERE id=? AND state IN ('sent','canceled')",
        ).run(scanned.id);
      } catch {
        db.prepare(
          "UPDATE alert_delivery_receipts SET next_attempt_at=? WHERE id=? AND state IN ('sent','canceled')",
        ).run(Date.now() + 5000, scanned.id);
      }
      continue;
    }
    const generation = scanned.generation + 1;
    const claimed = db
      .prepare(
        "UPDATE alert_delivery_receipts SET lease_owner=?,generation=?,lease_expires_at=? WHERE id=? AND generation=? AND (lease_owner IS NULL OR lease_expires_at<=?)",
      )
      .run(owner, generation, Date.now() + 30000, scanned.id, scanned.generation, Date.now());
    if (!claimed.changes) {
      continue;
    }
    const leaseRenew = setInterval(() => {
      db.prepare(
        "UPDATE alert_delivery_receipts SET lease_expires_at=? WHERE id=? AND generation=? AND lease_owner=? AND lease_expires_at>?",
      ).run(Date.now() + 30000, scanned.id, generation, owner, Date.now());
    }, 10000);
    leaseRenew.unref();
    const settle = (
      state: "sent" | "failed" | "canceled" | "indeterminate",
      evidence: Parameters<typeof settleDelivery>[5],
    ) => {
      const r = settleDelivery(db, scanned.id, owner, generation, state, evidence);
      if (r.first && r.snapshot) {
        deps.onFirstSent?.(r.snapshot, evidence.acceptedAt!);
      }
    };
    try {
      if (scanned.state === "queued") {
        if (
          !authorized ||
          !snapshot ||
          !recipient ||
          !scanned.payload_json ||
          scanned.payload_expires_at <= Date.now()
        ) {
          settle("canceled", { reason: "recipient_unavailable" });
          continue;
        }
        // Write admission before crossing into queue creation. A crash here is indeterminate.
        db.prepare(
          "UPDATE alert_delivery_receipts SET state='admitted',admitted_at=? WHERE id=? AND generation=? AND lease_owner=?",
        ).run(Date.now(), scanned.id, generation, owner);
        try {
          await sendBound({
            cfg: deps.config(),
            channel: recipient.channel as Exclude<OutboundChannel, "none">,
            accountId: recipient.accountId,
            to: recipient.to,
            payloads: JSON.parse(scanned.payload_json),
            durability: "required",
            queueId: scanned.id,
            completionPolicy: "caller",
            stateDir: deps.stateDir,
            callerRetention: {
              version: 1,
              owner: "alert-watcher",
              namespaceHash: snapshotHash(work.namespace),
              receiptId: scanned.id,
              payloadHash: scanned.payload_hash,
              recipientHash: scanned.recipient_hash,
              expiresAt: scanned.payload_expires_at,
            },
          });
        } catch {
          /* Read queue evidence even when the local send wrapper failed. */
        }
      }
      let terminal: QueuedDelivery | DeliveryTombstone | undefined;
      const queueLease = await acquireDeliveryEntryLease(scanned.id, deps.stateDir);
      try {
        terminal = await readDeliveryTombstone(scanned.id, deps.stateDir);
        if (!terminal) {
          let entry = await readQueuedDelivery(scanned.id, deps.stateDir);
          if (
            !entry.callerRetention ||
            entry.callerRetention.payloadHash !== scanned.payload_hash ||
            entry.callerRetention.recipientHash !== scanned.recipient_hash ||
            entry.callerRetention.namespaceHash !== snapshotHash(work.namespace)
          ) {
            throw new Error("queue_binding_mismatch");
          }
          if (await enforceDeliveryRetention(entry, queueLease, deps.stateDir)) {
            entry = await markRecoveredInFlightUncertain({
              entry,
              lease: queueLease,
              stateDir: deps.stateDir,
            });
            if (
              authorized &&
              entry.payloads.some((p) => p.state === "pending") &&
              !entry.payloads.some((p) => p.state === "uncertain")
            ) {
              const unfinished = entry.payloads.filter((p) => p.state === "pending");
              await sendBound({
                cfg: deps.config(),
                channel: entry.channel,
                to: entry.to,
                accountId: entry.accountId,
                payloads: unfinished.map((p) => p.payload),
                completionPolicy: "caller",
                callerRetention: entry.callerRetention,
                skipQueue: true,
                queueContext: {
                  entryId: entry.id,
                  payloadIds: unfinished.map((p) => p.id),
                  expectedGeneration: entry.generation,
                  stateDir: deps.stateDir,
                  lease: queueLease,
                },
              });
              entry = await readQueuedDelivery(scanned.id, deps.stateDir);
            }
            terminal = entry;
          } else {
            terminal = await readDeliveryTombstone(scanned.id, deps.stateDir);
          }
        }
      } catch {
        settle("indeterminate", { reason: "missing_or_mismatched_queue" });
        continue;
      } finally {
        await releaseDeliveryQueueLease(queueLease);
      }
      if (
        !terminal ||
        ("namespaceHash" in terminal &&
          (terminal.namespaceHash !== snapshotHash(work.namespace) ||
            terminal.payloadHash !== scanned.payload_hash ||
            terminal.recipientHash !== scanned.recipient_hash))
      ) {
        settle("indeterminate", { reason: "missing_or_mismatched_queue" });
        continue;
      }
      const accepted = terminal.payloads.filter(
        (p) => p.state === "accepted" && p.acceptedAt !== undefined,
      );
      // Preserve known external effects even after authority revocation; closed reply only.
      if (
        accepted.length === terminal.payloads.length &&
        accepted.length &&
        !("outcomeUncertain" in terminal && terminal.outcomeUncertain)
      ) {
        const replyRecipients = await authorizedReplyRecipients(db, work.id, snapshot, deps);
        settle("sent", {
          acceptedAt: Math.min(...accepted.map((p) => p.acceptedAt!)),
          queueGeneration: terminal.generation,
          authorizedReplyDestinations: replyRecipients,
          receipts: accepted.map((p) => ({
            id: p.id,
            acceptedAt: p.acceptedAt,
            receipt: p.receipt,
          })),
        });
        await acknowledgeCallerManagedDelivery(scanned.id, deps.stateDir).catch(() => {});
      } else if (
        ("outcomeUncertain" in terminal && terminal.outcomeUncertain) ||
        terminal.payloads.some((p) => p.state === "uncertain" || p.state === "in-flight")
      ) {
        settle("indeterminate", {
          reason: "uncertain_provider",
          queueGeneration: terminal.generation,
          receipts: accepted.map((p) => ({
            id: p.id,
            acceptedAt: p.acceptedAt,
            receipt: p.receipt,
          })),
        });
      } else if ("retiredAt" in terminal) {
        settle("failed", { reason: "payload_expired" });
      } else if (
        terminal.payloads.length &&
        terminal.payloads.every((p) => p.state === "accepted" || p.state === "suppressed")
      ) {
        settle("canceled", {
          reason: "payload_suppressed",
          queueGeneration: terminal.generation,
          receipts: accepted.map((p) => ({
            id: p.id,
            acceptedAt: p.acceptedAt,
            receipt: p.receipt,
          })),
        });
        // The next bounded tick acknowledges only after this durable local settlement.
      } else if (!authorized) {
        settle("indeterminate", { reason: "authority_changed_after_admission" });
      } else {
        db.prepare(
          "UPDATE alert_delivery_receipts SET lease_owner=NULL,lease_expires_at=NULL,next_attempt_at=? WHERE id=? AND generation=? AND lease_owner=?",
        ).run(Date.now() + 5000, scanned.id, generation, owner);
      }
    } catch {
      db.prepare(
        "UPDATE alert_delivery_receipts SET lease_owner=NULL,lease_expires_at=NULL,next_attempt_at=? WHERE id=? AND generation=? AND lease_owner=?",
      ).run(Date.now() + 5000, scanned.id, generation, owner);
    } finally {
      clearInterval(leaseRenew);
    }
  }
}
