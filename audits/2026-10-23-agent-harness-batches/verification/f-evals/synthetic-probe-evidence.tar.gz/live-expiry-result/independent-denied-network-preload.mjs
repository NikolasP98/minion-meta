import fs from 'node:fs';
import net from 'node:net';
import http from 'node:http';
import https from 'node:https';
const deny = () => { throw Error('external network forbidden'); };
net.Socket.prototype.connect=deny; http.request=deny; https.request=deny;
globalThis.fetch=async(url,o)=>{
 if (url!=='https://openrouter.ai/api/v1/chat/completions') throw Error('unallowlisted wire');
 const body=JSON.parse(o.body); if(o.redirect!=='error'||body.provider.allow_fallbacks!==false) throw Error('provider safety shape');
 const entries=fs.readFileSync(process.env.TEST_JOURNAL,'utf8').trim().split('\n').map(JSON.parse);
 if(entries.at(-1).kind!=='dispatched'||!entries.some(e=>e.kind==='reserved'&&e.attemptId===entries.at(-1).attemptId)) throw Error('dispatch lacks durable reservation');
 fs.appendFileSync(process.env.TEST_COUNTER,JSON.stringify({at:Date.now(),url,lastJournalKind:entries.at(-1).kind})+'\n');
 await new Promise(r=>setTimeout(r,400));
 return Response.json({model:body.model,choices:[{message:{content:'fixture answer'}}],usage:{prompt_tokens:2,completion_tokens:2,cost:0.000001}});
};
