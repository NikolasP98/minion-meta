import path from 'node:path';
import { assert, canonical, digest, readJSON, jsonl, args, direct, main } from './lib/common.mjs';
import { dedupe, validateObservation, validateRecord } from './lib/receipts.mjs';
import { pairedBootstrap, summarize } from './lib/statistics.mjs';
import { compileComplaintSchema, complaintReport, loadComplaintInput } from './complaint.mjs';
import { loadManifest } from './lib/manifest.mjs';
const printable = (v) => (Number.isFinite(v) ? v : 'unbounded');
export function analyze(input) {
  assert(input.version === 1 && Array.isArray(input.observations), 'report input');
  const observations = input.observations.map(validateObservation);
  const d = dedupe(observations.map((o) => ({ ...o, id: `${o.episodeId}:${o.arm}:${o.repeat}` })));
  const quarantine = [...d.quarantine];
  const cohorts = new Map();
  for (const row of d.records) {
    const key = digest(row.cohort);
    const rows = cohorts.get(key) ?? [];
    rows.push(row);
    cohorts.set(key, rows);
  }
  const reports = [];
  for (const [cohort, raw] of cohorts) {
    const byEpisode = new Map();
    for (const row of raw) {
      const key = `${row.episodeId}:${row.arm}`;
      const list = byEpisode.get(key) ?? [];
      list.push(row);
      byEpisode.set(key, list);
    }
    const rows = [];
    for (const list of byEpisode.values()) {
      const first = list[0];
      if (list.length > 1 && input.repeatAggregation !== 'all_repeats') {
        quarantine.push(first.episodeId);
        continue;
      }
      rows.push({
        ...first,
        outcome: list.every((x) => x.outcome === 'success')
          ? 'success'
          : list.find((x) => x.outcome !== 'success').outcome,
        costMicroUsd: list.some((x) => x.costMicroUsd === null)
          ? null
          : list.reduce((n, x) => n + x.costMicroUsd, 0),
        upperMicroUsd: list.some((x) => x.upperMicroUsd === null)
          ? null
          : list.reduce((n, x) => n + x.upperMicroUsd, 0),
        latencyMs: list.reduce((n, x) => n + x.latencyMs, 0),
        complete: list.every((x) => x.complete),
        critical: list.flatMap((x) => x.critical),
        costStatus: list.some((x) => x.costStatus === 'unbounded')
          ? 'unbounded'
          : list.some((x) => x.costStatus === 'bounded_unknown')
            ? 'bounded_unknown'
            : 'known',
      });
    }
    const arms = {};
    for (const arm of ['full', 'jev', 'core_discovery']) {
      const items = rows.filter((r) => r.arm === arm);
      const s = summarize(items, arm === 'full' ? 'baseline' : 'candidate');
      arms[arm] = {
        ...s,
        costMicroUsd: printable(s.costMicroUsd),
        cpsMicroUsd: printable(s.cpsMicroUsd),
        p95LatencyMs: printable(s.p95LatencyMs),
        attempts: raw.filter((r) => r.arm === arm).reduce((n, r) => n + (r.attempts ?? 1), 0),
        knownBillCoverage: items.length
          ? items.filter((r) => r.costStatus === 'known').length / items.length
          : 0,
        costPerStartedMicroUsd: items.length
          ? printable(s.costMicroUsd / items.length)
          : 'unbounded',
      };
    }
    const comparisons = {};
    for (const candidateArm of ['jev', 'core_discovery']) {
      const bases = rows.filter((r) => r.arm === 'full'),
        candidates = rows.filter((r) => r.arm === candidateArm),
        pairs = bases.flatMap((base) => {
          const candidate = candidates.find((c) => c.episodeId === base.episodeId);
          return candidate && candidate.clusterId === base.clusterId ? [{ base, candidate }] : [];
        });
      const reasons = [];
      if (
        pairs.length !== bases.length ||
        pairs.length !== candidates.length ||
        (input.expectedEpisodes && pairs.length !== input.expectedEpisodes.length) ||
        !pairs.length
      )
        reasons.push('incomplete_pairs');
      if (rows.some((r) => !r.complete)) reasons.push('incomplete_receipts');
      if (
        rows.some(
          (r) =>
            r.costStatus === 'unbounded' || (r.costStatus === 'known' && r.costMicroUsd === null),
        )
      )
        reasons.push('unbounded_cost');
      if (quarantine.length) reasons.push('quarantined_records');
      if (cohorts.size > 1) reasons.push('drift_separated_cohorts');
      if (
        !input.preregistration?.stopping ||
        !input.preregistration?.expansion ||
        !input.repeatAggregation
      )
        reasons.push('missing_preregistration');
      if (!input.humanCorpusReady || rows.some((r) => r.labelMethod !== 'human_adjudicated'))
        reasons.push('independent_human_corpus_not_ready');
      const boot = pairs.length ? pairedBootstrap(pairs, { seed: input.seed, draws: 10000 }) : null;
      if (!boot || boot.clusters < (input.minimumClusters ?? 60))
        reasons.push('insufficient_power');
      const critical = candidates.flatMap((c) => c.critical);
      if (critical.length) reasons.push('critical_veto');
      const gates = boot
        ? {
            success:
              typeof boot.intervals.successDifference.lower === 'number' &&
              boot.intervals.successDifference.lower >= -0.02,
            cost:
              boot.undefinedCostDraws === 0 &&
              typeof boot.intervals.costRatio.upper === 'number' &&
              boot.intervals.costRatio.upper < 1,
            latency:
              typeof boot.intervals.latencyRatio.upper === 'number' &&
              boot.intervals.latencyRatio.upper <= 1.1,
          }
        : { success: false, cost: false, latency: false };
      const status = reasons.length
        ? 'inconclusive'
        : Object.values(gates).every(Boolean)
          ? 'candidate_eligible_for_human_review'
          : 'baseline_retained';
      comparisons[candidateArm] = {
        status,
        reasons,
        gates,
        critical,
        bootstrap: boot,
        pairedEpisodes: pairs.length,
        adverseUnknownBounds: rows.some((r) => r.costStatus === 'bounded_unknown'),
      };
    }
    reports.push({ cohort, provenance: raw[0]?.cohort, arms, comparisons });
  }
  return {
    version: 1,
    status:
      reports.length &&
      reports.every((r) =>
        Object.values(r.comparisons).every(
          (c) => c.status === 'candidate_eligible_for_human_review',
        ),
      )
        ? 'candidate_eligible_for_human_review'
        : 'baseline_retained',
    cohorts: reports,
    quarantine,
    preregistration: input.preregistration ?? null,
    authority: 'analysis_only',
  };
}
export function reportRun(root) {
  const result = readJSON(path.join(root, 'result.json')),
    manifest = readJSON(path.join(root, 'manifest.json'));
  assert(digest(manifest) === result.manifestSha256, 'run manifest hash changed');
  const events = dedupe(jsonl(path.join(root, 'events.jsonl')).map(validateRecord)),
    receipts = dedupe(jsonl(path.join(root, 'receipts.jsonl')).map(validateRecord));
  const records = [...events.records, ...receipts.records];
  const combined = dedupe(records);
  assert(
    records.every(
      (r) => r.runId === result.runId && digest(r.revisions) === digest(manifest.provenance),
    ),
    'run receipt revision/binding mismatch',
  );
  const analysis = structuredClone(result.analysis);
  analysis.expectedEpisodes = manifest.corpus.episodeIds;
  for (const row of analysis.observations) {
    const relevant = receipts.records.filter(
      (r) => r.episodeId === row.episodeId && r.arm === row.arm,
    );
    const collection = relevant.find((r) => r.kind === 'collection'),
      reset = relevant.find((r) => r.kind === 'reset');
    const required = manifest.evidence.expectedKinds.filter(
      (k) => !['adapter_identity'].includes(k),
    );
    if (
      !collection ||
      !reset ||
      collection.rootId !== reset.rootId ||
      required.some((kind) => !relevant.some((r) => r.kind === kind)) ||
      events.quarantine.length ||
      receipts.quarantine.length ||
      combined.quarantine.length
    ) {
      row.complete = false;
      row.outcome = 'indeterminate';
    }
    assert(digest(row.cohort) === digest(manifest.provenance), 'cohort binding mismatch');
    if (collection) {
      row.outcome = row.complete ? collection.payload.outcome : 'indeterminate';
      row.complete = row.complete && collection.payload.complete === true;
      row.critical = collection.payload.critical;
    }
    const drift = relevant
      .filter((r) => r.kind === 'provider_received' || r.kind === 'provider_settled')
      .flatMap((r) => {
        const request = events.records.find(
          (e) => e.kind === 'provider_requested' && e.attemptId === r.attemptId,
        );
        const model =
          request?.payload.kind === 'classifier'
            ? manifest.provenance.model.classifier
            : manifest.provenance.model;
        return r.payload.resolvedModel && !model?.resolved.includes(r.payload.resolvedModel)
          ? [
              {
                kind: request?.payload.kind ?? 'unknown',
                requested: request?.payload.requestedModel ?? null,
                resolved: r.payload.resolvedModel,
              },
            ]
          : [];
      });
    if (drift.length) row.cohort = { ...manifest.provenance, observedModelDrift: drift };

    const bills = dedupe(
      relevant
        .filter((r) => r.kind === 'provider_settled' || r.kind === 'provider_failed')
        .map((r) => ({ ...r.payload, id: r.attemptId })),
    );
    if (bills.quarantine.length) {
      row.complete = false;
      row.costStatus = 'unbounded';
      row.upperMicroUsd = null;
    }
    const requests = events.records.filter(
      (r) => r.kind === 'provider_requested' && r.episodeId === row.episodeId && r.arm === row.arm,
    );
    if (requests.some((r) => !bills.records.some((b) => b.id === r.attemptId))) {
      row.complete = false;
      row.outcome = 'indeterminate';
      row.costStatus = 'unbounded';
      row.upperMicroUsd = null;
    }
    const known = bills.records
      .filter((r) => r.costStatus === 'known')
      .reduce((n, r) => n + r.costMicroUsd, 0);
    assert(
      row.costMicroUsd === null || row.costMicroUsd >= known,
      'cached outcome omitted billed attempts',
    );
  }
  return analyze(analysis);
}
if (direct(import.meta.url))
  main(async () => {
    const a = args(process.argv.slice(2));
    if (a.complaint) {
      const { manifest } = loadManifest(a.manifest);
      assert(manifest.provenance.gateway, 'pinned C source required');
      const validate = compileComplaintSchema(
        path.resolve(a['gateway-root']),
        manifest.provenance.gateway,
      );
      console.log(
        canonical(
          complaintReport(
            loadComplaintInput(a.complaint, manifest.provenance.gateway),
            validate,
            manifest.gates.complaint,
            a.labels ? readJSON(a.labels) : [],
          ),
        ),
      );
    } else
      console.log(canonical(a.run ? reportRun(path.resolve(a.run)) : analyze(readJSON(a.input))));
  });
